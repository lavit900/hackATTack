@echo off
cd /d "%~dp0"
title FlowPilot
python app.py
pause
