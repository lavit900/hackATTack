"""
FlowPilot AI - Autonomous Sequential Executor
Executes structured plans in dependency order, manages state transitions in SQLite,
invokes tools via MCP, handles human approvals, coordinates self-healing retries,
and runs independent verification.
"""

import os
import time
import threading
from typing import Any, Dict, List, Optional, Set, Tuple

import database
from mcp_client import MCPClient
from agent.recovery import RecoveryEngine
import agent.verifier as verifier
import services.audit as audit_svc
import services.approval as approval_svc

# Thread safety lock map to prevent duplicate concurrent runs per task
_task_execution_locks: Dict[str, threading.Lock] = {}
_global_lock = threading.Lock()


def get_task_lock(task_id: str) -> threading.Lock:
    with _global_lock:
        if task_id not in _task_execution_locks:
            _task_execution_locks[task_id] = threading.Lock()
        return _task_execution_locks[task_id]


class WorkflowExecutor:
    def __init__(self, db_path: Optional[str] = None, mcp_client: Optional[MCPClient] = None):
        self.db_path = db_path
        self.mcp_client = mcp_client or MCPClient(db_path=self.db_path)
        self.recovery = RecoveryEngine(db_path=self.db_path)
        self.audit = audit_svc.AuditService(db_path=self.db_path)
        self.approvals = approval_svc.ApprovalService(db_path=self.db_path)

    def run_task(self, task_id: str) -> Dict[str, Any]:
        """
        Main execution entry point. Acquires lock, executes pending steps in dependency order,
        recovers from errors, halts for approvals, and independently verifies outputs.
        """
        lock = get_task_lock(task_id)
        if not lock.acquire(blocking=False):
            return {
                "success": False,
                "error": f"Task {task_id} is already actively running in another execution thread.",
                "status": "RUNNING",
            }

        try:
            task = database.get_task(task_id, db_path=self.db_path)
            if not task:
                return {"success": False, "error": f"Task {task_id} not found."}

            if task["status"] == "CANCELLED":
                return {"success": False, "status": "CANCELLED", "message": "Task is cancelled."}

            if task["status"] in ("SUCCEEDED", "WAITING_FOR_APPROVAL") and task.get("completed_at"):
                return {"success": True, "task": task, "message": "Task already completed."}

            # Set task status to RUNNING
            database.update_task_status(task_id, "RUNNING", db_path=self.db_path)
            self.audit.log(task_id, "TASK_EXECUTION_STARTED", f"Execution started for task: {task['goal']}")

            steps = database.get_steps_for_task(task_id, db_path=self.db_path)
            if not steps:
                database.update_task_status(task_id, "FAILED", error_message="No execution steps found in task.", db_path=self.db_path)
                return {"success": False, "error": "No execution steps found."}

            # Map step outputs so downstream steps can access required data
            step_outputs: Dict[str, Any] = {}
            for s in steps:
                if s["status"] == "SUCCEEDED":
                    step_outputs[s["step_id"]] = s.get("result") or {}

            # Topological execution of steps
            for step in steps:
                step_id = step["step_id"]

                # 0. Check if task was cancelled
                fresh_task = database.get_task(task_id, db_path=self.db_path)
                if fresh_task and fresh_task["status"] == "CANCELLED":
                    self.audit.log(task_id, "TASK_CANCELLED", "Task execution halted due to cancellation.")
                    return {"success": False, "status": "CANCELLED", "message": "Task execution was cancelled."}

                # 1. Skip already succeeded steps (Never rerun successful work!)
                if step["status"] == "SUCCEEDED":
                    continue

                # 2. Check dependencies
                deps = step.get("dependencies", [])
                unmet_deps = [d for d in deps if d not in step_outputs]
                if unmet_deps:
                    err_msg = f"Step '{step_id}' cannot run; unmet dependencies: {unmet_deps}"
                    database.update_step_status(task_id, step_id, "FAILED", error_message=err_msg, db_path=self.db_path)
                    database.update_task_status(task_id, "FAILED", error_message=err_msg, db_path=self.db_path)
                    self.audit.log(task_id, "STEP_DEPENDENCY_FAILED", err_msg, step_id=step_id)
                    return {"success": False, "error": err_msg, "step_id": step_id}

                # 3. Check Human Approval requirement
                if step.get("requires_approval"):
                    pending = self.approvals.get_pending(task_id)
                    existing_appr = next((a for a in pending if a["step_id"] == step_id), None)
                    
                    # Check if decision was already made
                    all_apprs = database.get_connection(self.db_path).execute(
                        "SELECT * FROM approvals WHERE task_id = ? AND step_id = ?",
                        (task_id, step_id)
                    ).fetchall()
                    
                    approved = any(dict(a).get("status") == "APPROVED" for a in all_apprs)
                    rejected = any(dict(a).get("status") == "REJECTED" for a in all_apprs)

                    if rejected:
                        # User rejected sensitive action
                        database.update_step_status(task_id, step_id, "SKIPPED", error_message="Action rejected by user.", db_path=self.db_path)
                        self.audit.log(task_id, "APPROVAL_REJECTED", f"Step '{step_id}' skipped by user approval refusal.", step_id=step_id)
                        continue

                    if not approved:
                        # Halt and request explicit approval
                        if not existing_appr:
                            self.approvals.request_approval(
                                task_id=task_id,
                                step_id=step_id,
                                action_type="SENSITIVE_EXTERNAL_ACTION",
                                description=step["description"],
                                risk_assessment="External action: Potential external side-effects or sensitive transmission.",
                                payload=step["input_params"],
                            )
                        database.update_step_status(task_id, step_id, "WAITING_FOR_APPROVAL", db_path=self.db_path)
                        database.update_task_status(task_id, "WAITING_FOR_APPROVAL", db_path=self.db_path)
                        self.audit.log(
                            task_id,
                            "APPROVAL_REQUESTED",
                            f"Step '{step_id}' paused awaiting explicit human approval.",
                            step_id=step_id,
                            details={"description": step["description"]}
                        )
                        return {
                            "success": True,
                            "status": "WAITING_FOR_APPROVAL",
                            "step_id": step_id,
                            "message": "Execution paused. Explicit human approval required before proceeding."
                        }

                # 4. Prepare parameters with contextual data from upstream dependencies
                tool_name = step["tool_name"]
                input_params = dict(step.get("input_params", {}))
                
                # Context enrichment from upstream research step
                if tool_name == "save_opportunities" and "opportunities" not in input_params:
                    # Fetch from step_1 or first search step
                    for d_id in deps:
                        dep_res = step_outputs.get(d_id, {})
                        if isinstance(dep_res, dict) and "opportunities" in dep_res:
                            input_params["opportunities"] = dep_res["opportunities"]
                            break
                    # If still empty, check default search
                    if "opportunities" not in input_params:
                        for prev_res in step_outputs.values():
                            if isinstance(prev_res, dict) and "opportunities" in prev_res:
                                input_params["opportunities"] = prev_res["opportunities"]
                                break

                # Ensure task_id is passed to tools that use it for paths/faults
                if "task_id" not in input_params:
                    input_params["task_id"] = task_id
                if self.db_path and "db_path" not in input_params:
                    input_params["db_path"] = self.db_path

                # Context enrichment for screenshot and validation from upstream opportunities
                if tool_name in ("take_page_screenshot", "validate_source"):
                    current_url = input_params.get("url", "")
                    if not current_url or "careers.google.com/students" in current_url:
                        for prev_res in step_outputs.values():
                            if isinstance(prev_res, dict) and "opportunities" in prev_res and prev_res["opportunities"]:
                                first_opp = prev_res["opportunities"][0]
                                dynamic_url = first_opp.get("source_url") or first_opp.get("application_url")
                                if dynamic_url:
                                    input_params["url"] = dynamic_url
                                    if "opportunity_id" in input_params:
                                        input_params["opportunity_id"] = first_opp.get("opportunity_id")
                # Context enrichment for communication dispatch
                if tool_name == "send_communication_or_message" and "attachment_path" not in input_params:
                    for prev_res in step_outputs.values():
                        if isinstance(prev_res, dict) and "file_path" in prev_res:
                            input_params["attachment_path"] = prev_res["file_path"]
                            break

                # 5. Execute Step with Self-Healing Recovery Loop
                success, step_res, err_msg = self._execute_step_with_healing(task_id, step, input_params, step_outputs)
                if not success:
                    # Step failed after retries exhausted
                    database.update_task_status(task_id, "FAILED", error_message=err_msg, db_path=self.db_path)
                    self.audit.log(task_id, "TASK_EXECUTION_FAILED", f"Task failed at step '{step_id}': {err_msg}", step_id=step_id)
                    # Run verifier for honest partial completion report
                    verifier.verify_task_deliverables(task_id, db_path=self.db_path)
                    return {"success": False, "error": err_msg, "step_id": step_id}

                # Step Succeeded!
                step_outputs[step_id] = step_res
                # Save immediately to database
                database.update_step_status(task_id, step_id, "SUCCEEDED", result=step_res, db_path=self.db_path)
                self.audit.log(task_id, "STEP_COMPLETED", f"Step '{step_id}' ({tool_name}) succeeded.", step_id=step_id)

                # Register generated artifacts if applicable
                self._register_step_artifacts(task_id, step_id, tool_name, step_res)

            # 6. All steps executed! Run Independent Verification
            self.audit.log(task_id, "VERIFICATION_STARTED", "Starting independent artifact inspection.")
            verification_result = verifier.verify_task_deliverables(task_id, db_path=self.db_path)
            
            ver_status = verification_result["status"]
            self.audit.log(
                task_id,
                "VERIFICATION_RESULT",
                f"Verification completed with outcome: {ver_status}. {verification_result['summary']}",
                details=verification_result["details"]
            )

            final_task_status = "SUCCEEDED" if ver_status in ("VERIFIED", "PARTIALLY_VERIFIED") else "FAILED"
            database.update_task_status(task_id, final_task_status, db_path=self.db_path)

            self.audit.log(task_id, "TASK_COMPLETED", f"FlowPilot mission finalized with status: {final_task_status}.")
            return {
                "success": True,
                "status": final_task_status,
                "verification": verification_result,
                "task_id": task_id,
            }

        finally:
            lock.release()

    def _execute_step_with_healing(
        self,
        task_id: str,
        step: Dict[str, Any],
        input_params: Dict[str, Any],
        step_outputs: Dict[str, Any],
    ) -> Tuple[bool, Optional[Any], Optional[str]]:
        """
        Executes a tool call using the MCP client, catching transient errors and applying
        bounded exponential backoff and pre-retry artifact inspection.
        """
        step_id = step["step_id"]
        tool_name = step["tool_name"]

        # If tool is create_email_draft and input_params doesn't have opportunity, create drafts for all opportunities
        if tool_name == "create_email_draft" and "opportunity" not in input_params:
            opps = []
            for prev_res in step_outputs.values():
                if isinstance(prev_res, dict) and "opportunities" in prev_res:
                    opps = prev_res["opportunities"]
                    break
            
            if opps:
                # Create drafts for each opportunity found
                drafts_results = []
                for opp in opps:
                    sub_params = {
                        "opportunity": opp,
                        "task_id": task_id,
                    }
                    sub_res = self.mcp_client.call_tool("create_email_draft", sub_params)
                    drafts_results.append(sub_res)
                return True, {"drafts": drafts_results, "count": len(drafts_results)}, None

        # Standard tool execution loop with bounded retries
        current_attempt = step.get("attempt_count", 0)
        max_retries = step.get("max_retries", 3)

        while current_attempt < max_retries:
            current_attempt += 1
            database.update_step_status(task_id, step_id, "RUNNING", increment_attempt=True, db_path=self.db_path)
            self.audit.log(
                task_id,
                "TOOL_INVOKED",
                f"Executing MCP tool '{tool_name}' (Attempt {current_attempt}/{max_retries})",
                step_id=step_id,
                details={"tool": tool_name, "attempt": current_attempt}
            )

            try:
                # Call tool via official MCP client
                result = self.mcp_client.call_tool(tool_name, input_params)
                
                # Check for explicit tool-level error in structured return
                if isinstance(result, dict) and result.get("success") is False:
                    error_msg = result.get("error", "Unknown tool failure")
                    raise IOError(error_msg)

                return True, result, None

            except Exception as e:
                # Pass to Recovery Engine
                step_snapshot = dict(step)
                step_snapshot["attempt_count"] = current_attempt
                decision = self.recovery.decide_recovery(task_id, step_snapshot, e)

                if decision["action"] == "RESOLVED_VIA_ARTIFACT_CHECK":
                    return True, decision["result"], None

                elif decision["action"] == "RETRY":
                    database.update_step_status(
                        task_id,
                        step_id,
                        "RETRYING",
                        error_message=str(e),
                        db_path=self.db_path
                    )
                    time.sleep(decision["delay_seconds"])
                    # Loop will retry
                    continue

                else:
                    # Action is FAIL
                    database.update_step_status(
                        task_id,
                        step_id,
                        "FAILED",
                        error_message=decision["reason"],
                        db_path=self.db_path
                    )
                    return False, None, decision["reason"]

        return False, None, f"Exhausted all {max_retries} retry attempts without successful completion."

    def _register_step_artifacts(self, task_id: str, step_id: str, tool_name: str, step_res: Any) -> None:
        """Register artifacts generated during step execution."""
        if not isinstance(step_res, dict):
            return

        if tool_name == "save_opportunities" and step_res.get("file_path"):
            fpath = step_res["file_path"]
            database.register_artifact(
                task_id=task_id,
                artifact_type="SPREADSHEET",
                file_path=fpath,
                title=f"Opportunities Workbook ({os.path.basename(fpath)})",
                step_id=step_id,
                metadata={"total_records": step_res.get("total_records")},
                db_path=self.db_path,
            )

        elif tool_name == "create_email_draft":
            if "file_path" in step_res:
                fpath = step_res["file_path"]
                database.register_artifact(
                    task_id=task_id,
                    artifact_type="EMAIL_DRAFT",
                    file_path=fpath,
                    title=f"Email Draft ({os.path.basename(fpath)})",
                    step_id=step_id,
                    metadata={"opportunity_id": step_res.get("opportunity_id")},
                    db_path=self.db_path,
                )
            elif "drafts" in step_res:
                for d in step_res["drafts"]:
                    if isinstance(d, dict) and d.get("file_path"):
                        fpath = d["file_path"]
                        database.register_artifact(
                            task_id=task_id,
                            artifact_type="EMAIL_DRAFT",
                            file_path=fpath,
                            title=f"Email Draft ({os.path.basename(fpath)})",
                            step_id=step_id,
                            metadata={"opportunity_id": d.get("opportunity_id")},
                            db_path=self.db_path,
                        )

        elif tool_name in ("take_page_screenshot", "take_desktop_screenshot") and step_res.get("file_path"):
            fpath = step_res["file_path"]
            database.register_artifact(
                task_id=task_id,
                artifact_type="SCREENSHOT",
                file_path=fpath,
                title=f"Screenshot ({os.path.basename(fpath)})",
                step_id=step_id,
                metadata={"file_size": step_res.get("file_size_bytes"), "url": step_res.get("url")},
                db_path=self.db_path,
            )

        elif tool_name in ("generate_study_plan", "draft_cover_letter", "prepare_document_or_pdf") and (step_res.get("file_path") or step_res.get("plan_file")):
            fpath = step_res.get("file_path") or step_res.get("plan_file")
            database.register_artifact(
                task_id=task_id,
                artifact_type="DOCUMENT",
                file_path=fpath,
                title=f"Verified Document ({os.path.basename(fpath)})",
                step_id=step_id,
                metadata={"recipient": step_res.get("recipient")},
                db_path=self.db_path,
            )
