"""
FlowPilot AI - AI Planning Engine
Converts natural language user goals into structured, validated execution plans.
Supports official Google GenAI SDK with graceful fallback to labeled deterministic planner in Demo Mode.
"""

import json
import os
import re
import uuid
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Set
from dotenv import load_dotenv

load_dotenv()

ALLOWED_TOOLS: Set[str] = {
    "search_opportunities",
    "validate_source",
    "save_opportunities",
    "inspect_workbook",
    "create_email_draft",
    "list_drafts",
    "take_page_screenshot",
    "take_desktop_screenshot",
    "create_reminder",
    "list_reminders",
    "cancel_reminder",
    "generate_study_plan",
    "compare_resume_to_job",
    "draft_cover_letter",
    "prepare_document_or_pdf",
    "send_communication_or_message",
}

VALID_STATUSES: Set[str] = {
    "PENDING",
    "RUNNING",
    "WAITING_FOR_APPROVAL",
    "SUCCEEDED",
    "FAILED",
    "RETRYING",
    "SKIPPED",
}


class PlanValidationError(ValueError):
    """Raised when a plan violates the execution schema, tool restrictions, or dependency graph."""
    pass


def validate_plan(plan: Dict[str, Any]) -> Dict[str, Any]:
    """
    Validates a generated plan against the strict FlowPilot execution schema:
    - Verifies task summary and steps structure.
    - Prohibits unknown tools.
    - Prohibits circular dependencies and future step references.
    - Validates parameter objects.
    """
    if not isinstance(plan, dict):
        raise PlanValidationError("Plan root must be a JSON object.")

    if not plan.get("task_summary") or not isinstance(plan["task_summary"], str):
        raise PlanValidationError("Plan must have a non-empty 'task_summary' string.")

    steps = plan.get("steps")
    if not isinstance(steps, list) or len(steps) == 0:
        raise PlanValidationError("Plan must contain a non-empty list of 'steps'.")

    seen_step_ids: Set[str] = set()

    for idx, step in enumerate(steps):
        if not isinstance(step, dict):
            raise PlanValidationError(f"Step at index {idx} must be a dictionary.")

        step_id = step.get("step_id")
        if not step_id or not isinstance(step_id, str):
            raise PlanValidationError(f"Step at index {idx} is missing a valid 'step_id'.")

        if step_id in seen_step_ids:
            raise PlanValidationError(f"Duplicate step_id '{step_id}' found in plan.")

        tool_name = step.get("tool_name")
        if tool_name not in ALLOWED_TOOLS:
            raise PlanValidationError(
                f"Step '{step_id}' requests forbidden or unknown tool '{tool_name}'. "
                f"Allowed tools: {sorted(list(ALLOWED_TOOLS))}"
            )

        if not isinstance(step.get("input_params"), dict):
            raise PlanValidationError(f"Step '{step_id}' input_params must be a dictionary.")

        deps = step.get("dependencies", [])
        if not isinstance(deps, list):
            raise PlanValidationError(f"Step '{step_id}' dependencies must be a list of step IDs.")

        for dep in deps:
            if dep not in seen_step_ids:
                raise PlanValidationError(
                    f"Step '{step_id}' depends on '{dep}', which has not been declared before it. "
                    "Circular or forward dependencies are disallowed."
                )

        status = step.get("status", "PENDING")
        if status not in VALID_STATUSES:
            raise PlanValidationError(f"Step '{step_id}' has invalid initial status '{status}'.")

        seen_step_ids.add(step_id)

    return plan


def generate_deterministic_demo_plan(goal: str, task_id: str) -> Dict[str, Any]:
    """
    Generates an authentic, structured multi-tool execution plan for hackathon demonstrations
    when the Gemini API key is absent. Labeled explicitly for transparency.
    """
    goal_lower = goal.lower().strip()
    is_sensitive = any(kw in goal_lower for kw in ["send email", "submit application", "auto apply", "deliver email", "for my approval", "approval required"])
    wants_screenshot = any(kw in goal_lower for kw in ["screenshot", "screen shot", "take ss", " ss ", "snapshot", "capture screen", "capture page"])
    wants_reminder = any(kw in goal_lower for kw in ["reminder", "alarm", "schedule deadline", "remind me", "wake me"])
    wants_study_plan = any(kw in goal_lower for kw in ["study plan", "placement prep", "interview plan", "roadmap"])

    # Classify a single-action request BEFORE the generic opportunity pipeline.
    # This prevents screenshot-only/alarm-only prompts from inheriting unrelated
    # spreadsheet and email-draft steps.
    explicit_multi_action = bool(re.search(r"\b(and then|also|plus|as well as)\b", goal_lower))
    screenshot_verbs = any(kw in goal_lower for kw in ["take", "capture", "save", "get", "make"])
    screenshot_requested = wants_screenshot and screenshot_verbs
    desktop_capture = bool(re.search(r"\b(my desktop|desktop screen|whole screen|entire screen|monitor screen|computer screen|screen of my computer)\b", goal_lower))
    if screenshot_requested and not explicit_multi_action:
        url_match = re.search(r"(?:https?://|www\.)[^\s,\'\"<>]+", goal, re.IGNORECASE)
        if not url_match:
            url_match = re.search(r"\b(?:localhost|127\.0\.0\.1)(?::\d{1,5})?(?:/[^\s,\'\"<>]*)?", goal, re.IGNORECASE)
        if not url_match:
            url_match = re.search(r"\b(?:[a-z0-9-]+\.)+(?:com|org|net|io|gov|edu|in|co|ai|dev)(?::\d{1,5})?(?:/[^\s,\'\"<>]*)?", goal, re.IGNORECASE)
        target_url = url_match.group(0).rstrip(".,;)") if url_match else ""
        if target_url and target_url.startswith("www."):
            target_url = "https://" + target_url
        elif target_url and not target_url.startswith(("http://", "https://")):
            target_url = ("http://" if target_url.lower().startswith(("localhost", "127.0.0.1")) else "https://") + target_url
        if not target_url:
            known_sites = {
                "google": "https://www.google.com/",
                "youtube": "https://www.youtube.com/",
                "microsoft": "https://www.microsoft.com/",
                "isro": "https://www.isro.gov.in/",
                "amazon": "https://www.amazon.in/",
                "github": "https://github.com/",
                "linkedin": "https://www.linkedin.com/",
                "netlify": "https://www.netlify.com/",
                "chatgpt": "https://chatgpt.com/",
                "openai": "https://openai.com/",
                "flipkart": "https://www.flipkart.com/",
            }
            for site_name, site_url in known_sites.items():
                if re.search(rf"\b{re.escape(site_name)}\b", goal_lower):
                    target_url = site_url
                    break
        tool = "take_desktop_screenshot" if desktop_capture else "take_page_screenshot"
        params = {"task_id": task_id}
        if tool == "take_page_screenshot":
            params["url"] = target_url
        return {
            "task_id": task_id,
            "task_summary": "Capture desktop screenshot" if desktop_capture else (f"Capture screenshot of {target_url}" if target_url else "Capture requested webpage screenshot"),
            "planner_source": "DETERMINISTIC_DEMO_PLANNER (Hackathon Demo Mode)",
            "goal": goal,
            "steps": [{
                "step_id": "step_1",
                "description": ("Capture the actual desktop display" if desktop_capture else (f"Open the requested URL in a real browser and capture it: {target_url}" if target_url else "Capture the requested website; a URL or recognized website name is required.")),
                "tool_name": tool,
                "input_params": params,
                "dependencies": [],
                "success_criteria": "A real PNG screenshot of the requested target is saved and registered as an artifact.",
                "requires_approval": False,
                "status": "PENDING",
            }],
        }

    if wants_reminder and not any(kw in goal_lower for kw in ["internship", "opportunity", "job search", "excel", "spreadsheet"]) and not explicit_multi_action:
        # Resolve common natural-language reminder dates/times into a real future ISO timestamp.
        now = datetime.now().astimezone()
        due = now + timedelta(hours=1)
        time_match = re.search(r"\b(\d{1,2})(?::(\d{2}))?\s*(am|pm)\b", goal_lower)
        if time_match:
            hour = int(time_match.group(1)) % 12
            if time_match.group(3) == "pm":
                hour += 12
            minute = int(time_match.group(2) or 0)
            due = due.replace(hour=hour, minute=minute, second=0, microsecond=0)
        if "tomorrow" in goal_lower:
            due = (now + timedelta(days=1)).replace(hour=due.hour, minute=due.minute, second=0, microsecond=0)
        elif "today" in goal_lower and due <= now:
            due += timedelta(days=1)
        elif time_match and due <= now:
            due += timedelta(days=1)
        title_match = re.search(r"(?:remind me to|reminder for|alarm for|wake me for|remind me about)\s+(.+?)(?:\s+(?:at|on|tomorrow|today)\b|$)", goal, re.IGNORECASE)
        title = (title_match.group(1).strip(" .,!?") if title_match else "Personal reminder") or "Personal reminder"
        if re.fullmatch(r"\d{1,2}(?::\d{2})?\s*(?:am|pm)?", title, re.IGNORECASE):
            title = "Alarm"
        recurrence = "DAILY" if "every day" in goal_lower or "daily" in goal_lower else "ONCE"
        return {
            "task_id": task_id,
            "task_summary": f"Schedule reminder: {title}",
            "planner_source": "DETERMINISTIC_DEMO_PLANNER (Hackathon Demo Mode)",
            "goal": goal,
            "steps": [{
                "step_id": "step_1",
                "description": f"Save reminder '{title}' for {due.isoformat(timespec='minutes')}.",
                "tool_name": "create_reminder",
                "input_params": {"title": title, "due_at": due.isoformat(timespec="minutes"), "recurrence": recurrence, "reminder_type": "ALARM" if "alarm" in goal_lower or "wake me" in goal_lower else "GENERAL", "task_id": task_id},
                "dependencies": [],
                "success_criteria": "Reminder is persisted in SQLite and visible in the reminders list.",
                "requires_approval": False,
                "status": "PENDING",
            }],
        }

    # Determine target URL based on goal query or company mentions
    url_match = re.search(r'https?://[^\s,\'\"]+', goal)
    if url_match:
        target_url = url_match.group(0)
    elif any(kw in goal_lower for kw in ["frontend", "this page", "current page", "dashboard", "localhost", "ui", "web app", "site", "webpage"]):
        target_url = "http://127.0.0.1:5000"
    elif "google" in goal_lower:
        target_url = "https://careers.google.com/students/"
    elif "nvidia" in goal_lower:
        target_url = "https://www.nvidia.com/en-us/about-nvidia/careers/"
    elif "microsoft" in goal_lower:
        target_url = "https://careers.microsoft.com/v2/global/en/students-graduates.html"
    elif "openai" in goal_lower:
        target_url = "https://openai.com/careers/"
    elif "vercel" in goal_lower:
        target_url = "https://vercel.com/careers"
    elif "stripe" in goal_lower:
        target_url = "https://stripe.com/jobs"
    elif "amazon" in goal_lower:
        target_url = "https://www.amazon.jobs/en/teams/internships-for-students"
    elif "isro" in goal_lower:
        target_url = "https://www.isro.gov.in/Careers.html"
    elif "cloudflare" in goal_lower:
        target_url = "https://www.cloudflare.com/careers/"
    elif "spotify" in goal_lower:
        target_url = "https://www.lifeatspotify.com/jobs"
    elif "tesla" in goal_lower:
        target_url = "https://www.tesla.com/careers"
    else:
        target_url = "http://127.0.0.1:5000"


    # Check for pure standalone tool goals
    is_pure_screenshot = (
        any(kw in goal_lower for kw in ["screenshot", "screen shot", "take ss", "ss of", "capture page", "snapshot", "capture screen"])
        or (re.search(r'\bss\b', goal_lower) is not None)
    ) and not any(kw in goal_lower for kw in ["internship", "job", "opportunity", "excel", "spreadsheet", "draft email", "whatsapp"])

    is_communication_goal = any(kw in goal_lower for kw in ["whatsapp", "send pdf", "send document", "send file", "telegram", "slack", "message to", "to a contact"])
    is_pure_study_plan = any(kw in goal_lower for kw in ["study plan", "roadmap", "placement prep", "interview plan"]) and not any(kw in goal_lower for kw in ["internship", "excel", "spreadsheet", "email draft", "whatsapp"])
    is_pure_resume = any(kw in goal_lower for kw in ["compare resume", "resume match", "resume gap"]) and not any(kw in goal_lower for kw in ["excel", "spreadsheet"])
    is_pure_cover_letter = any(kw in goal_lower for kw in ["cover letter", "application letter"]) and not any(kw in goal_lower for kw in ["excel", "spreadsheet"])

    if is_pure_screenshot:
        use_desktop = any(kw in goal_lower for kw in ["desktop", "screen", "monitor", "display"]) and "frontend" not in goal_lower and "http" not in target_url
        tool_to_use = "take_desktop_screenshot" if use_desktop else "take_page_screenshot"
        input_params = {"task_id": task_id} if use_desktop else {"url": target_url, "task_id": task_id}
        desc = f"Capture high-resolution visual screenshot of {target_url}." if not use_desktop else "Capture physical desktop screen capture using ImageGrab."

        return {
            "task_id": task_id,
            "task_summary": f"High-Resolution Visual Webpage Capture of {target_url}",
            "planner_source": "DETERMINISTIC_DEMO_PLANNER (Hackathon Demo Mode)",
            "goal": goal,
            "steps": [
                {
                    "step_id": "step_1",
                    "description": desc,
                    "tool_name": tool_to_use,
                    "input_params": input_params,
                    "dependencies": [],
                    "success_criteria": "Verified PNG screenshot saved to outputs and verified.",
                    "requires_approval": False,
                    "status": "PENDING",
                }
            ],
        }

    if is_communication_goal:
        recip_match = re.search(r'(?:to|with)\s+(?:a\s+|an\s+)?([A-Za-z0-9_\-\.]+)', goal, re.IGNORECASE)
        recipient = recip_match.group(1).title() if recip_match else "Target Contact"
        channel = "whatsapp" if "whatsapp" in goal_lower else ("slack" if "slack" in goal_lower else "email")
        # Preserve a full international phone number when a WhatsApp goal includes one.
        if channel == "whatsapp":
            phone_match = re.search(r'(?:\+?\d[\d\s().-]{7,}\d)', goal)
            if phone_match:
                recipient = re.sub(r"[^0-9]", "", phone_match.group(0))
        message_match = re.search(r'(?:message|text)\s*:\s*["\']?(.+?)["\']?(?:\s+(?:to|via)\s+|$)', goal, re.IGNORECASE)
        requested_message = message_match.group(1).strip().strip("\'\"") if message_match else f"Sending requested document to {recipient} via {channel.upper()}."

        return {
            "task_id": task_id,
            "task_summary": f"Document Dispatch: Transmit Verified PDF to {recipient} via {channel.upper()}",
            "planner_source": "DETERMINISTIC_DEMO_PLANNER (Hackathon Demo Mode)",
            "goal": goal,
            "steps": [
                {
                    "step_id": "step_1",
                    "description": f"Generate formatted PDF deliverable document requested for {recipient}.",
                    "tool_name": "prepare_document_or_pdf",
                    "input_params": {
                        "title": f"Official Deliverable for {recipient}",
                        "recipient": recipient,
                        "content": f"Verified document generated per operator instructions: '{goal}'. Ready for transmission over authorized gateway.",
                        "task_id": task_id,
                    },
                    "dependencies": [],
                    "success_criteria": "Verified PDF document compiled with ReportLab and registered in SQLite.",
                    "requires_approval": False,
                    "status": "PENDING",
                },
                {
                    "step_id": "step_2",
                    "description": f"Transmit generated PDF document to {recipient} via {channel.upper()}.",
                    "tool_name": "send_communication_or_message",
                    "input_params": {
                        "channel": channel,
                        "recipient": recipient,
                        "message": requested_message,
                        "task_id": task_id,
                    },
                    "dependencies": ["step_1"],
                    "success_criteria": "External transmission confirmed and logged to audit stream.",
                    "requires_approval": True,
                    "status": "PENDING",
                }
            ],
        }

    if is_pure_study_plan:
        return {
            "task_id": task_id,
            "task_summary": "Comprehensive 4-Week Placement Preparation Roadmap",
            "planner_source": "DETERMINISTIC_DEMO_PLANNER (Hackathon Demo Mode)",
            "goal": goal,
            "steps": [
                {
                    "step_id": "step_1",
                    "description": "Formulate 4-week placement preparation and DSA interview roadmap.",
                    "tool_name": "generate_study_plan",
                    "input_params": {
                        "topic": "Data Structures, Algorithms & Core CS",
                        "target_role": "Software Engineering Candidate",
                        "duration_weeks": 4,
                        "task_id": task_id,
                    },
                    "dependencies": [],
                    "success_criteria": "Structured study roadmap generated and saved.",
                    "requires_approval": False,
                    "status": "PENDING",
                }
            ],
        }

    if is_pure_resume:
        return {
            "task_id": task_id,
            "task_summary": "Resume-to-Job Fit Analysis & Gap Assessment",
            "planner_source": "DETERMINISTIC_DEMO_PLANNER (Hackathon Demo Mode)",
            "goal": goal,
            "steps": [
                {
                    "step_id": "step_1",
                    "description": "Compare candidate resume against target role requirements.",
                    "tool_name": "compare_resume_to_job",
                    "input_params": {
                        "resume_text": "B.Tech CS 3rd year student. Skills: Python, Java, Data Structures, Algorithms, React, SQL. Projects: FlowPilot AI operator, E-commerce backend.",
                        "job_description": "Software Engineering Intern. Requirements: Strong algorithms, object-oriented design, Python or Java, cloud basics.",
                        "task_id": task_id,
                    },
                    "dependencies": [],
                    "success_criteria": "Detailed fit score and gaps report compiled.",
                    "requires_approval": False,
                    "status": "PENDING",
                }
            ],
        }

    if is_pure_cover_letter:
        return {
            "task_id": task_id,
            "task_summary": "Tailored Cover Letter Drafting",
            "planner_source": "DETERMINISTIC_DEMO_PLANNER (Hackathon Demo Mode)",
            "goal": goal,
            "steps": [
                {
                    "step_id": "step_1",
                    "description": "Draft tailored, compelling cover letter for target role.",
                    "tool_name": "draft_cover_letter",
                    "input_params": {
                        "company": "Target Employer",
                        "role": "Software Development Engineer Intern",
                        "task_id": task_id,
                    },
                    "dependencies": [],
                    "success_criteria": "Professional cover letter generated and saved.",
                    "requires_approval": False,
                    "status": "PENDING",
                }
            ],
        }

    # Standard Multi-Tool Opportunity Pipeline
    steps = []
    requested_count_match = re.search(r"\b(?:find|search(?: for)?|show|list|get)\s+(?:me\s+)?(\d{1,3})\s+(?:[a-z0-9+.#/-]+\s+){0,4}(?:jobs?|internships?|opportunities|roles|openings)\b", goal_lower)
    requested_count = max(1, min(100, int(requested_count_match.group(1)))) if requested_count_match else 10

    # Step 1: Search Opportunities
    steps.append({
        "step_id": "step_1",
        "description": f"Search for verified opportunities matching: '{goal[:60]}...'",
        "tool_name": "search_opportunities",
        "input_params": {
            "query": goal,
            "max_results": requested_count,
            "force_demo": False,
        },
        "dependencies": [],
        "success_criteria": "Retrieve verified student opportunities with eligibility details.",
        "requires_approval": False,
        "status": "PENDING",
    })

    # Step 2: Validate Source Links
    steps.append({
        "step_id": "step_2",
        "description": f"Validate official career portals and application links ({target_url[:35]}...).",
        "tool_name": "validate_source",
        "input_params": {
            "url": target_url,
        },
        "dependencies": ["step_1"],
        "success_criteria": "Confirm HTTP connectivity, SSL validity, and career portal accessibility.",
        "requires_approval": False,
        "status": "PENDING",
    })

    # Step 3: Excel Compilation
    steps.append({
        "step_id": "step_3",
        "description": "Save matched opportunities into a structured Excel workbook with deduplication.",
        "tool_name": "save_opportunities",
        "input_params": {
            "file_path": f"outputs/opportunities_{task_id}.xlsx",
            "task_id": task_id,
        },
        "dependencies": ["step_2"],
        "success_criteria": "Excel file created/updated with formatted columns and deduplicated rows.",
        "requires_approval": False,
        "status": "PENDING",
    })

    prev_step_id = "step_3"

    # Optional or Multi-Tool: Browser Screenshot
    if wants_screenshot or "screenshot" in goal_lower:
        shot_step_id = f"step_{len(steps) + 1}"
        steps.append({
            "step_id": shot_step_id,
            "description": f"Capture high-resolution visual screenshot of verified career portal ({target_url[:30]}...).",
            "tool_name": "take_page_screenshot",
            "input_params": {
                "url": target_url,
                "task_id": task_id,
            },
            "dependencies": ["step_2"],
            "success_criteria": "Browser screenshot generated and registered as verified PNG artifact.",
            "requires_approval": False,
            "status": "PENDING",
        })
        prev_step_id = shot_step_id

    # Optional: Persistent Deadline Reminder
    if wants_reminder:
        rem_step_id = f"step_{len(steps) + 1}"
        steps.append({
            "step_id": rem_step_id,
            "description": "Schedule persistent deadline reminder for internship application window.",
            "tool_name": "create_reminder",
            "input_params": {
                "title": "Internship Application Deadline Follow-Up",
                "due_at": "2026-11-30",
                "recurrence": "ONCE",
                "reminder_type": "DEADLINE",
                "task_id": task_id,
            },
            "dependencies": ["step_1"],
            "success_criteria": "Persistent deadline reminder stored in SQLite database.",
            "requires_approval": False,
            "status": "PENDING",
        })

    # Optional: Study Plan
    if wants_study_plan:
        study_step_id = f"step_{len(steps) + 1}"
        steps.append({
            "step_id": study_step_id,
            "description": "Formulate 4-week placement preparation and DSA interview roadmap.",
            "tool_name": "generate_study_plan",
            "input_params": {
                "topic": "DSA & Core CS",
                "target_role": "Software Engineering Intern",
                "duration_weeks": 4,
                "task_id": task_id,
            },
            "dependencies": ["step_1"],
            "success_criteria": "Custom placement study roadmap compiled and saved to disk.",
            "requires_approval": False,
            "status": "PENDING",
        })

    # Step: Email Draft Generation
    draft_step_id = f"step_{len(steps) + 1}"
    steps.append({
        "step_id": draft_step_id,
        "description": "Generate personalized .eml email drafts for opportunities without sending.",
        "tool_name": "create_email_draft",
        "input_params": {
            "task_id": task_id,
        },
        "dependencies": ["step_3"],
        "success_criteria": "Formatted .eml files stored locally in outputs/drafts with recipient placeholders.",
        "requires_approval": False,
        "status": "PENDING",
    })

    # Step: Independent Physical Inspection
    inspect_step_id = f"step_{len(steps) + 1}"
    steps.append({
        "step_id": inspect_step_id,
        "description": "Verify workbook content, columns, and records using openpyxl independent inspection.",
        "tool_name": "inspect_workbook",
        "input_params": {
            "file_path": f"outputs/opportunities_{task_id}.xlsx",
        },
        "dependencies": ["step_3"],
        "success_criteria": "Confirm 0 duplicate IDs, correct column headers, and non-empty record rows.",
        "requires_approval": False,
        "status": "PENDING",
    })

    # If the user explicitly asks to dispatch/send emails or requests approval gating
    if is_sensitive:
        gated_step_id = f"step_{len(steps) + 1}"
        steps.append({
            "step_id": gated_step_id,
            "description": "Transmit prepared internship application emails to employer recruiting channels.",
            "tool_name": "create_email_draft",
            "input_params": {
                "action": "PROPOSED_EXTERNAL_DISPATCH",
                "task_id": task_id,
            },
            "dependencies": [draft_step_id, inspect_step_id],
            "success_criteria": "Explicit human approval required before performing external email transmission.",
            "requires_approval": True,
            "status": "PENDING",
        })

    return {
        "task_id": task_id,
        "task_summary": "Multi-Tool Autonomous Research, Excel Compilation, and Artifact Generation Pipeline",
        "planner_source": "DETERMINISTIC_DEMO_PLANNER (Hackathon Demo Mode)",
        "goal": goal,
        "steps": steps,
    }


def generate_plan(goal: str, task_id: Optional[str] = None) -> Dict[str, Any]:
    """
    Main planning entry point.
    Uses Google GenAI SDK if GEMINI_API_KEY is available; otherwise falls back to deterministic planner.
    Always validates schema before returning.
    """
    tid = task_id or f"task_{uuid.uuid4().hex[:8]}"
    gemini_key = os.getenv("GEMINI_API_KEY", "").strip()

    if not gemini_key:
        plan = generate_deterministic_demo_plan(goal, tid)
        return validate_plan(plan)

    # Use official Google GenAI SDK
    try:
        from google import genai
        client = genai.Client(api_key=gemini_key)

        allowed_tools_str = ", ".join(sorted(list(ALLOWED_TOOLS)))
        prompt = f"""You are the AI Planning Engine for FlowPilot AI, an autonomous workflow operator.
Given the user goal below, produce a strictly valid JSON execution plan following this schema:

{{
  "task_id": "{tid}",
  "task_summary": "<One-sentence summary of the workflow>",
  "planner_source": "GEMINI_GENAI_LIVE",
  "goal": "{goal}",
  "steps": [
    {{
      "step_id": "step_1",
      "description": "<What this step accomplishes>",
      "tool_name": "<Must be exactly one of: {allowed_tools_str}>",
      "input_params": {{ "<key>": "<val>" }},
      "dependencies": [ "<step_id_of_previous_step>" ],
      "success_criteria": "<Measurable condition for success>",
      "requires_approval": false,
      "status": "PENDING"
    }}
  ]
}}

STRICT RULES:
1. ONLY use tools from this exact list: {allowed_tools_str}.
2. Never reference future steps in dependencies (no circular dependencies).
3. If an action involves sending external emails or submitting forms, set "requires_approval": true.
4. Output raw JSON only with NO markdown code fences.

User Goal:
{goal}
"""
        response = client.models.generate_content(
            model="gemini-2.5-flash",
            contents=prompt,
        )

        raw_text = response.text or ""
        # Clean potential markdown fences
        clean_text = re.sub(r"^```(?:json)?", "", raw_text.strip(), flags=re.MULTILINE)
        clean_text = re.sub(r"```$", "", clean_text.strip(), flags=re.MULTILINE).strip()

        plan_dict = json.loads(clean_text)
        plan_dict["task_id"] = tid
        plan_dict["planner_source"] = "GEMINI_GENAI_LIVE"
        return validate_plan(plan_dict)

    except Exception as e:
        # Fall back safely to demo planner if API call fails (rate limits, key invalid, etc.)
        fallback_plan = generate_deterministic_demo_plan(goal, tid)
        fallback_plan["planner_notice"] = f"Fell back to deterministic planner due to LLM error: {str(e)}"
        return validate_plan(fallback_plan)
