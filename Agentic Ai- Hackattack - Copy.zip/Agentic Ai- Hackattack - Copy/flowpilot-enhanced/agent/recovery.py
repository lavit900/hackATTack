"""
FlowPilot AI - Self-Healing Recovery Engine
Classifies errors, implements bounded exponential backoff, checks pre-retry artifact state,
and ensures idempotent recovery without duplicating completed work.
"""

import os
import time
from typing import Any, Dict, Optional, Tuple

import database
import tools.spreadsheet as spreadsheet_tools
import tools.email_drafts as email_tools

# Error classification definitions
RETRYABLE_ERROR_KEYWORDS = [
    "timeout",
    "simulateddisktimeouterror",
    "connection",
    "temporarily unavailable",
    "rate limit",
    "disk write lock",
    "ioerror",
    "network",
    "503",
    "429",
    "try again",
]

PERMANENT_ERROR_KEYWORDS = [
    "unknown tool",
    "forbidden",
    "invalid parameter",
    "planvalidationerror",
    "unauthorized",
    "401",
    "403",
    "syntaxerror",
    "typeerror",
]


class RecoveryEngine:
    def __init__(self, db_path: Optional[str] = None):
        self.db_path = db_path

    def classify_error(self, error: Any) -> Tuple[bool, str]:
        """
        Classifies an error as transient (retryable) or permanent.
        Returns (is_retryable: bool, reason: str).
        """
        err_str = str(error).lower()
        err_type = type(error).__name__.lower()

        # Check explicit permanent markers
        for kw in PERMANENT_ERROR_KEYWORDS:
            if kw in err_str or kw in err_type:
                return False, f"Permanent error detected ('{kw}'): Do not retry invalid inputs."

        # Check retryable markers
        for kw in RETRYABLE_ERROR_KEYWORDS:
            if kw in err_str or kw in err_type:
                return True, f"Transient recoverable error detected ('{kw}'): Eligible for bounded retry."

        # Default standard IO or generic operational exceptions to retryable once
        if isinstance(error, (IOError, OSError, ConnectionError, TimeoutError)):
            return True, f"Operational system exception ({type(error).__name__}): Eligible for retry."

        # Fallback to non-retryable if unknown to avoid infinite loops
        return False, f"Unclassified error ({type(error).__name__}): Marking non-retryable for safety."

    def calculate_backoff(self, attempt: int, base_delay: float = 0.5, max_delay: float = 4.0) -> float:
        """
        Bounded exponential backoff with ceiling.
        """
        delay = base_delay * (2 ** max(0, attempt - 1))
        return min(delay, max_delay)

    def check_pre_retry_artifacts(self, task_id: str, step: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        Critical edge case handler:
        If a tool finished writing its file and timed out before the agent received confirmation,
        inspect the actual filesystem before performing another write.
        If valid artifacts are already present, recover immediately without duplicate writes.
        """
        tool_name = step.get("tool_name")
        input_params = step.get("input_params", {})

        if tool_name == "save_opportunities":
            file_path = input_params.get("file_path") or spreadsheet_tools.get_default_spreadsheet_path(task_id)
            if os.path.exists(file_path):
                inspection = spreadsheet_tools.inspect_workbook(file_path)
                if inspection.get("is_valid") and inspection.get("total_records", 0) > 0:
                    return {
                        "recovered": True,
                        "reason": f"Workbook artifact already exists on disk at '{file_path}' with {inspection.get('total_records')} valid records. Recovered without duplicate writes.",
                        "result": {
                            "success": True,
                            "file_path": file_path,
                            "total_records": inspection.get("total_records"),
                            "recovered_from_disk": True,
                        }
                    }

        elif tool_name == "create_email_draft":
            target_dir = input_params.get("output_dir") or email_tools.get_default_drafts_dir(task_id)
            if os.path.exists(target_dir):
                drafts = email_tools.list_drafts(task_id=task_id, output_dir=target_dir)
                if drafts.get("count", 0) > 0:
                    return {
                        "recovered": True,
                        "reason": f"Draft artifacts already exist on disk in '{target_dir}' ({drafts.get('count')} drafts). Recovered without duplicate writes.",
                        "result": drafts
                    }

        return None

    def decide_recovery(
        self,
        task_id: str,
        step: Dict[str, Any],
        error: Exception,
    ) -> Dict[str, Any]:
        """
        Core decision engine for failures. Evaluates error type, attempts remaining,
        and disk artifact state.
        """
        step_id = step.get("step_id")
        current_attempts = step.get("attempt_count", 0)
        max_retries = step.get("max_retries", 3)

        # 1. Inspect on-disk artifacts first (did the previous run secretly succeed before timeout?)
        disk_recovery = self.check_pre_retry_artifacts(task_id, step)
        if disk_recovery:
            database.log_event(
                task_id=task_id,
                step_id=step_id,
                event_type="PRE_RETRY_RECOVERY",
                message=disk_recovery["reason"],
                details={"step_id": step_id, "disk_recovery": True},
                db_path=self.db_path,
            )
            return {
                "action": "RESOLVED_VIA_ARTIFACT_CHECK",
                "result": disk_recovery["result"],
                "reason": disk_recovery["reason"],
            }

        # 2. Classify error
        is_retryable, classification_reason = self.classify_error(error)

        # 3. Check attempt budget
        if is_retryable and current_attempts < max_retries:
            delay = self.calculate_backoff(current_attempts + 1)
            reason = f"Attempt {current_attempts + 1}/{max_retries} failed ({classification_reason}). Retrying in {delay:.1f}s."
            
            database.log_event(
                task_id=task_id,
                step_id=step_id,
                event_type="RETRY_SCHEDULED",
                message=reason,
                details={
                    "step_id": step_id,
                    "attempt": current_attempts + 1,
                    "max_retries": max_retries,
                    "delay_seconds": delay,
                    "error": str(error),
                },
                db_path=self.db_path,
            )

            return {
                "action": "RETRY",
                "delay_seconds": delay,
                "reason": reason,
            }
        else:
            # Permanent failure or retries exhausted
            exhausted_reason = f"Permanent failure or retries exhausted ({current_attempts}/{max_retries} attempts). Error: {str(error)}"
            
            database.log_event(
                task_id=task_id,
                step_id=step_id,
                event_type="RECOVERY_EXHAUSTED",
                message=exhausted_reason,
                details={
                    "step_id": step_id,
                    "attempts": current_attempts,
                    "max_retries": max_retries,
                    "is_retryable": is_retryable,
                    "error": str(error),
                },
                db_path=self.db_path,
            )

            return {
                "action": "FAIL",
                "delay_seconds": 0,
                "reason": exhausted_reason,
            }
