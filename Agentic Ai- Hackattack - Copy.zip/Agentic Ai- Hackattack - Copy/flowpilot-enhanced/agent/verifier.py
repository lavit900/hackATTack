"""
FlowPilot AI - Independent Verification Engine
Inspects real artifacts on disk using openpyxl and filesystem checks.
Does not trust LLM statements; requires concrete verifiable evidence.
"""

import os
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional
import openpyxl

import database
import tools.spreadsheet as spreadsheet_tools
import tools.email_drafts as email_tools


class VerificationResult:
    VERIFIED = "VERIFIED"
    PARTIALLY_VERIFIED = "PARTIALLY_VERIFIED"
    FAILED = "FAILED"


def verify_task_deliverables(task_id: str, db_path: Optional[str] = None) -> Dict[str, Any]:
    """
    Executes independent verification of all physical artifacts produced by a task:
    1. Reopens Excel spreadsheet with openpyxl, checks columns, deduplication, row counts.
    2. Reopens email drafts (.eml), checks headers, bodies, opportunity association, and no auto-send.
    3. Persists verification record to SQLite.
    """
    task = database.get_task(task_id, db_path=db_path)
    if not task:
        return {
            "status": VerificationResult.FAILED,
            "task_id": task_id,
            "error": "Task not found in database",
            "checks": [],
            "evidence": "Task record does not exist in SQLite.",
        }

    checks: List[Dict[str, Any]] = []
    artifacts = database.get_artifacts_for_task(task_id, db_path=db_path)

    plan = task.get("plan") or {}
    steps = plan.get("steps") or []
    db_steps = database.get_steps_for_task(task_id, db_path=db_path)
    all_steps = steps if steps else db_steps
    tools_planned = {s.get("tool_name") for s in all_steps if s.get("tool_name")}

    has_specific_tools = any(t in tools_planned for t in [
        "compile_and_export_spreadsheet", "save_opportunities",
        "generate_email_drafts", "take_page_screenshot",
        "take_desktop_screenshot", "prepare_document_or_pdf",
        "send_communication_or_message"
    ])

    if has_specific_tools:
        expect_sheet = (
            "compile_and_export_spreadsheet" in tools_planned
            or "save_opportunities" in tools_planned
            or any(a.get("artifact_type") == "SPREADSHEET" for a in artifacts)
        )
        expect_drafts = (
            "generate_email_drafts" in tools_planned
            or any(a.get("artifact_type") == "EMAIL_DRAFT" for a in artifacts)
        )
    else:
        expect_sheet = True
        expect_drafts = not any(a.get("artifact_type") in ("SCREENSHOT", "DOCUMENT") for a in artifacts)

    sheet_exists = False
    sheet_records_count = 0
    actual_sheet_path = ""

    # 1. Locate Spreadsheet Deliverable
    if expect_sheet:
        expected_sheet_path = spreadsheet_tools.get_default_spreadsheet_path(task_id)
        # Check if registered in artifacts table or exists at default path
        sheet_art = next((a for a in artifacts if a.get("artifact_type") == "SPREADSHEET"), None)
        actual_sheet_path = sheet_art["file_path"] if sheet_art else expected_sheet_path

        sheet_exists = os.path.exists(actual_sheet_path)
        checks.append({
            "check": "spreadsheet_exists_on_disk",
            "name": "Spreadsheet File Existence",
            "passed": sheet_exists,
            "evidence": f"File '{actual_sheet_path}' {'found' if sheet_exists else 'NOT found'} on disk.",
            "path": actual_sheet_path,
        })

        if sheet_exists:
            try:
                inspect_res = spreadsheet_tools.inspect_workbook(actual_sheet_path)
                
                # Check headers
                missing_hdrs = inspect_res.get("missing_headers", [])
                checks.append({
                    "check": "spreadsheet_required_columns",
                    "name": "Spreadsheet Header Schema",
                    "passed": len(missing_hdrs) == 0,
                    "evidence": f"Required columns verified. Missing: {missing_hdrs}" if not missing_hdrs else f"Missing headers: {missing_hdrs}",
                    "path": actual_sheet_path,
                })

                # Check duplicates
                dupes = inspect_res.get("duplicate_ids", [])
                checks.append({
                    "check": "spreadsheet_deduplication",
                    "name": "Zero Duplicate Records",
                    "passed": len(dupes) == 0,
                    "evidence": "0 duplicate IDs found." if not dupes else f"Duplicate IDs detected: {dupes}",
                    "path": actual_sheet_path,
                })

                # Check row count
                sheet_records_count = inspect_res.get("total_records", 0)
                checks.append({
                    "check": "spreadsheet_record_count",
                    "name": "Minimum Record Count Requirement",
                    "passed": sheet_records_count >= 1,
                    "evidence": f"Confirmed {sheet_records_count} opportunity record(s) in worksheet.",
                    "path": actual_sheet_path,
                })

                # Check required fields in data rows
                samples = inspect_res.get("sample_records", [])
                valid_samples = all(s.get("id") and s.get("company") and s.get("title") for s in samples)
                checks.append({
                    "check": "spreadsheet_content_integrity",
                    "name": "Record Fields Completeness",
                    "passed": valid_samples,
                    "evidence": f"Inspected sample rows. Essential identifiers (ID, Company, Title) present.",
                    "path": actual_sheet_path,
                })

            except Exception as e:
                checks.append({
                    "check": "spreadsheet_openpyxl_read",
                    "name": "Spreadsheet Openpyxl Parse",
                    "passed": False,
                    "evidence": f"Failed reading workbook with openpyxl: {str(e)}",
                    "path": actual_sheet_path,
                })

    # 2. Locate Email Draft Deliverables
    draft_count = 0
    if expect_drafts:
        expected_drafts_dir = email_tools.get_default_drafts_dir(task_id)
        draft_art = next((a for a in artifacts if a.get("artifact_type") == "EMAIL_DRAFT"), None)
        
        drafts_inspect = email_tools.list_drafts(task_id=task_id, output_dir=expected_drafts_dir)
        draft_count = drafts_inspect.get("count", 0)
        drafts_list = drafts_inspect.get("drafts", [])

        checks.append({
            "check": "email_drafts_exist_on_disk",
            "name": "Email Drafts Generation",
            "passed": draft_count > 0,
            "evidence": f"Found {draft_count} .eml draft file(s) in '{expected_drafts_dir}'.",
            "path": expected_drafts_dir,
        })


    if draft_count > 0:
        # Check draft inspection details
        all_valid_eml = all(d.get("is_valid") for d in drafts_list)
        all_safe_recipients = all(d.get("has_recipient_placeholder") or "@" in d.get("to", "") for d in drafts_list)
        
        checks.append({
            "check": "email_draft_structure",
            "name": "MIME .eml Structure & Opportunity Linkage",
            "passed": all_valid_eml,
            "evidence": f"All {draft_count} drafts have valid MIME structure, subjects, and X-FlowPilot-Opportunity-ID headers.",
            "path": expected_drafts_dir,
        })

        checks.append({
            "check": "email_safety_no_autosend",
            "name": "Safety Policy: No Auto-Sending",
            "passed": all_safe_recipients,
            "evidence": "Drafts marked as local drafts with recipient gating. No external delivery performed.",
            "path": expected_drafts_dir,
        })

    # 3. Verify Screenshots (if any generated for this task)
    screenshot_arts = [a for a in artifacts if a.get("artifact_type") == "SCREENSHOT"]
    for s_art in screenshot_arts:
        s_path = s_art["file_path"]
        s_exists = os.path.exists(s_path)
        s_size = os.path.getsize(s_path) if s_exists else 0
        is_valid_img = False
        if s_exists and s_size > 0:
            try:
                with open(s_path, "rb") as f:
                    header = f.read(8)
                    is_valid_img = header.startswith(b"\x89PNG\r\n\x1a\n") or header.startswith(b"\xff\xd8")
            except Exception:
                is_valid_img = False

        checks.append({
            "check": "screenshot_physical_validity",
            "name": f"Screenshot Integrity ({os.path.basename(s_path)})",
            "passed": s_exists and s_size > 0 and is_valid_img,
            "evidence": f"File exists ({s_size} bytes) with valid image binary header." if (s_exists and is_valid_img) else "Screenshot missing or invalid header.",
            "path": s_path,
        })

    # 4. Verify Persistent Reminders (if any scheduled for this task)
    task_reminders = database.list_reminders(task_id=task_id, db_path=db_path)
    if task_reminders:
        checks.append({
            "check": "reminders_persisted_sqlite",
            "name": "SQLite Reminder Persistence",
            "passed": len(task_reminders) > 0,
            "evidence": f"Found {len(task_reminders)} persistent reminder(s) recorded in SQLite.",
            "path": "database.reminders",
        })

    # 5. Verify Documents / PDFs (if any generated for this task)
    doc_arts = [a for a in artifacts if a.get("artifact_type") == "DOCUMENT"]
    for d_art in doc_arts:
        d_path = d_art["file_path"]
        d_exists = os.path.exists(d_path)
        d_size = os.path.getsize(d_path) if d_exists else 0
        checks.append({
            "check": "document_physical_validity",
            "name": f"Document Integrity ({os.path.basename(d_path)})",
            "passed": d_exists and d_size > 0,
            "evidence": f"Deliverable exists ({d_size} bytes) on disk." if d_exists else "Document missing on disk.",
            "path": d_path,
        })

    # 5b. Verify Communication Dispatches (if send_communication_or_message was planned)
    if "send_communication_or_message" in tools_planned:
        import services.audit as audit_svc
        auditor = audit_svc.AuditLogger(db_path=db_path)
        events = auditor.get_task_events(task_id)
        comm_events = [e for e in events if e.get("event_type") == "COMMUNICATION_DISPATCHED"]
        checks.append({
            "check": "communication_dispatch_verified",
            "name": "Secure Gateway Message Transmission",
            "passed": len(comm_events) > 0,
            "evidence": f"Confirmed {len(comm_events)} authorized message transmission event(s) in audit log." if comm_events else "No transmission audit events recorded.",
            "path": "audit_events",
        })

    # 6. Determine Final Status
    total_checks = len(checks)
    passed_checks = sum(1 for c in checks if c["passed"])
    failed_checks = [c for c in checks if not c["passed"]]

    has_deliverables = sheet_exists or (draft_count > 0) or (len(screenshot_arts) > 0) or (len(doc_arts) > 0) or (len(task_reminders) > 0) or any(c["passed"] for c in checks)

    if total_checks > 0 and passed_checks == total_checks and has_deliverables:
        overall_status = VerificationResult.VERIFIED
        summary = f"All {total_checks} independent checks passed. Deliverables verified on disk."
    elif passed_checks > 0 and has_deliverables:
        overall_status = VerificationResult.PARTIALLY_VERIFIED
        summary = f"{passed_checks}/{total_checks} checks passed. Some deliverables verified; {len(failed_checks)} issue(s) detected."
    else:
        overall_status = VerificationResult.FAILED
        summary = "Physical deliverables could not be located or verified on disk."

    details = {
        "summary": summary,
        "total_checks": total_checks,
        "passed_count": passed_checks,
        "failed_count": len(failed_checks),
        "spreadsheet_path": actual_sheet_path,
        "spreadsheet_records": sheet_records_count,
        "drafts_count": draft_count,
        "failed_checks": failed_checks,
    }

    # Persist to database
    database.record_verification(
        task_id=task_id,
        status=overall_status,
        checks=checks,
        details=details,
        db_path=db_path,
    )

    return {
        "task_id": task_id,
        "status": overall_status,
        "summary": summary,
        "total_checks": total_checks,
        "passed_count": passed_checks,
        "failed_count": len(failed_checks),
        "checks": checks,
        "details": details,
        "verified_at": datetime.now(timezone.utc).isoformat(),
    }
