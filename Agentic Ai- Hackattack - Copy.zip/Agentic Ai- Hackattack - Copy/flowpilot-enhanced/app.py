"""
FlowPilot AI - Flask Web API Server
Exposes REST endpoints for planning, execution, approvals, verification, and artifacts.
Serves the FlowPilot Operator Dashboard.
"""

import os
import sys
import uuid
import threading
from typing import Any, Dict, Optional
from flask import Flask, jsonify, request, send_from_directory, send_file, abort
from flask_cors import CORS
from dotenv import load_dotenv
import urllib.parse

import database
from agent.planner import generate_plan, PlanValidationError
from agent.executor import WorkflowExecutor
from agent.verifier import verify_task_deliverables
from mcp_client import MCPClient
import services.approval as approval_svc

load_dotenv()

# Initialize Database
database.init_db()

FRONTEND_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "frontend"))
STATIC_DIR = FRONTEND_DIR if os.path.exists(FRONTEND_DIR) else os.path.abspath(os.path.join(os.path.dirname(__file__), "static"))
app = Flask(__name__, static_folder=STATIC_DIR, static_url_path="")
CORS(app)

# Background executor instances
mcp_client = MCPClient()
executor = WorkflowExecutor(mcp_client=mcp_client)
approvals = approval_svc.ApprovalService()


# --- Static UI Serving ---

@app.route("/")
def index():
    return send_from_directory(STATIC_DIR, "index.html")


# --- System Health ---

@app.route("/api/health", methods=["GET"])
def health():
    db_ok = False
    try:
        conn = database.get_connection()
        conn.execute("SELECT 1").fetchone()
        conn.close()
        db_ok = True
    except Exception:
        db_ok = False

    gemini_key = os.getenv("GEMINI_API_KEY", "").strip()
    ai_mode = "LIVE_GEMINI" if gemini_key else "DETERMINISTIC_DEMO_MODE"

    return jsonify({
        "status": "healthy" if db_ok else "degraded",
        "service": "FlowPilot AI Operator",
        "database": "sqlite_connected" if db_ok else "error",
        "ai_engine": ai_mode,
        "mcp_server": "active",
        "version": "1.0.0",
    })


# --- Operator Authentication ---

@app.route("/api/auth/login", methods=["POST"])
def auth_login():
    data = request.get_json(silent=True) or {}
    operator_name = data.get("operator_name", "").strip() or "Operator Alpha"
    role = data.get("role", "").strip() or "Senior Autonomous Systems Engineer"
    api_key_override = data.get("api_key", "").strip()

    if api_key_override:
        os.environ["GEMINI_API_KEY"] = api_key_override

    session_id = f"sess_{uuid.uuid4().hex[:12]}"
    token = f"fp_token_{uuid.uuid4().hex[:16]}"

    return jsonify({
        "success": True,
        "token": token,
        "operator": {
            "name": operator_name,
            "role": role,
            "session_id": session_id,
            "permissions": ["PLAN_GENERATE", "EXECUTE_TOOL", "APPROVE_SENSITIVE", "FAULT_INJECT", "VERIFY_ARTIFACTS"],
            "ai_mode": "LIVE_GEMINI" if os.getenv("GEMINI_API_KEY") else "DETERMINISTIC_DEMO_MODE",
        },
        "message": f"Welcome back, {operator_name}. FlowPilot Operator Authorization Granted.",
    })


# --- Tools Discovery ---

@app.route("/api/tools", methods=["GET"])
def get_tools():
    try:
        tools = mcp_client.list_tools()
        return jsonify({
            "success": True,
            "count": len(tools),
            "tools": tools,
        })
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@app.route("/api/mcp/servers", methods=["GET"])
def get_mcp_servers():
    try:
        tools = mcp_client.list_tools()
        return jsonify({
            "success": True,
            "servers": [
                {
                    "name": "flowpilot-mcp-server",
                    "version": "2.0.0",
                    "transport": "stdio",
                    "protocol": "Model Context Protocol (MCP) 2.3",
                    "status": "CONNECTED",
                    "tool_count": len(tools),
                    "capabilities": ["tools", "resources", "prompts"],
                    "categories": [
                        "Web Research & Opportunities",
                        "Spreadsheet & Data Operations",
                        "Email & Outreach Communication",
                        "Browser Automation & Screenshots",
                        "Alarms & Persistent Scheduling",
                        "Student Placement & Interview Prep"
                    ],
                }
            ]
        })
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


# --- Task Planning & Creation ---

@app.route("/api/tasks", methods=["POST"])
def create_task():
    data = request.get_json(silent=True) or {}
    goal = data.get("goal", "").strip()
    if not goal:
        return jsonify({"success": False, "error": "Goal description cannot be empty."}), 400

    task_id = f"task_{uuid.uuid4().hex[:8]}"

    try:
        # Generate structured plan using AI planning engine
        plan = generate_plan(goal, task_id=task_id)
        task_summary = plan.get("task_summary", "Autonomous Execution Plan")

        # Persist task to database
        task = database.create_task(
            task_id=task_id,
            goal=goal,
            summary=task_summary,
            plan_json=import_json(plan),
        )

        # Persist each step
        for step in plan.get("steps", []):
            database.create_step(task_id, step)

        # Log audit event
        database.log_event(
            task_id=task_id,
            event_type="TASK_CREATED",
            message=f"Task initialized with goal: '{goal[:80]}...'",
            details={"task_summary": task_summary, "step_count": len(plan.get("steps", []))},
        )

        return jsonify({
            "success": True,
            "task_id": task_id,
            "task": task,
            "plan": plan,
        }), 201

    except PlanValidationError as e:
        return jsonify({"success": False, "error": f"Plan schema validation failed: {str(e)}"}), 422
    except Exception as e:
        return jsonify({"success": False, "error": f"Failed to plan task: {str(e)}"}), 500


# --- Task Query ---

@app.route("/api/tasks/<task_id>", methods=["GET"])
def get_task(task_id: str):
    task = database.get_task(task_id)
    if not task:
        return jsonify({"success": False, "error": "Task not found."}), 404

    steps = database.get_steps_for_task(task_id)
    pending_apprs = approvals.get_pending(task_id)
    verification = database.get_latest_verification(task_id)

    return jsonify({
        "success": True,
        "task": task,
        "steps": steps,
        "pending_approvals": pending_apprs,
        "verification": verification,
    })


@app.route("/api/tasks", methods=["GET"])
def list_tasks():
    tasks = database.list_tasks(limit=50)
    return jsonify({
        "success": True,
        "count": len(tasks),
        "tasks": tasks,
    })


# --- Task Execution ---

def _run_task_async(task_id: str):
    try:
        executor.run_task(task_id)
    except Exception as e:
        database.update_task_status(task_id, "FAILED", error_message=str(e))
        database.log_event(task_id, "UNCAUGHT_EXECUTION_ERROR", str(e))


@app.route("/api/tasks/<task_id>/run", methods=["POST"])
def run_task(task_id: str):
    task = database.get_task(task_id)
    if not task:
        return jsonify({"success": False, "error": "Task not found."}), 404

    # Run in background thread so API responds promptly, while client polls live timeline
    thread = threading.Thread(target=_run_task_async, args=(task_id,), daemon=True)
    thread.start()

    return jsonify({
        "success": True,
        "task_id": task_id,
        "status": "RUNNING",
        "message": "Task execution initiated.",
    })


@app.route("/api/tasks/<task_id>/resume", methods=["POST"])
def resume_task(task_id: str):
    task = database.get_task(task_id)
    if not task:
        return jsonify({"success": False, "error": "Task not found."}), 404

    thread = threading.Thread(target=_run_task_async, args=(task_id,), daemon=True)
    thread.start()

    return jsonify({
        "success": True,
        "task_id": task_id,
        "status": "RESUMED",
        "message": "Task execution resumed.",
    })


@app.route("/api/tasks/<task_id>/cancel", methods=["POST"])
def cancel_task(task_id: str):
    task = database.get_task(task_id)
    if not task:
        return jsonify({"success": False, "error": "Task not found."}), 404

    data = request.get_json(silent=True) or {}
    reason = data.get("reason", "Cancelled by human operator")
    database.cancel_task(task_id, reason=reason)
    database.log_event(
        task_id=task_id,
        event_type="TASK_CANCELLED",
        message=f"Mission cancelled: {reason}",
    )
    return jsonify({
        "success": True,
        "task_id": task_id,
        "status": "CANCELLED",
        "message": f"Task {task_id} has been cancelled.",
    })


# --- Audit Events & Logs ---

@app.route("/api/tasks/<task_id>/events", methods=["GET"])
@app.route("/api/tasks/<task_id>/logs", methods=["GET"])
def get_task_events(task_id: str):
    task = database.get_task(task_id)
    if not task:
        return jsonify({"success": False, "error": "Task not found."}), 404

    events = database.get_events_for_task(task_id)
    return jsonify({
        "success": True,
        "task_id": task_id,
        "count": len(events),
        "events": events,
    })


# --- Artifacts ---

@app.route("/api/artifacts", methods=["GET"])
def list_all_artifacts():
    limit = int(request.args.get("limit", 100))
    artifacts = database.list_all_artifacts(limit=limit)
    return jsonify({
        "success": True,
        "count": len(artifacts),
        "artifacts": artifacts,
    })


@app.route("/api/artifacts/<int:artifact_id>", methods=["GET"])
def get_single_artifact(artifact_id: int):
    art = database.get_artifact_by_id(artifact_id)
    if not art:
        return jsonify({"success": False, "error": "Artifact not found."}), 404
    return jsonify({
        "success": True,
        "artifact": art,
        "download_url": f"/api/artifacts/download?path={urllib.parse.quote(art['file_path'])}",
    })


@app.route("/api/tasks/<task_id>/artifacts", methods=["GET"])
def get_task_artifacts(task_id: str):
    task = database.get_task(task_id)
    if not task:
        return jsonify({"success": False, "error": "Task not found."}), 404

    artifacts = database.get_artifacts_for_task(task_id)
    return jsonify({
        "success": True,
        "task_id": task_id,
        "count": len(artifacts),
        "artifacts": artifacts,
    })


@app.route("/api/artifacts/download", methods=["GET"])
def download_artifact():
    raw_path = request.args.get("path", "").strip()
    if not raw_path:
        return jsonify({"error": "Path parameter required."}), 400

    out_dir = os.path.abspath(os.getenv("OUTPUT_DIR", "outputs"))
    full_path = os.path.abspath(raw_path)

    # Security check: Prevent path traversal outside configured OUTPUT_DIR
    if not full_path.startswith(out_dir):
        return jsonify({"error": "Access denied: Path traversal outside outputs directory forbidden."}), 403

    if not os.path.exists(full_path):
        return jsonify({"error": "Artifact file not found."}), 404

    return send_file(full_path, as_attachment=True)


# --- Verification ---

@app.route("/api/tasks/<task_id>/verification", methods=["GET"])
def get_task_verification(task_id: str):
    task = database.get_task(task_id)
    if not task:
        return jsonify({"success": False, "error": "Task not found."}), 404

    # Return latest or run on-demand
    ver = database.get_latest_verification(task_id)
    if not ver:
        ver = verify_task_deliverables(task_id)

    return jsonify({
        "success": True,
        "task_id": task_id,
        "verification": ver,
    })


# --- Human Approvals ---

@app.route("/api/tasks/<task_id>/approve", methods=["POST"])
def approve_task_direct(task_id: str):
    pending = approvals.get_pending(task_id)
    if not pending:
        return jsonify({"success": False, "error": "No pending approvals found for this task."}), 400
    approval_id = pending[0]["id"]
    return submit_approval(task_id, approval_id, decision_override="APPROVED")


@app.route("/api/tasks/<task_id>/reject", methods=["POST"])
def reject_task_direct(task_id: str):
    pending = approvals.get_pending(task_id)
    if not pending:
        return jsonify({"success": False, "error": "No pending approvals found for this task."}), 400
    approval_id = pending[0]["id"]
    return submit_approval(task_id, approval_id, decision_override="REJECTED")


@app.route("/api/tasks/<task_id>/approvals/<approval_id>", methods=["POST"])
def submit_approval(task_id: str, approval_id: str, decision_override: Optional[str] = None):
    data = request.get_json(silent=True) or {}
    decision = decision_override or data.get("decision", "").strip().upper()
    if decision not in ("APPROVED", "REJECTED"):
        return jsonify({"success": False, "error": "Decision must be 'APPROVED' or 'REJECTED'."}), 400

    appr = approvals.get_approval(approval_id)
    if not appr or appr["task_id"] != task_id:
        return jsonify({"success": False, "error": "Approval request not found."}), 404

    updated = approvals.record_decision(approval_id, decision)

    database.log_event(
        task_id=task_id,
        step_id=appr["step_id"],
        event_type=f"APPROVAL_{decision}",
        message=f"Human operator explicitly decided: {decision} for action '{appr['action_type']}'",
        details={"approval_id": approval_id, "decision": decision},
    )

    # Auto-resume execution if approved
    if decision == "APPROVED":
        thread = threading.Thread(target=_run_task_async, args=(task_id,), daemon=True)
        thread.start()

    return jsonify({
        "success": True,
        "approval": updated,
        "message": f"Approval decision '{decision}' recorded.",
    })


# --- Reminders & Scheduling ---

@app.route("/api/reminders", methods=["GET"])
def get_reminders():
    status = request.args.get("status")
    task_id = request.args.get("task_id")
    limit = int(request.args.get("limit", 100))
    reminders = database.list_reminders(status=status, task_id=task_id, limit=limit)
    return jsonify({
        "success": True,
        "count": len(reminders),
        "reminders": reminders,
    })


@app.route("/api/reminders", methods=["POST"])
def post_reminder():
    data = request.get_json(silent=True) or {}
    title = data.get("title", "").strip()
    due_at = str(data.get("due_at") or "").strip()
    if not title or not due_at:
        return jsonify({"success": False, "error": "Fields 'title' and 'due_at' are required."}), 400

    rem = database.create_reminder(
        title=title,
        due_at=due_at,
        recurrence=data.get("recurrence", "ONCE"),
        reminder_type=data.get("reminder_type", "GENERAL"),
        task_id=data.get("task_id"),
    )
    return jsonify({
        "success": True,
        "reminder": rem,
        "message": f"Reminder '{title}' scheduled for {due_at}.",
    }), 201


@app.route("/api/reminders/<reminder_id>", methods=["PATCH"])
def patch_reminder(reminder_id: str):
    data = request.get_json(silent=True) or {}
    updated = database.update_reminder(
        reminder_id=reminder_id,
        title=data.get("title"),
        due_at=data.get("due_at"),
        recurrence=data.get("recurrence"),
        status=data.get("status"),
    )
    if not updated:
        return jsonify({"success": False, "error": "Reminder not found."}), 404
    return jsonify({"success": True, "reminder": updated})


@app.route("/api/reminders/<reminder_id>", methods=["DELETE"])
def delete_reminder(reminder_id: str):
    ok = database.delete_reminder(reminder_id)
    if not ok:
        return jsonify({"success": False, "error": "Reminder not found."}), 404
    return jsonify({"success": True, "message": f"Reminder '{reminder_id}' deleted."})


# --- Fault Injection Controls ---

@app.route("/api/demo/fault-injection", methods=["POST"])
def configure_fault_injection():
    data = request.get_json(silent=True) or {}
    tool_name = data.get("tool_name", "save_opportunities")
    fail_count = int(data.get("fail_count", 1))
    task_id = data.get("task_id")
    enabled = bool(data.get("enabled", True))

    if not enabled:
        database.reset_fault_configs()
        return jsonify({
            "success": True,
            "message": "Fault injection disabled and cleared.",
        })

    database.arm_fault_injection(
        tool_name=tool_name,
        fail_count=fail_count,
        task_id=task_id,
    )

    return jsonify({
        "success": True,
        "message": f"Fault injection armed: '{tool_name}' will simulate 1 failure before succeeding on retry.",
        "config": {
            "tool_name": tool_name,
            "fail_count": fail_count,
            "task_id": task_id,
            "enabled": True,
        }
    })


def import_json(val: Any) -> str:
    import json
    return json.dumps(val)


if __name__ == "__main__":
    port = int(os.getenv("PORT", 5000))
    host = os.getenv("HOST", "127.0.0.1")
    print(f"FlowPilot AI API Server running at http://{host}:{port}")
    app.run(host=host, port=port, debug=False)
