"""
FlowPilot AI - SQLite Database Layer
Handles initialization, migrations, connection management, and parameterized data access.
"""

import os
import json
import sqlite3
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

DEFAULT_DB_PATH = os.getenv("DATABASE_PATH", "flowpilot.db")


def get_db_path(custom_path: Optional[str] = None) -> str:
    return custom_path or os.getenv("DATABASE_PATH", DEFAULT_DB_PATH)


def get_connection(db_path: Optional[str] = None) -> sqlite3.Connection:
    path = get_db_path(db_path)
    # Ensure directory exists if path includes folder
    folder = os.path.dirname(path)
    if folder and not os.path.exists(folder):
        os.makedirs(folder, exist_ok=True)
    conn = sqlite3.connect(path, timeout=30.0, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    return conn


def init_db(db_path: Optional[str] = None) -> None:
    """Initialize SQLite schema with all required tables and indexes."""
    conn = get_connection(db_path)
    try:
        with conn:
            conn.executescript("""
            CREATE TABLE IF NOT EXISTS tasks (
                id TEXT PRIMARY KEY,
                goal TEXT NOT NULL,
                summary TEXT,
                status TEXT NOT NULL,
                plan_json TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                completed_at TEXT,
                error_message TEXT
            );

            CREATE TABLE IF NOT EXISTS steps (
                id TEXT PRIMARY KEY,
                task_id TEXT NOT NULL,
                step_id TEXT NOT NULL,
                description TEXT NOT NULL,
                tool_name TEXT NOT NULL,
                input_params TEXT NOT NULL,
                dependencies TEXT NOT NULL,
                requires_approval INTEGER NOT NULL DEFAULT 0,
                status TEXT NOT NULL,
                attempt_count INTEGER NOT NULL DEFAULT 0,
                max_retries INTEGER NOT NULL DEFAULT 3,
                result_json TEXT,
                error_message TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE
            );

            CREATE TABLE IF NOT EXISTS events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task_id TEXT NOT NULL,
                step_id TEXT,
                event_type TEXT NOT NULL,
                message TEXT NOT NULL,
                details_json TEXT,
                created_at TEXT NOT NULL,
                FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE
            );

            CREATE TABLE IF NOT EXISTS artifacts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task_id TEXT NOT NULL,
                step_id TEXT,
                artifact_type TEXT NOT NULL,
                file_path TEXT NOT NULL,
                title TEXT NOT NULL,
                metadata_json TEXT,
                created_at TEXT NOT NULL,
                FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE
            );

            CREATE TABLE IF NOT EXISTS approvals (
                id TEXT PRIMARY KEY,
                task_id TEXT NOT NULL,
                step_id TEXT NOT NULL,
                action_type TEXT NOT NULL,
                description TEXT NOT NULL,
                risk_assessment TEXT NOT NULL,
                payload_json TEXT,
                status TEXT NOT NULL DEFAULT 'PENDING',
                user_decision TEXT,
                decided_at TEXT,
                created_at TEXT NOT NULL,
                FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE
            );

            CREATE TABLE IF NOT EXISTS verifications (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task_id TEXT NOT NULL,
                status TEXT NOT NULL,
                checks_json TEXT NOT NULL,
                details_json TEXT,
                verified_at TEXT NOT NULL,
                FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE
            );

            CREATE TABLE IF NOT EXISTS fault_configs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task_id TEXT,
                tool_name TEXT NOT NULL,
                fail_count INTEGER NOT NULL DEFAULT 1,
                current_failures INTEGER NOT NULL DEFAULT 0,
                error_type TEXT NOT NULL DEFAULT 'SimulatedDiskTimeoutError',
                enabled INTEGER NOT NULL DEFAULT 1
            );

            CREATE TABLE IF NOT EXISTS reminders (
                id TEXT PRIMARY KEY,
                task_id TEXT,
                title TEXT NOT NULL,
                due_at TEXT NOT NULL,
                recurrence TEXT NOT NULL DEFAULT 'ONCE',
                status TEXT NOT NULL DEFAULT 'PENDING',
                reminder_type TEXT NOT NULL DEFAULT 'GENERAL',
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE SET NULL
            );

            CREATE INDEX IF NOT EXISTS idx_steps_task_id ON steps(task_id);
            CREATE INDEX IF NOT EXISTS idx_events_task_id ON events(task_id);
            CREATE INDEX IF NOT EXISTS idx_artifacts_task_id ON artifacts(task_id);
            CREATE INDEX IF NOT EXISTS idx_approvals_task_id ON approvals(task_id);
            CREATE INDEX IF NOT EXISTS idx_verifications_task_id ON verifications(task_id);
            CREATE INDEX IF NOT EXISTS idx_reminders_status ON reminders(status);
            CREATE INDEX IF NOT EXISTS idx_reminders_task_id ON reminders(task_id);
            """)
    finally:
        conn.close()


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


# --- Task Operations ---

def create_task(task_id: str, goal: str, summary: str, plan_json: Optional[str] = None, db_path: Optional[str] = None) -> Dict[str, Any]:
    now = utc_now()
    conn = get_connection(db_path)
    try:
        with conn:
            conn.execute(
                """
                INSERT INTO tasks (id, goal, summary, status, plan_json, created_at, updated_at)
                VALUES (?, ?, ?, 'PENDING', ?, ?, ?)
                """,
                (task_id, goal, summary, plan_json, now, now)
            )
        return get_task(task_id, db_path)
    finally:
        conn.close()


def get_task(task_id: str, db_path: Optional[str] = None) -> Optional[Dict[str, Any]]:
    conn = get_connection(db_path)
    try:
        row = conn.execute("SELECT * FROM tasks WHERE id = ?", (task_id,)).fetchone()
        if not row:
            return None
        task = dict(row)
        if task.get("plan_json"):
            try:
                task["plan"] = json.loads(task["plan_json"])
            except Exception:
                task["plan"] = None
        else:
            task["plan"] = None
        return task
    finally:
        conn.close()


def update_task_status(task_id: str, status: str, error_message: Optional[str] = None, db_path: Optional[str] = None) -> None:
    now = utc_now()
    completed_at = now if status in ("SUCCEEDED", "FAILED") else None
    conn = get_connection(db_path)
    try:
        with conn:
            if completed_at:
                conn.execute(
                    """
                    UPDATE tasks
                    SET status = ?, error_message = ?, updated_at = ?, completed_at = COALESCE(completed_at, ?)
                    WHERE id = ?
                    """,
                    (status, error_message, now, completed_at, task_id)
                )
            else:
                conn.execute(
                    """
                    UPDATE tasks
                    SET status = ?, error_message = ?, updated_at = ?
                    WHERE id = ?
                    """,
                    (status, error_message, now, task_id)
                )
    finally:
        conn.close()


def list_tasks(limit: int = 50, db_path: Optional[str] = None) -> List[Dict[str, Any]]:
    conn = get_connection(db_path)
    try:
        rows = conn.execute("SELECT * FROM tasks ORDER BY created_at DESC LIMIT ?", (limit,)).fetchall()
        tasks = []
        for r in rows:
            t = dict(r)
            if t.get("plan_json"):
                try:
                    t["plan"] = json.loads(t["plan_json"])
                except Exception:
                    t["plan"] = None
            tasks.append(t)
        return tasks
    finally:
        conn.close()


# --- Step Operations ---

def create_step(task_id: str, step_data: Dict[str, Any], db_path: Optional[str] = None) -> None:
    now = utc_now()
    step_key = f"{task_id}:{step_data['step_id']}"
    result_val = step_data.get("result")
    result_str = json.dumps(result_val) if result_val is not None else step_data.get("result_json")
    conn = get_connection(db_path)
    try:
        with conn:
            conn.execute(
                """
                INSERT OR REPLACE INTO steps 
                (id, task_id, step_id, description, tool_name, input_params, dependencies, requires_approval, status, attempt_count, max_retries, result_json, error_message, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    step_key,
                    task_id,
                    step_data["step_id"],
                    step_data["description"],
                    step_data["tool_name"],
                    json.dumps(step_data.get("input_params", {})),
                    json.dumps(step_data.get("dependencies", [])),
                    1 if step_data.get("requires_approval") else 0,
                    step_data.get("status", "PENDING"),
                    step_data.get("attempt_count", 0),
                    step_data.get("max_retries", 3),
                    result_str,
                    step_data.get("error_message"),
                    now,
                    now,
                )
            )
    finally:
        conn.close()


def get_steps_for_task(task_id: str, db_path: Optional[str] = None) -> List[Dict[str, Any]]:
    conn = get_connection(db_path)
    try:
        rows = conn.execute("SELECT * FROM steps WHERE task_id = ? ORDER BY step_id ASC", (task_id,)).fetchall()
        result = []
        for r in rows:
            step = dict(r)
            step["input_params"] = json.loads(step["input_params"]) if step["input_params"] else {}
            step["dependencies"] = json.loads(step["dependencies"]) if step["dependencies"] else []
            step["result"] = json.loads(step["result_json"]) if step["result_json"] else None
            step["requires_approval"] = bool(step["requires_approval"])
            result.append(step)
        return result
    finally:
        conn.close()


def get_step(task_id: str, step_id: str, db_path: Optional[str] = None) -> Optional[Dict[str, Any]]:
    step_key = f"{task_id}:{step_id}"
    conn = get_connection(db_path)
    try:
        row = conn.execute("SELECT * FROM steps WHERE id = ?", (step_key,)).fetchone()
        if not row:
            return None
        step = dict(row)
        step["input_params"] = json.loads(step["input_params"]) if step["input_params"] else {}
        step["dependencies"] = json.loads(step["dependencies"]) if step["dependencies"] else []
        step["result"] = json.loads(step["result_json"]) if step["result_json"] else None
        step["requires_approval"] = bool(step["requires_approval"])
        return step
    finally:
        conn.close()


def update_step_status(
    task_id: str,
    step_id: str,
    status: str,
    result: Optional[Any] = None,
    error_message: Optional[str] = None,
    increment_attempt: bool = False,
    db_path: Optional[str] = None
) -> None:
    now = utc_now()
    step_key = f"{task_id}:{step_id}"
    result_str = json.dumps(result) if result is not None else None
    conn = get_connection(db_path)
    try:
        with conn:
            if increment_attempt:
                conn.execute(
                    """
                    UPDATE steps
                    SET status = ?, result_json = COALESCE(?, result_json), error_message = ?, 
                        attempt_count = attempt_count + 1, updated_at = ?
                    WHERE id = ?
                    """,
                    (status, result_str, error_message, now, step_key)
                )
            else:
                conn.execute(
                    """
                    UPDATE steps
                    SET status = ?, result_json = COALESCE(?, result_json), error_message = ?, updated_at = ?
                    WHERE id = ?
                    """,
                    (status, result_str, error_message, now, step_key)
                )
    finally:
        conn.close()


# --- Event Logging ---

def log_event(
    task_id: str,
    event_type: str,
    message: str,
    step_id: Optional[str] = None,
    details: Optional[Dict[str, Any]] = None,
    db_path: Optional[str] = None
) -> int:
    now = utc_now()
    details_str = json.dumps(details) if details is not None else None
    conn = get_connection(db_path)
    try:
        with conn:
            cur = conn.execute(
                """
                INSERT INTO events (task_id, step_id, event_type, message, details_json, created_at)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (task_id, step_id, event_type, message, details_str, now)
            )
            return cur.lastrowid
    finally:
        conn.close()


def get_events_for_task(task_id: str, db_path: Optional[str] = None) -> List[Dict[str, Any]]:
    conn = get_connection(db_path)
    try:
        rows = conn.execute(
            "SELECT * FROM events WHERE task_id = ? ORDER BY id ASC",
            (task_id,)
        ).fetchall()
        events = []
        for r in rows:
            e = dict(r)
            e["details"] = json.loads(e["details_json"]) if e["details_json"] else None
            events.append(e)
        return events
    finally:
        conn.close()


# --- Artifacts ---

def register_artifact(
    task_id: str,
    artifact_type: str,
    file_path: str,
    title: str,
    step_id: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
    db_path: Optional[str] = None
) -> int:
    now = utc_now()
    meta_str = json.dumps(metadata) if metadata is not None else None
    conn = get_connection(db_path)
    try:
        with conn:
            # Artifact-producing tools may register their output directly and the
            # workflow executor may register it again. Keep registration idempotent
            # for the same task/type/path so the UI does not show duplicate files.
            existing = conn.execute(
                "SELECT id, step_id FROM artifacts WHERE task_id = ? AND artifact_type = ? AND file_path = ? ORDER BY id LIMIT 1",
                (task_id, artifact_type, file_path),
            ).fetchone()
            if existing:
                conn.execute(
                    "UPDATE artifacts SET step_id = COALESCE(step_id, ?), title = ?, metadata_json = COALESCE(?, metadata_json) WHERE id = ?",
                    (step_id, title, meta_str, existing["id"]),
                )
                return existing["id"]
            cur = conn.execute(
                """
                INSERT INTO artifacts (task_id, step_id, artifact_type, file_path, title, metadata_json, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (task_id, step_id, artifact_type, file_path, title, meta_str, now)
            )
            return cur.lastrowid
    finally:
        conn.close()


def get_artifacts_for_task(task_id: str, db_path: Optional[str] = None) -> List[Dict[str, Any]]:
    conn = get_connection(db_path)
    try:
        rows = conn.execute(
            "SELECT * FROM artifacts WHERE task_id = ? ORDER BY id ASC",
            (task_id,)
        ).fetchall()
        artifacts = []
        for r in rows:
            a = dict(r)
            a["metadata"] = json.loads(a["metadata_json"]) if a["metadata_json"] else {}
            artifacts.append(a)
        return artifacts
    finally:
        conn.close()


# --- Approvals ---

def create_approval(
    approval_id: str,
    task_id: str,
    step_id: str,
    action_type: str,
    description: str,
    risk_assessment: str,
    payload: Optional[Dict[str, Any]] = None,
    db_path: Optional[str] = None
) -> Dict[str, Any]:
    now = utc_now()
    payload_str = json.dumps(payload) if payload else None
    conn = get_connection(db_path)
    try:
        with conn:
            conn.execute(
                """
                INSERT INTO approvals 
                (id, task_id, step_id, action_type, description, risk_assessment, payload_json, status, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, 'PENDING', ?)
                """,
                (approval_id, task_id, step_id, action_type, description, risk_assessment, payload_str, now)
            )
        return get_approval(approval_id, db_path)
    finally:
        conn.close()


def get_approval(approval_id: str, db_path: Optional[str] = None) -> Optional[Dict[str, Any]]:
    conn = get_connection(db_path)
    try:
        row = conn.execute("SELECT * FROM approvals WHERE id = ?", (approval_id,)).fetchone()
        if not row:
            return None
        appr = dict(row)
        appr["payload"] = json.loads(appr["payload_json"]) if appr["payload_json"] else {}
        return appr
    finally:
        conn.close()


def get_pending_approvals_for_task(task_id: str, db_path: Optional[str] = None) -> List[Dict[str, Any]]:
    conn = get_connection(db_path)
    try:
        rows = conn.execute(
            "SELECT * FROM approvals WHERE task_id = ? AND status = 'PENDING' ORDER BY created_at ASC",
            (task_id,)
        ).fetchall()
        approvals = []
        for r in rows:
            a = dict(r)
            a["payload"] = json.loads(a["payload_json"]) if a["payload_json"] else {}
            approvals.append(a)
        return approvals
    finally:
        conn.close()


def update_approval_decision(
    approval_id: str,
    decision: str,  # 'APPROVED' or 'REJECTED'
    db_path: Optional[str] = None
) -> Optional[Dict[str, Any]]:
    now = utc_now()
    status = "APPROVED" if decision.upper() == "APPROVED" else "REJECTED"
    conn = get_connection(db_path)
    try:
        with conn:
            conn.execute(
                """
                UPDATE approvals
                SET status = ?, user_decision = ?, decided_at = ?
                WHERE id = ?
                """,
                (status, decision.upper(), now, approval_id)
            )
        return get_approval(approval_id, db_path)
    finally:
        conn.close()


# --- Verifications ---

def record_verification(
    task_id: str,
    status: str,
    checks: List[Dict[str, Any]],
    details: Optional[Dict[str, Any]] = None,
    db_path: Optional[str] = None
) -> int:
    now = utc_now()
    checks_str = json.dumps(checks)
    details_str = json.dumps(details) if details else None
    conn = get_connection(db_path)
    try:
        with conn:
            cur = conn.execute(
                """
                INSERT INTO verifications (task_id, status, checks_json, details_json, verified_at)
                VALUES (?, ?, ?, ?, ?)
                """,
                (task_id, status, checks_str, details_str, now)
            )
            return cur.lastrowid
    finally:
        conn.close()


def get_latest_verification(task_id: str, db_path: Optional[str] = None) -> Optional[Dict[str, Any]]:
    conn = get_connection(db_path)
    try:
        row = conn.execute(
            "SELECT * FROM verifications WHERE task_id = ? ORDER BY id DESC LIMIT 1",
            (task_id,)
        ).fetchone()
        if not row:
            return None
        v = dict(row)
        v["checks"] = json.loads(v["checks_json"]) if v["checks_json"] else []
        v["details"] = json.loads(v["details_json"]) if v["details_json"] else {}
        if isinstance(v["details"], dict):
            for k in ("summary", "total_checks", "passed_count", "failed_count"):
                if k in v["details"]:
                    v[k] = v["details"][k]
        return v
    finally:
        conn.close()


# --- Fault Injection Controls ---

def arm_fault_injection(
    tool_name: str,
    fail_count: int = 1,
    task_id: Optional[str] = None,
    error_type: str = "SimulatedDiskTimeoutError",
    db_path: Optional[str] = None
) -> int:
    conn = get_connection(db_path)
    try:
        with conn:
            # Disable existing for same tool/task
            conn.execute(
                "DELETE FROM fault_configs WHERE tool_name = ? AND (task_id = ? OR task_id IS NULL)",
                (tool_name, task_id)
            )
            cur = conn.execute(
                """
                INSERT INTO fault_configs (task_id, tool_name, fail_count, current_failures, error_type, enabled)
                VALUES (?, ?, ?, 0, ?, 1)
                """,
                (task_id, tool_name, fail_count, error_type)
            )
            return cur.lastrowid
    finally:
        conn.close()


def check_and_trigger_fault(tool_name: str, task_id: Optional[str] = None, db_path: Optional[str] = None) -> Optional[str]:
    """
    Checks if a fault should be triggered. If enabled and failures < fail_count,
    increments current_failures and returns the error_type to simulate.
    Otherwise returns None.
    """
    conn = get_connection(db_path)
    try:
        with conn:
            row = conn.execute(
                """
                SELECT id, fail_count, current_failures, error_type
                FROM fault_configs
                WHERE tool_name = ? AND enabled = 1 AND (task_id = ? OR task_id IS NULL)
                ORDER BY id DESC LIMIT 1
                """,
                (tool_name, task_id)
            ).fetchone()
            if not row:
                return None
            fid, fail_count, cur_fails, err_type = row["id"], row["fail_count"], row["current_failures"], row["error_type"]
            if cur_fails < fail_count:
                conn.execute(
                    "UPDATE fault_configs SET current_failures = current_failures + 1 WHERE id = ?",
                    (fid,)
                )
                return err_type
            else:
                # Disarm once threshold met
                conn.execute("UPDATE fault_configs SET enabled = 0 WHERE id = ?", (fid,))
                return None
    finally:
        conn.close()


def reset_fault_configs(db_path: Optional[str] = None) -> None:
    conn = get_connection(db_path)
    try:
        with conn:
            conn.execute("DELETE FROM fault_configs")
    finally:
        conn.close()


# --- Reminders & Scheduling ---

def create_reminder(
    title: str,
    due_at: str,
    recurrence: str = "ONCE",
    reminder_type: str = "GENERAL",
    task_id: Optional[str] = None,
    reminder_id: Optional[str] = None,
    db_path: Optional[str] = None,
) -> Dict[str, Any]:
    rem_id = reminder_id or f"rem_{uuid.uuid4().hex[:8]}" if 'uuid' in globals() else f"rem_{os.urandom(4).hex()}"
    now = utc_now()
    conn = get_connection(db_path)
    try:
        with conn:
            conn.execute(
                """
                INSERT INTO reminders (id, task_id, title, due_at, recurrence, status, reminder_type, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, 'PENDING', ?, ?, ?)
                """,
                (rem_id, task_id, title, due_at, recurrence, reminder_type, now, now)
            )
            return {
                "id": rem_id,
                "task_id": task_id,
                "title": title,
                "due_at": due_at,
                "recurrence": recurrence,
                "status": "PENDING",
                "reminder_type": reminder_type,
                "created_at": now,
                "updated_at": now,
            }
    finally:
        conn.close()


def get_reminder(reminder_id: str, db_path: Optional[str] = None) -> Optional[Dict[str, Any]]:
    conn = get_connection(db_path)
    try:
        row = conn.execute("SELECT * FROM reminders WHERE id = ?", (reminder_id,)).fetchone()
        return dict(row) if row else None
    finally:
        conn.close()


def list_reminders(
    status: Optional[str] = None,
    task_id: Optional[str] = None,
    limit: int = 100,
    db_path: Optional[str] = None,
) -> List[Dict[str, Any]]:
    conn = get_connection(db_path)
    try:
        query = "SELECT * FROM reminders WHERE 1=1"
        params = []
        if status:
            query += " AND status = ?"
            params.append(status)
        if task_id:
            query += " AND task_id = ?"
            params.append(task_id)
        query += " ORDER BY due_at ASC LIMIT ?"
        params.append(limit)
        rows = conn.execute(query, tuple(params)).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def update_reminder(
    reminder_id: str,
    title: Optional[str] = None,
    due_at: Optional[str] = None,
    recurrence: Optional[str] = None,
    status: Optional[str] = None,
    db_path: Optional[str] = None,
) -> Optional[Dict[str, Any]]:
    conn = get_connection(db_path)
    try:
        with conn:
            existing = conn.execute("SELECT * FROM reminders WHERE id = ?", (reminder_id,)).fetchone()
            if not existing:
                return None
            fields = []
            params = []
            if title is not None:
                fields.append("title = ?")
                params.append(title)
            if due_at is not None:
                fields.append("due_at = ?")
                params.append(due_at)
            if recurrence is not None:
                fields.append("recurrence = ?")
                params.append(recurrence)
            if status is not None:
                fields.append("status = ?")
                params.append(status)
            fields.append("updated_at = ?")
            params.append(utc_now())
            params.append(reminder_id)
            conn.execute(f"UPDATE reminders SET {', '.join(fields)} WHERE id = ?", tuple(params))
            row = conn.execute("SELECT * FROM reminders WHERE id = ?", (reminder_id,)).fetchone()
            return dict(row) if row else None
    finally:
        conn.close()


def delete_reminder(reminder_id: str, db_path: Optional[str] = None) -> bool:
    conn = get_connection(db_path)
    try:
        with conn:
            cur = conn.execute("DELETE FROM reminders WHERE id = ?", (reminder_id,))
            return cur.rowcount > 0
    finally:
        conn.close()


# --- Task Cancellation ---

def cancel_task(task_id: str, reason: str = "Cancelled by operator", db_path: Optional[str] = None) -> bool:
    conn = get_connection(db_path)
    try:
        with conn:
            task = conn.execute("SELECT status FROM tasks WHERE id = ?", (task_id,)).fetchone()
            if not task:
                return False
            now = utc_now()
            conn.execute(
                "UPDATE tasks SET status = 'CANCELLED', error_message = ?, updated_at = ?, completed_at = ? WHERE id = ?",
                (reason, now, now, task_id)
            )
            # Mark running, pending, retrying or waiting steps as SKIPPED
            conn.execute(
                "UPDATE steps SET status = 'SKIPPED', updated_at = ? WHERE task_id = ? AND status IN ('PENDING', 'RUNNING', 'WAITING_FOR_APPROVAL', 'RETRYING')",
                (now, task_id)
            )
            return True
    finally:
        conn.close()


# --- Global Artifact Query Helpers ---

def get_artifact_by_id(artifact_id: int, db_path: Optional[str] = None) -> Optional[Dict[str, Any]]:
    conn = get_connection(db_path)
    try:
        row = conn.execute("SELECT * FROM artifacts WHERE id = ?", (artifact_id,)).fetchone()
        return dict(row) if row else None
    finally:
        conn.close()


def list_all_artifacts(limit: int = 100, db_path: Optional[str] = None) -> List[Dict[str, Any]]:
    conn = get_connection(db_path)
    try:
        rows = conn.execute("SELECT * FROM artifacts ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()

