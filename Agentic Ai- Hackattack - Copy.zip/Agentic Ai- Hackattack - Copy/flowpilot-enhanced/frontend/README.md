# FlowPilot AI — Frontend Workspace

This directory contains the complete, dedicated frontend source code for **FlowPilot AI**, styled in a modern, high-contrast **Red, Grey, and Blue** design system.

---

## 📁 File Structure

- **`index.html`**: Streamlined, hands-on user interface.
  - User login & profile without clutter or unnecessary API key inputs.
  - User-centric welcome hero explaining what FlowPilot does in clear, plain language.
  - Interactive **Mission Console** with 1-click presets and `🚀 Run Autonomous Mission`.
  - **Cancel Mission** button to halt active dependencies at any time.
  - **Verified Opportunities Grid** displaying live opportunity cards with 100% active, verified official career portal and direct application links (Google, Microsoft, ISRO, Amazon).
  - Deliverable cards for:
    - Excel spreadsheets (`.xlsx`)
    - Personalized email drafts (`.eml`)
    - High-resolution portal screenshot captures (`.png`) with instant inline preview
    - Physical disk verification certificate (`openpyxl`)
  - **Scheduled Deadlines & Reminders Modal** with persistent SQLite tracking.
  - Human Approval modal for sensitive actions.
  - Collapsible **Diagnostics Drawer** for judges and developers (14 MCP tools inspection & self-healing fault simulation).

- **`style.css`**: Professional **Red, Grey & Blue** design system:
  - **Grey Foundation**: Deep slate grey (`#0A0E17`, `#101623`, `#1E293B`, `#334155`) for high readability and reduced eye strain.
  - **Royal / Cobalt Blue (`#2563EB`, `#3B82F6`)**: Primary action buttons, interactive portals, and verified badges.
  - **Crimson / Scarlet Red (`#DC2626`, `#EF4444`)**: Direct apply buttons, status highlights, and operator gate safety modals.
  - Fully responsive on desktop and mobile.

- **`app.js`**: Vanilla JavaScript controller:
  - Manages session state (remembers user name and role).
  - Triggers asynchronous mission planning and live execution over Flask REST APIs.
  - Real-time polling with automatic extraction of verified opportunities.
  - Inline preview and download of screenshot deliverables.
  - Direct click handling for verified links (SSL & HTTP 200).
  - Handles human approvals, mission cancellation, self-healing recovery notifications, and deliverable downloads.
  - Complete reminder management (create, toggle complete, delete) synced with SQLite backend.

---

## 🚀 How to Run & Access

The Flask backend is configured to automatically serve this `frontend/` directory at:
```
http://127.0.0.1:5000
```

To modify or inspect styles and layouts, edit `frontend/index.html`, `frontend/style.css`, or `frontend/app.js`.
