/**
 * FlowPilot AI — Streamlined Red, Grey & Blue Operator Client
 * Connects frontend to Flask REST API, manages live autonomous workflow execution,
 * renders interactive opportunity cards with working links, handles human approvals,
 * and tracks independent openpyxl verification.
 */

const API_BASE = "";
let currentTaskId = null;
let completionHandledTaskId = null;
let currentPlan = null;
let pollInterval = null;
let isPolling = false;
let currentEvents = [];
const notifiedReminderIds = new Set();
let reminderPollInterval = null;

// --- DOM Elements ---

// Auth
const loginScreen = document.getElementById("loginScreen");
const loginForm = document.getElementById("loginForm");
const loginName = document.getElementById("loginName");
const loginRole = document.getElementById("loginRole");
const btnQuickDemoLogin = document.getElementById("btnQuickDemoLogin");
const navOperatorName = document.getElementById("navOperatorName");
const navOperatorRole = document.getElementById("navOperatorRole");
const navAvatar = document.getElementById("navAvatar");
const btnLogout = document.getElementById("btnLogout");

// Mission Console
const goalInput = document.getElementById("goalInput");
const btnPlan = document.getElementById("btnPlan");
const btnRunText = document.getElementById("btnRunText");
const btnPreviewPlan = document.getElementById("btnPreviewPlan");
const btnResumeTask = document.getElementById("btnResumeTask");
const planDrawer = document.getElementById("planDrawer");
const planSummaryBadge = document.getElementById("planSummaryBadge");
const planStepsGrid = document.getElementById("planStepsGrid");
const btnClosePlan = document.getElementById("btnClosePlan");

// Execution Status Banner
const executionBanner = document.getElementById("executionBanner");
const taskStatusBadge = document.getElementById("taskStatusBadge");
const bannerTitle = document.getElementById("bannerTitle");
const activeTaskIdBadge = document.getElementById("activeTaskIdBadge");
const btnCancelActiveTask = document.getElementById("btnCancelActiveTask");

// Recovery Console
const recoveryConsole = document.getElementById("recoveryConsole");
const recoveryErrorMsg = document.getElementById("recoveryErrorMsg");
const recoveryAttemptBadge = document.getElementById("recoveryAttemptBadge");

// Opportunities Grid & Files
const opportunitiesGrid = document.getElementById("opportunitiesGrid");
const oppCountBadge = document.getElementById("oppCountBadge");
const artifactCountBadge = document.getElementById("artifactCountBadge");
const excelFileName = document.getElementById("excelFileName");
const btnDownloadExcel = document.getElementById("btnDownloadExcel");
const draftsFileCount = document.getElementById("draftsFileCount");
const btnDownloadDrafts = document.getElementById("btnDownloadDrafts");
const screenshotFileName = document.getElementById("screenshotFileName");
const screenshotPreviewBox = document.getElementById("screenshotPreviewBox");
const screenshotImgPreview = document.getElementById("screenshotImgPreview");
const btnDownloadScreenshot = document.getElementById("btnDownloadScreenshot");
const pdfDeliverableBox = document.getElementById("pdfDeliverableBox");
const pdfFileName = document.getElementById("pdfFileName");
const btnDownloadPdf = document.getElementById("btnDownloadPdf");
const verifBadgeStatus = document.getElementById("verifBadgeStatus");
const verifSummaryText = document.getElementById("verifSummaryText");
const btnReverify = document.getElementById("btnReverify");
const stepsList = document.getElementById("stepsList");

// Reminders & Scheduling
const btnOpenReminders = document.getElementById("btnOpenReminders");
const navRemindersCount = document.getElementById("navRemindersCount");
const remindersModal = document.getElementById("remindersModal");
const btnCloseReminders = document.getElementById("btnCloseReminders");
const newReminderForm = document.getElementById("newReminderForm");
const remInputTitle = document.getElementById("remInputTitle");
const remInputDate = document.getElementById("remInputDate");
const remindersListContainer = document.getElementById("remindersListContainer");

// Diagnostics & Fault Injection
const btnToggleDiagnostics = document.getElementById("btnToggleDiagnostics");
const diagnosticsSection = document.getElementById("diagnosticsSection");
const faultInjectionToggle = document.getElementById("faultInjectionToggle");
const btnArmFaultDirect = document.getElementById("btnArmFaultDirect");
const btnClearFaults = document.getElementById("btnClearFaults");
const btnExportAuditJson = document.getElementById("btnExportAuditJson");

// Human Approval Modal
const approvalModal = document.getElementById("approvalModal");
const approvalDescription = document.getElementById("approvalDescription");
const approvalRisk = document.getElementById("approvalRisk");
const approvalPayloadJson = document.getElementById("approvalPayloadJson");
const btnApproveAction = document.getElementById("btnApproveAction");
const btnRejectApproval = document.getElementById("btnRejectApproval");
let activeApprovalId = null;

// History Modal
const btnOpenTaskHistory = document.getElementById("btnOpenTaskHistory");
const taskHistoryModal = document.getElementById("taskHistoryModal");
const btnCloseTaskHistory = document.getElementById("btnCloseTaskHistory");
const taskHistoryListContainer = document.getElementById("taskHistoryListContainer");

// --- Initialization ---

window.addEventListener("DOMContentLoaded", () => {
  initAuth();
  setupPresets();
  setupEventListeners();
  fetchReminders();
  if (!reminderPollInterval) reminderPollInterval = window.setInterval(fetchReminders, 15000);
});

// --- Authentication ---

function initAuth() {
  const savedName = localStorage.getItem("flowpilot_op_name") || "Samridh";
  const savedRole = localStorage.getItem("flowpilot_op_role") || "3rd Year CS Student";
  const sessionActive = localStorage.getItem("flowpilot_session_active");

  loginName.value = savedName;
  loginRole.value = savedRole;

  if (sessionActive === "true") {
    applyUserSession(savedName, savedRole);
    loginScreen.classList.add("hidden");
  } else {
    loginScreen.classList.remove("hidden");
  }

  loginForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const name = loginName.value.trim() || "Samridh";
    const role = loginRole.value.trim() || "CS Student";
    localStorage.setItem("flowpilot_op_name", name);
    localStorage.setItem("flowpilot_op_role", role);
    localStorage.setItem("flowpilot_session_active", "true");
    applyUserSession(name, role);
    loginScreen.classList.add("hidden");
  });

  btnQuickDemoLogin.addEventListener("click", () => {
    const name = "Samridh";
    const role = "3rd Year CS Student";
    localStorage.setItem("flowpilot_op_name", name);
    localStorage.setItem("flowpilot_op_role", role);
    localStorage.setItem("flowpilot_session_active", "true");
    applyUserSession(name, role);
    loginScreen.classList.add("hidden");
  });

  btnLogout.addEventListener("click", () => {
    localStorage.removeItem("flowpilot_session_active");
    loginScreen.classList.remove("hidden");
  });
}

function applyUserSession(name, role) {
  navOperatorName.textContent = name;
  navOperatorRole.textContent = role;
  navAvatar.textContent = name.substring(0, 2).toUpperCase();
}

// --- Preset Missions ---

function setupPresets() {
  const chips = document.querySelectorAll(".preset-chip");
  chips.forEach((chip) => {
    chip.addEventListener("click", () => {
      chips.forEach((c) => c.classList.remove("chip-active"));
      chip.classList.add("chip-active");
      const goal = chip.getAttribute("data-goal");
      goalInput.value = goal;
    });
  });
}

// --- Event Listeners ---

function setupEventListeners() {
  btnPlan.addEventListener("click", handleRunMission);
  btnPreviewPlan.addEventListener("click", handleInspectPlan);
  btnClosePlan.addEventListener("click", () => planDrawer.classList.add("hidden"));
  btnResumeTask.addEventListener("click", handleResumeTask);
  btnReverify.addEventListener("click", handleTriggerReverify);

  // Diagnostics toggle
  btnToggleDiagnostics.addEventListener("click", () => {
    diagnosticsSection.classList.toggle("hidden");
    if (!diagnosticsSection.classList.contains("hidden")) {
      diagnosticsSection.scrollIntoView({ behavior: "smooth" });
    }
  });

  // Fault Injection
  faultInjectionToggle.addEventListener("change", (e) => setFaultInjection(e.target.checked));
  btnArmFaultDirect.addEventListener("click", () => setFaultInjection(true));
  btnClearFaults.addEventListener("click", () => setFaultInjection(false));
  btnExportAuditJson.addEventListener("click", exportAuditJson);

  // Approvals
  btnApproveAction.addEventListener("click", () => submitApprovalDecision("APPROVED"));
  btnRejectApproval.addEventListener("click", () => submitApprovalDecision("REJECTED"));

  // Task History
  btnOpenTaskHistory.addEventListener("click", openTaskHistory);
  btnCloseTaskHistory.addEventListener("click", () => taskHistoryModal.classList.add("hidden"));

  // Task Cancellation
  if (btnCancelActiveTask) {
    btnCancelActiveTask.addEventListener("click", handleCancelMission);
  }

  // Reminders Modal
  if (btnOpenReminders) {
    btnOpenReminders.addEventListener("click", () => {
      remindersModal.classList.remove("hidden");
      fetchReminders();
    });
  }
  if (btnCloseReminders) {
    btnCloseReminders.addEventListener("click", () => {
      remindersModal.classList.add("hidden");
    });
  }
  if (newReminderForm) {
    newReminderForm.addEventListener("submit", handleCreateReminder);
  }
}

// --- Autonomous Mission Execution (1-Click Run) ---

async function handleRunMission() {
  const goal = goalInput.value.trim();
  if (!goal) {
    alert("Please enter a mission goal first.");
    goalInput.focus();
    return;
  }

  btnPlan.disabled = true;
  btnRunText.textContent = "Synthesizing Plan...";
  taskStatusBadge.textContent = "PLANNING";
  taskStatusBadge.className = "status-badge status-RUNNING";
  bannerTitle.textContent = "AI Planner generating structured dependency graph...";

  // Clear previous mission outputs for clean state
  opportunitiesGrid.innerHTML = "";
  oppCountBadge.textContent = "0 Opportunities";
  artifactCountBadge.textContent = "0 Files";
  if (screenshotPreviewBox) {
    screenshotPreviewBox.style.display = "none";
  }
  if (screenshotImgPreview) {
    screenshotImgPreview.src = "";
  }
  screenshotFileName.textContent = "Not requested";
  btnDownloadScreenshot.classList.add("disabled");
  if (pdfDeliverableBox) pdfDeliverableBox.style.display = "none";
  if (btnDownloadPdf) btnDownloadPdf.classList.add("disabled");
  excelFileName.textContent = "Not requested";
  btnDownloadExcel.classList.add("disabled");
  draftsFileCount.textContent = "Not requested";
  btnDownloadDrafts.classList.add("disabled");
  verifBadgeStatus.textContent = "Awaiting Verification";
  verifSummaryText.textContent = "Independent verification will run after deliverable generation.";
  stepsList.innerHTML = "<div style='font-size:0.85rem; color:var(--grey-400); padding:0.5rem 0;'>Operator synthesizing plan and executing dependencies...</div>";

  try {
    // 1. Create & Plan Task
    const res = await fetch(`${API_BASE}/api/tasks`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ goal }),
    });

    const data = await res.json();
    if (!data.success) {
      alert(`Planning error: ${data.error}`);
      resetButton();
      return;
    }

    currentTaskId = data.task_id;
    currentPlan = data.plan;
    activeTaskIdBadge.textContent = currentTaskId;
    setArtifactPlaceholders(data.plan.steps || []);

    renderPlanDrawer(data.plan);
    renderSteps(data.plan.steps || []);

    // 2. Immediately Run Execution Loop
    btnRunText.textContent = "Executing Mission...";
    bannerTitle.textContent = "Mission running autonomously...";

    const execRes = await fetch(`${API_BASE}/api/tasks/${currentTaskId}/run`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
    });

    const execData = await execRes.json();
    if (!execData.success) {
      alert(`Execution start error: ${execData.error}`);
      resetButton();
      return;
    }

    // Start live polling loop
    startPolling();

  } catch (err) {
    alert(`Failed to execute mission: ${err.message}`);
    resetButton();
  }
}

function setArtifactPlaceholders(steps) {
  const tools = new Set((steps || []).map((step) => step.tool_name));
  const wantsScreenshot = tools.has("take_page_screenshot") || tools.has("take_desktop_screenshot");
  const wantsSpreadsheet = tools.has("save_opportunities") || tools.has("inspect_workbook");
  const wantsDrafts = tools.has("create_email_draft") || tools.has("list_drafts");
  const wantsPdf = tools.has("prepare_document_or_pdf");

  screenshotFileName.textContent = wantsScreenshot ? "Capture queued" : "Not requested";
  excelFileName.textContent = wantsSpreadsheet ? "Workbook queued" : "Not requested";
  draftsFileCount.textContent = wantsDrafts ? "Drafts queued" : "Not requested";
  if (pdfFileName) pdfFileName.textContent = wantsPdf ? "Document queued" : "Not requested";
}

function resetButton() {
  btnPlan.disabled = false;
  btnRunText.textContent = "🚀 Run Autonomous Mission";
}

// --- Inspect Plan Only ---

async function handleInspectPlan() {
  const goal = goalInput.value.trim();
  if (!goal) {
    alert("Please enter a mission goal first.");
    return;
  }

  btnPreviewPlan.disabled = true;
  btnPreviewPlan.textContent = "Planning...";

  try {
    const res = await fetch(`${API_BASE}/api/tasks`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ goal }),
    });

    const data = await res.json();
    if (!data.success) {
      alert(`Planning error: ${data.error}`);
      return;
    }

    currentTaskId = data.task_id;
    currentPlan = data.plan;
    activeTaskIdBadge.textContent = currentTaskId;

    renderPlanDrawer(data.plan);
    planDrawer.classList.remove("hidden");
    renderSteps(data.plan.steps || []);
    taskStatusBadge.textContent = "PLAN READY";
    taskStatusBadge.className = "status-badge status-PENDING";
    bannerTitle.textContent = `Plan synthesized: ${data.plan.task_summary}`;

  } catch (e) {
    alert(`Failed to preview plan: ${e.message}`);
  } finally {
    btnPreviewPlan.disabled = false;
    btnPreviewPlan.innerHTML = `
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline></svg>
      <span>Inspect Plan</span>
    `;
  }
}

function renderPlanDrawer(plan) {
  planSummaryBadge.textContent = `${plan.steps?.length || 0} Steps Generated`;
  planStepsGrid.innerHTML = "";

  (plan.steps || []).forEach((step, idx) => {
    const item = document.createElement("div");
    item.className = "plan-step-item";
    item.innerHTML = `
      <div class="plan-step-left">
        <span class="plan-step-idx">Step ${idx + 1}</span>
        <span class="plan-step-text">${step.description}</span>
      </div>
      <span class="plan-step-tool">${step.tool_name}()</span>
    `;
    planStepsGrid.appendChild(item);
  });
}

// --- Live Polling Engine ---

function startPolling() {
  if (isPolling) return;
  isPolling = true;
  pollTask();
  pollInterval = setInterval(pollTask, 1200);
}

function stopPolling() {
  if (pollInterval) {
    clearInterval(pollInterval);
    pollInterval = null;
  }
  isPolling = false;
  resetButton();
}

async function pollTask() {
  if (!currentTaskId) return;

  try {
    const [taskRes, eventsRes, artRes, verRes] = await Promise.all([
      fetch(`${API_BASE}/api/tasks/${currentTaskId}`).then((r) => r.json()),
      fetch(`${API_BASE}/api/tasks/${currentTaskId}/events`).then((r) => r.json()),
      fetch(`${API_BASE}/api/tasks/${currentTaskId}/artifacts`).then((r) => r.json()),
      fetch(`${API_BASE}/api/tasks/${currentTaskId}/verification`).then((r) => r.json()),
    ]);

    if (taskRes.success) {
      updateTaskState(taskRes);
    }
    if (eventsRes.success) {
      currentEvents = eventsRes.events || [];
    }
    if (artRes.success) {
      updateArtifacts(artRes.artifacts || []);
    }
    if (verRes.success) {
      updateVerification(verRes.verification);
    }
  } catch (err) {
    console.error("Polling error:", err);
  }
}

// --- UI State Management ---

function updateTaskState(data) {
  const task = data.task;
  const steps = data.steps || [];
  const pendingApprovals = data.pending_approvals || [];

  taskStatusBadge.textContent = task.status;
  taskStatusBadge.className = `status-badge status-${task.status}`;

  if (task.status === "RUNNING") {
    bannerTitle.textContent = "FlowPilot operator actively executing dependencies...";
    if (btnCancelActiveTask) btnCancelActiveTask.classList.remove("hidden");
  } else if (task.status === "SUCCEEDED") {
    bannerTitle.textContent = "Mission completed. Review your results below.";
    if (btnCancelActiveTask) btnCancelActiveTask.classList.add("hidden");
    stopPolling();
    if (completionHandledTaskId !== task.id) {
      completionHandledTaskId = task.id;
      // Move the user's focus to the result cards and clear the completed prompt.
      window.setTimeout(() => {
        const resultsTarget = document.getElementById("opportunitiesGrid");
        if (resultsTarget) resultsTarget.scrollIntoView({ behavior: "smooth", block: "start" });
        if (goalInput) goalInput.value = "";
      }, 150);
    }
  } else if (task.status === "FAILED") {
    bannerTitle.textContent = `Mission Halted: ${task.error_message || "Encountered issue."}`;
    if (btnCancelActiveTask) btnCancelActiveTask.classList.add("hidden");
    stopPolling();
  } else if (task.status === "CANCELLED") {
    bannerTitle.textContent = "Mission Cancelled by Operator. Active steps halted.";
    if (btnCancelActiveTask) btnCancelActiveTask.classList.add("hidden");
    stopPolling();
  } else if (task.status === "WAITING_FOR_APPROVAL") {
    bannerTitle.textContent = "Mission Paused: Operator approval required before external action.";
    if (btnCancelActiveTask) btnCancelActiveTask.classList.remove("hidden");
  } else {
    if (btnCancelActiveTask) btnCancelActiveTask.classList.add("hidden");
  }

  // Render Steps
  renderSteps(steps);

  // Extract Opportunities from Step 1 or Step 3 result
  extractAndRenderOpportunities(steps);

  // Self-Healing Recovery detection
  const retryingStep = steps.find((s) => s.status === "RETRYING" || s.attempt_count > 1);
  if (retryingStep && (retryingStep.status === "RETRYING" || retryingStep.error_message)) {
    recoveryConsole.classList.remove("hidden");
    recoveryAttemptBadge.textContent = `Attempt ${retryingStep.attempt_count}/${retryingStep.max_retries}`;
    recoveryErrorMsg.textContent = retryingStep.error_message || "Transient disk lock encountered. Initiating bounded retry.";
  } else {
    recoveryConsole.classList.add("hidden");
  }

  // Check for Human Approval Modal
  if (pendingApprovals.length > 0 && task.status === "WAITING_FOR_APPROVAL") {
    showApprovalModal(pendingApprovals[0]);
    btnResumeTask.classList.remove("hidden");
  } else {
    approvalModal.classList.add("hidden");
  }
}

// --- Render Opportunities Cards with 100% Live Working URLs ---

function extractAndRenderOpportunities(steps) {
  let opps = null;
  let commResult = null;
  let docResult = null;
  let ssResult = null;

  // Check step results
  for (const step of steps) {
    if (step.result && step.result.opportunities && Array.isArray(step.result.opportunities)) {
      opps = step.result.opportunities;
      break;
    }
    if (step.result && (step.tool_name === "send_communication_or_message" || step.result.channel)) {
      commResult = step.result;
    }
    if (step.result && (step.tool_name === "prepare_document_or_pdf" || step.result.title)) {
      docResult = step.result;
    }
    if (step.result && (step.tool_name === "take_page_screenshot" || step.tool_name === "take_desktop_screenshot")) {
      ssResult = step.result;
    }
  }

  // 1. Opportunities Flow
  if (opps && opps.length > 0) {
    oppCountBadge.textContent = `${opps.length} Opportunities`;
    opportunitiesGrid.innerHTML = "";

    opps.forEach((opp) => {
      const card = document.createElement("div");
      card.className = "opp-card";
      if (opp.company.toLowerCase().includes("isro")) {
        card.classList.add("opp-isro");
      }

      const sourceUrl = opp.source_url || "https://careers.google.com/students/";
      const applyUrl = opp.application_url || "https://www.google.com/about/careers/applications/jobs/results/?q=intern";

      card.innerHTML = `
        <div>
          <div class="opp-header">
            <div>
              <div class="opp-company">${opp.company}</div>
              <h4 class="opp-title">${opp.title}</h4>
            </div>
            <span class="opp-badge-verif">✓ SSL Verified</span>
          </div>

          <div class="opp-meta-list">
            <div class="opp-meta-row">
              <strong>Location:</strong>
              <span>${opp.location}</span>
            </div>
            <div class="opp-meta-row">
              <strong>Eligibility:</strong>
              <span>${opp.eligibility}</span>
            </div>
            <div class="opp-meta-row">
              <strong>Deadline:</strong>
              <span style="color:var(--red-400); font-weight:700;">${opp.deadline}</span>
            </div>
          </div>

          <div class="opp-skills-box">
            <strong>Key Skills Required:</strong>
            <span>${opp.skills}</span>
          </div>
        </div>

        <div class="opp-actions-bar">
          <a href="${sourceUrl}" target="_blank" rel="noopener noreferrer" class="btn-live-portal" title="Open official student careers portal">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="2" y1="12" x2="22" y2="12"></line><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path></svg>
            <span>Official Portal</span>
          </a>
          <a href="${applyUrl}" target="_blank" rel="noopener noreferrer" class="btn-apply-direct" title="Open direct application listings">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path><polyline points="15 3 21 3 21 9"></polyline><line x1="10" y1="14" x2="21" y2="3"></line></svg>
            <span>Direct Apply</span>
          </a>
        </div>
      `;

      opportunitiesGrid.appendChild(card);
    });
    return;
  }

  // 2. Communication Dispatch Flow (e.g. WhatsApp, Email, Slack PDF dispatch)
  if (commResult || docResult) {
    oppCountBadge.textContent = "1 Communication Dispatch";
    const channelName = (commResult?.channel || "WHATSAPP").toUpperCase();
    const recipientName = commResult?.recipient || docResult?.recipient || "Specified Contact";
    const statusText = commResult?.status || "NOT_SENT";
    const communicationActionUrl = commResult?.action_url || "";
    const communicationNote = commResult?.note || commResult?.error || "No external delivery provider is configured.";
    const deliveredAt = commResult?.delivered_at || new Date().toLocaleString();
    const messagePreview = commResult?.message_preview || "Document deliverable prepared and authorized for dispatch.";
    const docTitle = docResult?.title || "FlowPilot Prepared Document";
    const docSize = docResult?.file_size ? `${Math.round(docResult.file_size / 1024)} KB` : "PDF Ready";

    opportunitiesGrid.innerHTML = `
      <div class="opp-card" style="grid-column: 1/-1; border-left: 4px solid var(--blue-500); background: linear-gradient(145deg, #161b26 0%, #0e121a 100%); padding: 1.5rem;">
        <div class="opp-header">
          <div>
            <div class="opp-company" style="color:var(--blue-400); font-size:0.8rem; text-transform:uppercase; letter-spacing:0.06em; font-weight:700;">
              Communication Status
            </div>
            <h4 class="opp-title" style="font-size:1.15rem; margin-top:0.25rem;">
              ${channelName} Document Transmission to ${recipientName}
            </h4>
          </div>
          <span class="opp-badge-verif" style="background:rgba(59, 130, 246, 0.15); color:var(--blue-400); border-color:rgba(59, 130, 246, 0.3);">
            ${statusText === "READY_TO_SEND" ? "Ready for your confirmation" : statusText}
          </span>
        </div>

        <div class="opp-meta-list" style="margin-top:1rem;">
          <div class="opp-meta-row">
            <strong>Target Channel:</strong>
            <span style="color:var(--blue-400); font-weight:700;">${channelName}</span>
          </div>
          <div class="opp-meta-row">
            <strong>Recipient:</strong>
            <span style="font-weight:600; color:var(--grey-100);">${recipientName}</span>
          </div>
          <div class="opp-meta-row">
            <strong>Delivery Status:</strong>
            <span style="color:${statusText === "READY_TO_SEND" ? "var(--amber-500)" : statusText === "DELIVERED" ? "var(--green-500)" : "var(--red-400)"}; font-weight:700;">${statusText}</span>
          </div>
          ${docResult ? `
          <div class="opp-meta-row">
            <strong>Attached PDF:</strong>
            <span style="color:var(--grey-200); font-family:monospace;">${docTitle}.pdf (${docSize})</span>
          </div>
          ` : ""}
          <div class="opp-meta-row">
            <strong>Dispatched At:</strong>
            <span>${deliveredAt}</span>
          </div>
        </div>

        <div class="opp-skills-box" style="margin-top:1rem; background:rgba(0,0,0,0.3); border:1px solid rgba(255,255,255,0.06); padding:0.75rem 1rem; border-radius:6px;">
          <strong style="display:block; margin-bottom:0.25rem; color:var(--grey-300);">Message Preview:</strong>
          <span style="color:var(--grey-400); font-style:italic;">"${messagePreview}"</span>
          <p style="margin-top:.6rem;color:var(--grey-300);">${communicationNote}</p>
          ${communicationActionUrl ? `<a class="btn-live-portal" href="${communicationActionUrl}" target="_blank" rel="noopener noreferrer" style="display:inline-flex;margin-top:.6rem;">Open ${channelName} to review and send</a>` : ""}
        </div>
      </div>
    `;
    return;
  }

  // 3. Screenshot Capture Flow
  if (ssResult) {
    oppCountBadge.textContent = "1 Screenshot Captured";
    const ssUrl = ssResult.url || "Frontend Application (http://127.0.0.1:5000)";
    opportunitiesGrid.innerHTML = `
      <div class="opp-card" style="grid-column: 1/-1; border-left: 4px solid var(--blue-500); background: linear-gradient(145deg, #161b26 0%, #0e121a 100%); padding: 1.5rem;">
        <div class="opp-header">
          <div>
            <div class="opp-company" style="color:var(--blue-400); font-size:0.8rem; text-transform:uppercase; letter-spacing:0.06em; font-weight:700;">
              Real Browser Screenshot Captured
            </div>
            <h4 class="opp-title" style="font-size:1.15rem; margin-top:0.25rem;">
              Browser Viewport Snapshot
            </h4>
          </div>
          <span class="opp-badge-verif">✓ Browser Capture</span>
        </div>

        <div class="opp-meta-list" style="margin-top:1rem;">
          <div class="opp-meta-row">
            <strong>Captured Target:</strong>
            <span style="color:var(--grey-100); font-weight:600;">${ssUrl}</span>
          </div>
          <div class="opp-meta-row">
            <strong>Resolution:</strong>
            <span>${ssResult.resolution || ssResult.dimensions || "Reported by browser"}</span>
          </div>
          <div class="opp-meta-row">
            <strong>Artifact Path:</strong>
            <span style="font-family:monospace; color:var(--grey-300);">${ssResult.file_path || "outputs/screenshots/..."}</span>
          </div>
        </div>
      </div>
    `;
    return;
  }
}

// --- Render Execution Steps ---

function renderSteps(steps) {
  if (!steps || steps.length === 0) return;

  stepsList.innerHTML = "";
  steps.forEach((step, idx) => {
    const card = document.createElement("div");
    card.className = `step-card step-${step.status}`;

    let iconSymbol = "•";
    if (step.status === "SUCCEEDED") iconSymbol = "✓";
    else if (step.status === "RUNNING") iconSymbol = "⟳";
    else if (step.status === "RETRYING") iconSymbol = "↻";
    else if (step.status === "WAITING_FOR_APPROVAL") iconSymbol = "⚠";
    else if (step.status === "FAILED") iconSymbol = "✕";

    const attemptText = step.attempt_count > 1 ? ` · Attempt ${step.attempt_count}` : "";

    card.innerHTML = `
      <div class="step-main">
        <div class="step-status-icon">${iconSymbol}</div>
        <div>
          <div class="step-desc">Step ${idx + 1}: ${step.description}</div>
          <div class="step-meta">${step.tool_name}() ${attemptText}</div>
        </div>
      </div>
      <div>
        <span class="status-badge status-${step.status}" style="font-size:0.7rem; padding:0.2rem 0.5rem;">${step.status}</span>
      </div>
    `;

    stepsList.appendChild(card);
  });
}

// --- Update Deliverable Files ---

function updateArtifacts(artifacts) {
  artifactCountBadge.textContent = `${artifacts.length} Files`;
  if (artifacts.length === 0) return;

  const excelArt = artifacts.find((a) => a.artifact_type === "SPREADSHEET");
  if (excelArt) {
    excelFileName.textContent = excelArt.file_path.split("/").pop().split("\\").pop();
    btnDownloadExcel.href = `${API_BASE}/api/artifacts/download?path=${encodeURIComponent(excelArt.file_path)}`;
    btnDownloadExcel.classList.remove("disabled");
  }

  const drafts = artifacts.filter((a) => a.artifact_type === "EMAIL_DRAFT");
  if (drafts.length > 0) {
    draftsFileCount.textContent = `${drafts.length} Outreaches Ready`;
    // Download first draft or zip
    btnDownloadDrafts.href = `${API_BASE}/api/artifacts/download?path=${encodeURIComponent(drafts[0].file_path)}`;
    btnDownloadDrafts.classList.remove("disabled");
  }

  const screenshotArts = artifacts.filter((a) => a.artifact_type === "SCREENSHOT");
  if (screenshotArts.length > 0) {
    const screenshotArt = screenshotArts[screenshotArts.length - 1]; // Pick latest capture
    const filename = screenshotArt.file_path.split("/").pop().split("\\").pop();
    screenshotFileName.textContent = filename;
    const screenshotUrl = `${API_BASE}/api/artifacts/download?path=${encodeURIComponent(screenshotArt.file_path)}&t=${Date.now()}`;
    btnDownloadScreenshot.href = screenshotUrl;
    btnDownloadScreenshot.download = filename;
    btnDownloadScreenshot.classList.remove("disabled");
    screenshotImgPreview.src = screenshotUrl;
    if (screenshotPreviewBox) {
      screenshotPreviewBox.style.display = "block";
      screenshotPreviewBox.classList.remove("hidden");
      screenshotPreviewBox.onclick = () => window.open(screenshotUrl, "_blank");
    }
  }

  const docArts = artifacts.filter((a) => a.artifact_type === "DOCUMENT");
  if (docArts.length > 0) {
    const docArt = docArts[docArts.length - 1];
    const filename = docArt.file_path.split("/").pop().split("\\").pop();
    if (pdfFileName) pdfFileName.textContent = filename;
    const downloadUrl = `${API_BASE}/api/artifacts/download?path=${encodeURIComponent(docArt.file_path)}&t=${Date.now()}`;
    if (btnDownloadPdf) {
      btnDownloadPdf.href = downloadUrl;
      btnDownloadPdf.download = filename;
      btnDownloadPdf.classList.remove("disabled");
    }
    if (pdfDeliverableBox) {
      pdfDeliverableBox.style.display = "block";
    }
  }
}

// --- Update Physical Verification ---

function updateVerification(ver) {
  if (!ver) return;

  verifBadgeStatus.textContent = `${ver.status} (${ver.passed_count}/${ver.total_checks} Checks Passed)`;
  verifBadgeStatus.style.color = ver.status === "VERIFIED" ? "var(--green-500)" : "var(--amber-500)";
  if (ver.summary) {
    verifSummaryText.textContent = ver.summary;
  }
}

async function handleTriggerReverify() {
  if (!currentTaskId) {
    alert("Please run or load a mission before verifying.");
    return;
  }

  btnReverify.innerHTML = "<span>Verifying on Disk...</span>";
  try {
    const res = await fetch(`${API_BASE}/api/tasks/${currentTaskId}/verification`);
    const data = await res.json();
    if (data.success) {
      updateVerification(data.verification);
      alert(`Physical Verification Result: ${data.verification.status}\n${data.verification.summary}`);
    }
  } catch (e) {
    alert(`Verification failed: ${e.message}`);
  } finally {
    btnReverify.innerHTML = `
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
      <span>Run Independent Verification</span>
    `;
  }
}

// --- Human Approval Handling ---

function showApprovalModal(approval) {
  activeApprovalId = approval.id;
  approvalDescription.textContent = approval.description;
  approvalRisk.textContent = `Risk: ${approval.risk_assessment}`;
  approvalPayloadJson.textContent = JSON.stringify(approval.payload || {}, null, 2);
  approvalModal.classList.remove("hidden");
}

async function submitApprovalDecision(decision) {
  if (!currentTaskId || !activeApprovalId) return;

  btnApproveAction.disabled = true;
  btnRejectApproval.disabled = true;

  try {
    const res = await fetch(`${API_BASE}/api/tasks/${currentTaskId}/approvals/${activeApprovalId}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ decision }),
    });

    const data = await res.json();
    if (!data.success) {
      alert(`Approval error: ${data.error}`);
    }

    approvalModal.classList.add("hidden");
    startPolling();
  } catch (e) {
    alert(`Failed to submit approval: ${e.message}`);
  } finally {
    btnApproveAction.disabled = false;
    btnRejectApproval.disabled = false;
  }
}

async function handleResumeTask() {
  if (!currentTaskId) return;
  try {
    const res = await fetch(`${API_BASE}/api/tasks/${currentTaskId}/resume`, {
      method: "POST",
    });
    const data = await res.json();
    if (data.success) {
      btnResumeTask.classList.add("hidden");
      startPolling();
    }
  } catch (e) {
    alert(`Resume failed: ${e.message}`);
  }
}

// --- Fault Injection Configuration ---

async function setFaultInjection(enable) {
  try {
    const res = await fetch(`${API_BASE}/api/demo/fault-injection`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        tool_name: "save_opportunities",
        fail_count: 1,
        task_id: currentTaskId,
        enabled: enable,
      }),
    });
    const data = await res.json();
    faultInjectionToggle.checked = enable;
    if (enable) {
      alert("Fault injection armed: 'save_opportunities' will simulate 1 disk timeout failure, then self-heal without duplicate rows.");
    } else {
      alert("Fault injection disarmed and reset.");
    }
  } catch (e) {
    console.error("Fault injection failed:", e);
  }
}

function exportAuditJson() {
  if (!currentEvents || currentEvents.length === 0) {
    alert("No audit events to export yet.");
    return;
  }
  const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(currentEvents, null, 2));
  const downloadAnchor = document.createElement("a");
  downloadAnchor.setAttribute("href", dataStr);
  downloadAnchor.setAttribute("download", `flowpilot_audit_${currentTaskId || "session"}.json`);
  document.body.appendChild(downloadAnchor);
  downloadAnchor.click();
  downloadAnchor.remove();
}

// --- Past Missions History Modal ---

async function openTaskHistory() {
  taskHistoryModal.classList.remove("hidden");
  taskHistoryListContainer.innerHTML = "<p style='color:var(--grey-400);'>Loading missions from SQLite...</p>";

  try {
    const res = await fetch(`${API_BASE}/api/tasks`);
    const data = await res.json();
    if (data.success && data.tasks) {
      taskHistoryListContainer.innerHTML = "";
      if (data.tasks.length === 0) {
        taskHistoryListContainer.innerHTML = "<p style='color:var(--grey-400);'>No past missions found in SQLite.</p>";
        return;
      }

      data.tasks.forEach((t) => {
        const item = document.createElement("div");
        item.className = "history-item";
        item.innerHTML = `
          <div class="history-left">
            <span>${t.id}</span>
            <p>${t.goal}</p>
          </div>
          <div style="display:flex; align-items:center; gap:0.6rem;">
            <span class="status-badge status-${t.status}" style="font-size:0.7rem; padding:0.2rem 0.5rem;">${t.status}</span>
            <button class="btn-secondary" style="padding:0.3rem 0.6rem; font-size:0.75rem;" onclick="loadTask('${t.id}')">Load</button>
          </div>
        `;
        taskHistoryListContainer.appendChild(item);
      });
    }
  } catch (e) {
    taskHistoryListContainer.innerHTML = `<p style='color:var(--red-400);'>Failed to load missions: ${e.message}</p>`;
  }
}

window.loadTask = function(taskId) {
  currentTaskId = taskId;
  activeTaskIdBadge.textContent = taskId;
  taskHistoryModal.classList.add("hidden");
  pollTask();
};

async function autoLoadLatestTask() {
  try {
    const res = await fetch(`${API_BASE}/api/tasks`);
    const data = await res.json();
    if (data.success && data.tasks && data.tasks.length > 0) {
      const latest = data.tasks[0];
      currentTaskId = latest.id;
      activeTaskIdBadge.textContent = latest.id;
      pollTask();
    }
  } catch (e) {
    console.log("No prior task to autoload.");
  }
}

// --- Mission Cancellation ---

async function handleCancelMission() {
  if (!currentTaskId) return;
  if (!confirm("Are you sure you want to cancel this mission? Active and pending steps will be halted.")) {
    return;
  }

  try {
    const res = await fetch(`${API_BASE}/api/tasks/${currentTaskId}/cancel`, {
      method: "POST",
    });
    const data = await res.json();
    if (data.success) {
      stopPolling();
      pollTask();
    } else {
      alert(`Could not cancel mission: ${data.error}`);
    }
  } catch (err) {
    alert(`Cancellation request failed: ${err.message}`);
  }
}

// --- Scheduled Deadlines & Reminders ---

async function fetchReminders() {
  try {
    const res = await fetch(`${API_BASE}/api/reminders`);
    const data = await res.json();
    if (data.success && data.reminders) {
      const activeCount = data.reminders.filter((r) => r.status === "PENDING" || r.status === "ACTIVE").length;
      if (navRemindersCount) navRemindersCount.textContent = activeCount;
      notifyDueReminders(data.reminders);
      renderRemindersList(data.reminders);
    }
  } catch (err) {
    console.error("Failed to fetch reminders:", err);
  }
}

function notifyDueReminders(reminders) {
  const now = Date.now();
  (reminders || []).forEach((rem) => {
    if (!rem || !rem.id || rem.status === "COMPLETED" || rem.status === "CANCELLED" || !rem.due_at) return;
    const due = new Date(rem.due_at).getTime();
    if (!Number.isFinite(due) || due > now || notifiedReminderIds.has(rem.id)) return;
    notifiedReminderIds.add(rem.id);
    const message = `Reminder: ${rem.title}`;
    if ("Notification" in window && Notification.permission === "granted") {
      try { new Notification("FlowPilot reminder", { body: message, tag: rem.id }); } catch (_) { alert(message); }
    } else {
      alert(message);
    }
  });
}

function renderRemindersList(reminders) {
  if (!remindersListContainer) return;
  if (!reminders || reminders.length === 0) {
    remindersListContainer.innerHTML = "<p style='color:var(--grey-400); text-align:center; padding:1.5rem;'>No reminders scheduled yet.</p>";
    return;
  }

  remindersListContainer.innerHTML = "";
  reminders.forEach((rem) => {
    const isCompleted = rem.status === "COMPLETED";
    const item = document.createElement("div");
    item.className = "reminder-item";
    item.style.display = "flex";
    item.style.alignItems = "center";
    item.style.justifyContent = "space-between";
    item.style.padding = "0.75rem 1rem";
    item.style.marginBottom = "0.5rem";
    item.style.background = isCompleted ? "rgba(100, 116, 139, 0.1)" : "rgba(30, 41, 59, 0.6)";
    item.style.borderRadius = "8px";
    item.style.border = isCompleted ? "1px solid var(--grey-700)" : "1px solid rgba(59, 130, 246, 0.25)";

    item.innerHTML = `
      <div style="flex:1; padding-right:1rem;">
        <div style="display:flex; align-items:center; gap:0.5rem; flex-wrap:wrap;">
          <span style="font-weight:600; font-size:0.875rem; color:${isCompleted ? 'var(--grey-400)' : 'var(--grey-100)'}; text-decoration:${isCompleted ? 'line-through' : 'none'};">${rem.title}</span>
          <span class="status-badge status-${rem.status}" style="font-size:0.65rem; padding:0.15rem 0.4rem;">${rem.status}</span>
        </div>
        ${(rem.due_at || rem.due_date) ? `<div style="font-size:0.75rem; color:var(--grey-400); margin-top:0.25rem;">📅 Due: ${new Date(rem.due_at || rem.due_date).toLocaleString()}</div>` : ""}
      </div>
      <div style="display:flex; gap:0.4rem;">
        <button class="btn-secondary" style="padding:0.25rem 0.55rem; font-size:0.75rem;" onclick="toggleReminderStatus('${rem.id}', '${isCompleted ? 'PENDING' : 'COMPLETED'}')">
          ${isCompleted ? "Reactivate" : "Done"}
        </button>
        <button class="btn-secondary" style="padding:0.25rem 0.55rem; font-size:0.75rem; color:var(--red-400);" onclick="deleteReminder('${rem.id}')" title="Delete">
          ✕
        </button>
      </div>
    `;
    remindersListContainer.appendChild(item);
  });
}

async function handleCreateReminder(e) {
  e.preventDefault();
  const title = remInputTitle.value.trim();
  const dueDate = remInputDate.value;
  if (!title) return;

  try {
    const res = await fetch(`${API_BASE}/api/reminders`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        title,
        due_at: dueDate || null,
        task_id: currentTaskId || null,
      }),
    });
    const data = await res.json();
    if (data.success) {
      if ("Notification" in window && Notification.permission === "default") {
        try { await Notification.requestPermission(); } catch (_) {}
      }
      remInputTitle.value = "";
      remInputDate.value = "";
      fetchReminders();
    } else {
      alert(`Error creating reminder: ${data.error}`);
    }
  } catch (err) {
    alert(`Reminder creation failed: ${err.message}`);
  }
}

window.toggleReminderStatus = async function (reminderId, newStatus) {
  try {
    const res = await fetch(`${API_BASE}/api/reminders/${reminderId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: newStatus }),
    });
    const data = await res.json();
    if (data.success) {
      fetchReminders();
    }
  } catch (err) {
    console.error("Toggle reminder error:", err);
  }
};

window.deleteReminder = async function (reminderId) {
  try {
    const res = await fetch(`${API_BASE}/api/reminders/${reminderId}`, {
      method: "DELETE",
    });
    const data = await res.json();
    if (data.success) {
      fetchReminders();
    }
  } catch (err) {
    console.error("Delete reminder error:", err);
  }
};
