"""
FlowPilot AI - MCP Client
Connects to the FlowPilot MCP Server using the official Python MCP SDK,
discovers registered tools, and executes calls over stdio JSON-RPC.
"""

import asyncio
import json
import os
import sys
from typing import Any, Dict, List, Optional
from mcp import StdioServerParameters
from mcp.client.stdio import stdio_client
from mcp.client.session import ClientSession

# Import in-process server fallback for environments where spawning subprocess is restricted
import mcp_server


class MCPClient:
    def __init__(self, server_script: Optional[str] = None, use_subprocess: bool = True, db_path: Optional[str] = None):
        self.server_script = server_script or os.path.abspath(os.path.join(os.path.dirname(__file__), "mcp_server.py"))
        self.use_subprocess = use_subprocess
        self.db_path = db_path

    def _get_server_params(self) -> StdioServerParameters:
        # Pass current environment so Python path and .env variables propagate
        env = os.environ.copy()
        env["PYTHONUNBUFFERED"] = "1"
        if self.db_path:
            env["DATABASE_PATH"] = os.path.abspath(self.db_path)
        return StdioServerParameters(
            command=sys.executable,
            args=[self.server_script],
            env=env,
        )

    async def list_tools_async(self) -> List[Dict[str, Any]]:
        """
        Connects via stdio to discover all tools exposed by the MCP server.
        """
        if self.use_subprocess:
            try:
                server_params = self._get_server_params()
                async with stdio_client(server_params) as (read, write):
                    async with ClientSession(read, write) as session:
                        await session.initialize()
                        tools_result = await session.list_tools()
                        tools_data = []
                        for t in tools_result.tools:
                            tools_data.append({
                                "name": t.name,
                                "description": t.description,
                                "input_schema": t.inputSchema if hasattr(t, "inputSchema") else {},
                            })
                        return tools_data
            except Exception as e:
                # Fallback to in-process discovery if subprocess communication has issue
                pass

        # In-process server query fallback
        tools = await mcp_server.server.list_tools()
        tools_data = []
        for t in tools:
            tools_data.append({
                "name": t.name,
                "description": t.description,
                "input_schema": t.input_schema if hasattr(t, "input_schema") else {},
            })
        return tools_data

    async def call_tool_async(self, tool_name: str, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """
        Invokes an MCP tool by name with arguments over stdio JSON-RPC.
        """
        if self.use_subprocess:
            try:
                server_params = self._get_server_params()
                async with stdio_client(server_params) as (read, write):
                    async with ClientSession(read, write) as session:
                        await session.initialize()
                        result = await session.call_tool(tool_name, arguments)
                        return self._parse_tool_result(result)
            except Exception as e:
                # If subprocess fails, fall back to in-process server call with diagnostic note
                pass

        # In-process server call fallback
        result = await mcp_server.server.call_tool(tool_name, arguments)
        return self._parse_tool_result(result)

    def _parse_tool_result(self, result: Any) -> Dict[str, Any]:
        """
        Normalizes the MCP CallToolResult into a consistent JSON dictionary.
        """
        # If result is already a dict
        if isinstance(result, dict):
            return result

        # Check content blocks (TextContent)
        raw_text = ""
        if hasattr(result, "content") and result.content:
            for block in result.content:
                if hasattr(block, "text"):
                    raw_text += block.text

        if not raw_text and hasattr(result, "structured_content") and result.structured_content:
            return result.structured_content

        if raw_text:
            try:
                parsed = json.loads(raw_text)
                if isinstance(parsed, dict):
                    return parsed
                return {"result": parsed}
            except json.JSONDecodeError:
                return {"result": raw_text}

        return {"success": True, "raw": str(result)}

    # Synchronous wrappers for standard sequential executor
    def list_tools(self) -> List[Dict[str, Any]]:
        return asyncio.run(self.list_tools_async())

    def call_tool(self, tool_name: str, arguments: Dict[str, Any]) -> Dict[str, Any]:
        return asyncio.run(self.call_tool_async(tool_name, arguments))
