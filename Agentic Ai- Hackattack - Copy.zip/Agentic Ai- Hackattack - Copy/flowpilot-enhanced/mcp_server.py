"""
FlowPilot AI - MCP Server
Real Model Context Protocol server exposing verified tools using the official Python MCP SDK.
Supports Research, Spreadsheets, Email Outreaches, Browser Screenshots, Reminders, and Placement Prep.
"""

import json
import os
import sys
from typing import Any, Dict, List, Optional
from mcp.server.mcpserver import MCPServer

import tools.research as research_tools
import tools.spreadsheet as spreadsheet_tools
import tools.email_drafts as email_tools
import tools.browser as browser_tools
import tools.reminders as reminder_tools
import tools.student_prep as student_tools
import tools.communication as comm_tools

server = MCPServer(
    name="flowpilot-mcp-server",
    version="2.0.0",
    instructions="FlowPilot AI MCP Server providing multi-purpose autonomous tools for research, spreadsheet generation, browser automation, scheduling, and career prep."
)


# --- 1. Research & Source Validation ---

@server.tool(name="search_opportunities", description="Search for student internship opportunities matching eligibility criteria, or return deterministic labeled fixtures in demo mode.")
def search_opportunities_tool(query: str, max_results: int = 3, force_demo: bool = False) -> str:
    res = research_tools.search_opportunities(query=query, max_results=max_results, force_demo=force_demo)
    return json.dumps(res, indent=2)


@server.tool(name="validate_source", description="Check that an official opportunity or application link is usable, valid, and reachable, recording verification evidence.")
def validate_source_tool(url: str, opportunity_id: Optional[str] = None) -> str:
    res = research_tools.validate_source(url=url, opportunity_id=opportunity_id)
    return json.dumps(res, indent=2)


# --- 2. Spreadsheets & File Verification ---

@server.tool(name="save_opportunities", description="Idempotently create or update the Excel workbook with opportunities using stable opportunity IDs to prevent duplicates.")
def save_opportunities_tool(opportunities: List[Dict[str, Any]], file_path: Optional[str] = None, task_id: Optional[str] = None, db_path: Optional[str] = None) -> str:
    try:
        res = spreadsheet_tools.save_opportunities(
            opportunities=opportunities,
            file_path=file_path,
            task_id=task_id,
            db_path=db_path,
        )
        return json.dumps(res, indent=2)
    except Exception as e:
        return json.dumps({
            "success": False,
            "error": str(e),
            "error_type": type(e).__name__,
        }, indent=2)


@server.tool(name="inspect_workbook", description="Reopen the actual Excel workbook with openpyxl and return verified record counts, headers, and duplicate check.")
def inspect_workbook_tool(file_path: str) -> str:
    res = spreadsheet_tools.inspect_workbook(file_path=file_path)
    return json.dumps(res, indent=2)


# --- 3. Email Outreaches & Drafts ---

@server.tool(name="create_email_draft", description="Generate and save a personalized email application draft as a standard .eml file on disk.")
def create_email_draft_tool(
    opportunity: Dict[str, Any],
    candidate_profile: Optional[Dict[str, Any]] = None,
    recipient: Optional[str] = None,
    task_id: Optional[str] = None,
    output_dir: Optional[str] = None,
) -> str:
    res = email_tools.create_email_draft(
        opportunity=opportunity,
        candidate_profile=candidate_profile,
        recipient=recipient,
        task_id=task_id,
        output_dir=output_dir,
    )
    return json.dumps(res, indent=2)


@server.tool(name="list_drafts", description="Inspect existing email draft files on disk and return their actual paths, opportunity associations, and headers.")
def list_drafts_tool(task_id: Optional[str] = None, output_dir: Optional[str] = None) -> str:
    res = email_tools.list_drafts(task_id=task_id, output_dir=output_dir)
    return json.dumps(res, indent=2)


# --- 4. Browser Automation & Screenshots ---

@server.tool(name="take_page_screenshot", description="Capture a high-resolution visual screenshot of a webpage URL or career portal and save as PNG artifact.")
def take_page_screenshot_tool(
    url: str,
    task_id: Optional[str] = None,
    output_path: Optional[str] = None,
    db_path: Optional[str] = None,
) -> str:
    res = browser_tools.take_page_screenshot(
        url=url,
        task_id=task_id,
        output_path=output_path,
        db_path=db_path,
    )
    return json.dumps(res, indent=2)


@server.tool(name="take_desktop_screenshot", description="Capture an authorized desktop screenshot and save as PNG artifact.")
def take_desktop_screenshot_tool(
    task_id: Optional[str] = None,
    output_path: Optional[str] = None,
    db_path: Optional[str] = None,
) -> str:
    res = browser_tools.take_desktop_screenshot(
        task_id=task_id,
        output_path=output_path,
        db_path=db_path,
    )
    return json.dumps(res, indent=2)


# --- 5. Reminders & Scheduling ---

@server.tool(name="create_reminder", description="Create a persistent deadline or follow-up reminder in SQLite.")
def create_reminder_tool(
    title: str,
    due_at: str,
    recurrence: str = "ONCE",
    reminder_type: str = "GENERAL",
    task_id: Optional[str] = None,
    db_path: Optional[str] = None,
) -> str:
    res = reminder_tools.create_reminder(
        title=title,
        due_at=due_at,
        recurrence=recurrence,
        reminder_type=reminder_type,
        task_id=task_id,
        db_path=db_path,
    )
    return json.dumps(res, indent=2)


@server.tool(name="list_reminders", description="List scheduled upcoming or completed reminders from SQLite.")
def list_reminders_tool(
    status: Optional[str] = None,
    task_id: Optional[str] = None,
    limit: int = 50,
    db_path: Optional[str] = None,
) -> str:
    res = reminder_tools.list_reminders(
        status=status,
        task_id=task_id,
        limit=limit,
        db_path=db_path,
    )
    return json.dumps(res, indent=2)


@server.tool(name="cancel_reminder", description="Cancel an existing reminder in SQLite.")
def cancel_reminder_tool(
    reminder_id: str,
    db_path: Optional[str] = None,
) -> str:
    res = reminder_tools.cancel_reminder(
        reminder_id=reminder_id,
        db_path=db_path,
    )
    return json.dumps(res, indent=2)


# --- 6. Student Productivity & Placement Prep ---

@server.tool(name="generate_study_plan", description="Generate a structured, milestone-based placement preparation roadmap.")
def generate_study_plan_tool(
    topic: str = "Full Stack & DSA",
    target_role: str = "Software Engineering Intern",
    duration_weeks: int = 4,
    task_id: Optional[str] = None,
    db_path: Optional[str] = None,
) -> str:
    res = student_tools.generate_study_plan(
        topic=topic,
        target_role=target_role,
        duration_weeks=duration_weeks,
        task_id=task_id,
        db_path=db_path,
    )
    return json.dumps(res, indent=2)


@server.tool(name="compare_resume_to_job", description="Analyze candidate resume alignment against a job description, computing matching score and skill gaps.")
def compare_resume_to_job_tool(
    resume_text: str,
    job_requirements: str,
    task_id: Optional[str] = None,
    db_path: Optional[str] = None,
) -> str:
    res = student_tools.compare_resume_to_job(
        resume_text=resume_text,
        job_requirements=job_requirements,
        task_id=task_id,
        db_path=db_path,
    )
    return json.dumps(res, indent=2)


@server.tool(name="draft_cover_letter", description="Generate a tailored professional cover letter saved as a text artifact.")
def draft_cover_letter_tool(
    company: str,
    role: str,
    applicant_skills: str,
    task_id: Optional[str] = None,
    db_path: Optional[str] = None,
) -> str:
    res = student_tools.draft_cover_letter(
        company=company,
        role=role,
        applicant_skills=applicant_skills,
        task_id=task_id,
        db_path=db_path,
    )
    return json.dumps(res, indent=2)


# --- 7. Communication & Document Dispatch ---

@server.tool(name="prepare_document_or_pdf", description="Generate a verified document or PDF deliverable saved to outputs/documents.")
def prepare_document_or_pdf_tool(
    title: str = "Official Document",
    content: str = "",
    recipient: str = "Target Recipient",
    task_id: Optional[str] = None,
    output_path: Optional[str] = None,
    db_path: Optional[str] = None,
) -> str:
    res = comm_tools.prepare_document_or_pdf(
        title=title,
        content=content,
        recipient=recipient,
        task_id=task_id,
        output_path=output_path,
        db_path=db_path,
    )
    return json.dumps(res, indent=2)


@server.tool(name="send_communication_or_message", description="Transmit an authorized message, email, or WhatsApp communication with optional attachment.")
def send_communication_or_message_tool(
    channel: str = "whatsapp",
    recipient: str = "Contact",
    message: str = "",
    attachment_path: Optional[str] = None,
    task_id: Optional[str] = None,
    db_path: Optional[str] = None,
) -> str:
    res = comm_tools.send_communication_or_message(
        channel=channel,
        recipient=recipient,
        message=message,
        attachment_path=attachment_path,
        task_id=task_id,
        db_path=db_path,
    )
    return json.dumps(res, indent=2)


if __name__ == "__main__":
    # Run official MCP stdio server
    server.run(transport="stdio")
