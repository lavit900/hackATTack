"""
FlowPilot AI - Human Approval Service
Provides gating and decision tracking for sensitive or external actions.
"""

import uuid
from typing import Any, Dict, List, Optional
import database


class ApprovalService:
    def __init__(self, db_path: Optional[str] = None):
        self.db_path = db_path

    def request_approval(
        self,
        task_id: str,
        step_id: str,
        action_type: str,
        description: str,
        risk_assessment: str,
        payload: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Create a new pending approval gate for a step.
        """
        approval_id = f"appr_{uuid.uuid4().hex[:10]}"
        return database.create_approval(
            approval_id=approval_id,
            task_id=task_id,
            step_id=step_id,
            action_type=action_type,
            description=description,
            risk_assessment=risk_assessment,
            payload=payload,
            db_path=self.db_path,
        )

    def get_approval(self, approval_id: str) -> Optional[Dict[str, Any]]:
        return database.get_approval(approval_id, db_path=self.db_path)

    def get_pending(self, task_id: str) -> List[Dict[str, Any]]:
        return database.get_pending_approvals_for_task(task_id, db_path=self.db_path)

    def record_decision(self, approval_id: str, decision: str) -> Optional[Dict[str, Any]]:
        """
        Record user's decision ('APPROVED' or 'REJECTED').
        Never assumes consent without explicit user action.
        """
        clean_decision = decision.strip().upper()
        if clean_decision not in ("APPROVED", "REJECTED"):
            raise ValueError(f"Invalid approval decision: {decision}. Must be 'APPROVED' or 'REJECTED'.")
        return database.update_approval_decision(
            approval_id=approval_id,
            decision=clean_decision,
            db_path=self.db_path,
        )
