"""
FlowPilot AI - Audit Service
Logs structured execution events, transitions, tool calls, and recoveries to SQLite.
"""

from typing import Any, Dict, List, Optional
import database


class AuditService:
    def __init__(self, db_path: Optional[str] = None):
        self.db_path = db_path

    def log(
        self,
        task_id: str,
        event_type: str,
        message: str,
        step_id: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
    ) -> int:
        """
        Record a structured audit event.
        Common event types:
          - TASK_CREATED
          - PLAN_GENERATED
          - STEP_STARTED
          - TOOL_INVOKED
          - TOOL_SUCCEEDED
          - TOOL_FAILED
          - RETRY_ATTEMPTED
          - APPROVAL_REQUESTED
          - APPROVAL_GRANTED
          - APPROVAL_REJECTED
          - ARTIFACT_REGISTERED
          - VERIFICATION_STARTED
          - VERIFICATION_RESULT
          - TASK_COMPLETED
          - TASK_FAILED
        """
        return database.log_event(
            task_id=task_id,
            event_type=event_type,
            message=message,
            step_id=step_id,
            details=details,
            db_path=self.db_path,
        )

    def get_events(self, task_id: str) -> List[Dict[str, Any]]:
        return database.get_events_for_task(task_id, db_path=self.db_path)
