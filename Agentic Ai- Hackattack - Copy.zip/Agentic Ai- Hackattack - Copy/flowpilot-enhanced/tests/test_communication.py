"""Regression tests for safe, truthful communication dispatch behavior."""

from tools.communication import send_communication_or_message


def test_whatsapp_prepares_link_without_claiming_delivery():
    result = send_communication_or_message(
        channel="whatsapp",
        recipient="919876543210",
        message="Hello there",
    )
    assert result["success"] is True
    assert result["status"] == "READY_TO_SEND"
    assert result["delivered_at"] is None
    assert result["action_url"].startswith("https://wa.me/919876543210?")
    assert "Hello%20there" in result["action_url"]


def test_whatsapp_requires_full_phone_number():
    result = send_communication_or_message(
        channel="whatsapp",
        recipient="Sam",
        message="Hello there",
    )
    assert result["success"] is False
    assert result["status"] == "NOT_SENT"
    assert "international phone number" in result["error"]


def test_unknown_channel_does_not_claim_delivery():
    result = send_communication_or_message(
        channel="slack",
        recipient="someone",
        message="Hello",
    )
    assert result["success"] is False
    assert result["status"] == "NOT_SENT"
