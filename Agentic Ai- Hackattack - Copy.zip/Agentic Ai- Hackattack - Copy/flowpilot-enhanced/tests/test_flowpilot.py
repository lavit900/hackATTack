"""
FlowPilot AI - Automated Test Suite
Covers the 11 core verification requirements:
1. Health endpoint.
2. Task creation and validation.
3. Task retrieval and persistence after application restart.
4. MCP tool discovery and successful tool call.
5. Spreadsheet creation and reopening.
6. Idempotent spreadsheet writes.
7. Recovery after an injected one-time failure.
8. No duplicate records after retry.
9. Verification detects missing or incorrect records.
10. Approval is required for sensitive actions.
11. A partially completed task reports its unresolved issues honestly.
"""

import os
import tempfile
import shutil
import json
import pytest

import database
from mcp_client import MCPClient
import tools.spreadsheet as spreadsheet_tools
import tools.research as research_tools
import tools.email_drafts as email_tools
from agent.planner import generate_plan, validate_plan, PlanValidationError
from agent.executor import WorkflowExecutor
from agent.recovery import RecoveryEngine
import agent.verifier as verifier
import services.approval as approval_svc
import app as flask_app


@pytest.fixture
def temp_env():
    """Sets up an isolated temporary workspace directory and SQLite database for tests."""
    temp_dir = tempfile.mkdtemp()
    test_db = os.path.join(temp_dir, "test_flowpilot.db")
    test_out = os.path.join(temp_dir, "outputs")
    os.makedirs(test_out, exist_ok=True)
    
    # Initialize schema
    database.init_db(test_db)
    
    yield {
        "dir": temp_dir,
        "db": test_db,
        "outputs": test_out,
    }
    
    # Cleanup
    shutil.rmtree(temp_dir, ignore_errors=True)


# --- 1. Health Endpoint ---

def test_health_endpoint():
    client = flask_app.app.test_client()
    res = client.get("/api/health")
    assert res.status_code == 200
    data = res.get_json()
    assert data["status"] in ("healthy", "degraded")
    assert "service" in data
    assert data["mcp_server"] == "active"


# --- 2. Task Creation and Validation ---

def test_task_creation_and_validation(temp_env):
    goal = "Find three internship opportunities for a 3rd year CS student in India and create an Excel file."
    plan = generate_plan(goal, task_id="test_task_1")
    assert plan["task_id"] == "test_task_1"
    assert len(plan["steps"]) >= 3
    assert plan["task_summary"] is not None

    # Invalid plan rejection test: unknown tool
    invalid_plan = {
        "task_id": "bad_plan",
        "task_summary": "Bad Plan",
        "steps": [
            {
                "step_id": "step_1",
                "description": "Exploit shell",
                "tool_name": "execute_arbitrary_shell_command",  # FORBIDDEN
                "input_params": {},
                "dependencies": [],
                "status": "PENDING"
            }
        ]
    }
    with pytest.raises(PlanValidationError):
        validate_plan(invalid_plan)

    # Invalid plan rejection test: circular/forward dependency
    circular_plan = {
        "task_id": "circular",
        "task_summary": "Circular",
        "steps": [
            {
                "step_id": "step_1",
                "description": "Step 1",
                "tool_name": "search_opportunities",
                "input_params": {},
                "dependencies": ["step_2"],  # DEPENDS ON FUTURE STEP
                "status": "PENDING"
            },
            {
                "step_id": "step_2",
                "description": "Step 2",
                "tool_name": "validate_source",
                "input_params": {},
                "dependencies": [],
                "status": "PENDING"
            }
        ]
    }
    with pytest.raises(PlanValidationError):
        validate_plan(circular_plan)


# --- 3. Task Retrieval and Persistence after Application Restart ---

def test_task_persistence_after_restart(temp_env):
    db_path = temp_env["db"]
    task_id = "restart_test_101"
    
    # Simulate initial run storing task and steps
    database.create_task(task_id, "Find ML internships", "ML Research Plan", json.dumps({"test": 123}), db_path=db_path)
    database.create_step(task_id, {
        "step_id": "step_1",
        "description": "Search Step",
        "tool_name": "search_opportunities",
        "input_params": {"query": "ML"},
        "dependencies": [],
        "status": "SUCCEEDED",
        "attempt_count": 1,
        "max_retries": 3,
    }, db_path=db_path)

    # "Restart" application by closing and reconnecting via fresh query
    retrieved = database.get_task(task_id, db_path=db_path)
    assert retrieved is not None
    assert retrieved["id"] == task_id
    assert retrieved["goal"] == "Find ML internships"

    steps = database.get_steps_for_task(task_id, db_path=db_path)
    assert len(steps) == 1
    assert steps[0]["tool_name"] == "search_opportunities"
    assert steps[0]["status"] == "SUCCEEDED"


# --- 4. MCP Tool Discovery and Successful Call ---

def test_mcp_tool_discovery_and_call():
    client = MCPClient()
    tools = client.list_tools()
    assert len(tools) >= 6
    names = {t["name"] for t in tools}
    assert "search_opportunities" in names
    assert "save_opportunities" in names
    assert "create_email_draft" in names
    assert "inspect_workbook" in names

    # Call tool via MCP
    result = client.call_tool("search_opportunities", {"query": "computer science intern", "max_results": 2, "force_demo": True})
    assert result.get("success") is True
    assert len(result.get("opportunities", [])) == 2


# --- 5. Spreadsheet Creation and Reopening ---

def test_spreadsheet_creation_and_reopening(temp_env):
    target_xlsx = os.path.join(temp_env["outputs"], "test_sheet.xlsx")
    opps = research_tools.search_opportunities("CS intern", max_results=3, force_demo=True)["opportunities"]
    
    # Save
    save_res = spreadsheet_tools.save_opportunities(opps, file_path=target_xlsx)
    assert save_res["success"] is True
    assert os.path.exists(target_xlsx)

    # Reopen and inspect with openpyxl
    inspect_res = spreadsheet_tools.inspect_workbook(target_xlsx)
    assert inspect_res["exists"] is True
    assert inspect_res["is_valid"] is True
    assert inspect_res["total_records"] == 3
    assert len(inspect_res["missing_headers"]) == 0
    assert len(inspect_res["duplicate_ids"]) == 0


# --- 6. Idempotent Spreadsheet Writes ---

def test_idempotent_spreadsheet_writes(temp_env):
    target_xlsx = os.path.join(temp_env["outputs"], "idempotent_test.xlsx")
    opps = research_tools.search_opportunities("CS intern", max_results=3, force_demo=True)["opportunities"]

    # First write
    spreadsheet_tools.save_opportunities(opps, file_path=target_xlsx)
    inspect_1 = spreadsheet_tools.inspect_workbook(target_xlsx)
    assert inspect_1["total_records"] == 3

    # Second write with the SAME records
    spreadsheet_tools.save_opportunities(opps, file_path=target_xlsx)
    inspect_2 = spreadsheet_tools.inspect_workbook(target_xlsx)
    
    # Must still be exactly 3 records, NO duplicates
    assert inspect_2["total_records"] == 3
    assert len(inspect_2["duplicate_ids"]) == 0


# --- 7. Recovery After an Injected One-Time Failure ---

def test_recovery_after_injected_one_time_failure(temp_env):
    db_path = temp_env["db"]
    task_id = "fault_recovery_task"
    target_xlsx = os.path.join(temp_env["outputs"], f"opportunities_{task_id}.xlsx")
    
    # Arm one-time failure for save_opportunities
    database.arm_fault_injection(
        tool_name="save_opportunities",
        fail_count=1,
        task_id=task_id,
        error_type="SimulatedDiskTimeoutError",
        db_path=db_path
    )

    # Create task & steps in test database
    database.create_task(task_id, "Test Fault Recovery", "Fault Recovery Demo", db_path=db_path)
    
    opps = research_tools.search_opportunities("CS intern", max_results=2, force_demo=True)["opportunities"]
    database.create_step(task_id, {
        "step_id": "step_1",
        "description": "Search",
        "tool_name": "search_opportunities",
        "input_params": {"query": "CS intern", "max_results": 2, "force_demo": True},
        "dependencies": [],
        "status": "SUCCEEDED",
        "result_json": json.dumps({"opportunities": opps}),
    }, db_path=db_path)

    database.create_step(task_id, {
        "step_id": "step_2",
        "description": "Save to Excel (Will inject 1 failure)",
        "tool_name": "save_opportunities",
        "input_params": {"file_path": target_xlsx, "opportunities": opps, "task_id": task_id},
        "dependencies": ["step_1"],
        "status": "PENDING",
        "max_retries": 3,
    }, db_path=db_path)

    # Run executor
    executor = WorkflowExecutor(db_path=db_path)
    res = executor.run_task(task_id)

    assert res["success"] is True
    # Verify step_2 succeeded after retry
    step_2 = database.get_step(task_id, "step_2", db_path=db_path)
    assert step_2["status"] == "SUCCEEDED"
    assert step_2["attempt_count"] == 2  # Attempt 1 failed, Attempt 2 succeeded!

    # Check audit events record the retry
    events = database.get_events_for_task(task_id, db_path=db_path)
    event_types = [e["event_type"] for e in events]
    assert "RETRY_SCHEDULED" in event_types


# --- 8. No Duplicate Records After Retry ---

def test_no_duplicate_records_after_retry(temp_env):
    # Builds upon recovery test: inspect the workbook after retry
    db_path = temp_env["db"]
    task_id = "fault_recovery_task_dupe_check"
    target_xlsx = os.path.join(temp_env["outputs"], f"opportunities_{task_id}.xlsx")
    
    database.arm_fault_injection("save_opportunities", fail_count=1, task_id=task_id, db_path=db_path)
    database.create_task(task_id, "Dupe Check", "Dupe Check", db_path=db_path)
    
    opps = research_tools.search_opportunities("CS intern", max_results=3, force_demo=True)["opportunities"]
    database.create_step(task_id, {
        "step_id": "step_1",
        "description": "Search",
        "tool_name": "search_opportunities",
        "input_params": {"query": "CS intern", "max_results": 3, "force_demo": True},
        "dependencies": [],
        "status": "SUCCEEDED",
        "result_json": json.dumps({"opportunities": opps}),
    }, db_path=db_path)

    database.create_step(task_id, {
        "step_id": "step_2",
        "description": "Save to Excel",
        "tool_name": "save_opportunities",
        "input_params": {"file_path": target_xlsx, "opportunities": opps, "task_id": task_id},
        "dependencies": ["step_1"],
        "status": "PENDING",
        "max_retries": 3,
    }, db_path=db_path)

    executor = WorkflowExecutor(db_path=db_path)
    executor.run_task(task_id)

    # Inspect the workbook
    inspection = spreadsheet_tools.inspect_workbook(target_xlsx)
    assert inspection["exists"] is True
    assert inspection["total_records"] == 3
    assert len(inspection["duplicate_ids"]) == 0


# --- 9. Verification Detects Missing or Incorrect Records ---

def test_verification_detects_missing_or_incorrect_records(temp_env):
    db_path = temp_env["db"]
    task_id = "verification_missing_test"
    database.create_task(task_id, "Goal", "Summary", db_path=db_path)

    # No files exist yet: Verification MUST fail
    ver = verifier.verify_task_deliverables(task_id, db_path=db_path)
    assert ver["status"] == verifier.VerificationResult.FAILED
    assert ver["failed_count"] > 0


# --- 10. Approval is Required for Sensitive Actions ---

def test_approval_is_required_for_sensitive_actions(temp_env):
    db_path = temp_env["db"]
    task_id = "sensitive_task"
    database.create_task(task_id, "Send internship applications automatically", "Sensitive Goal", db_path=db_path)

    database.create_step(task_id, {
        "step_id": "step_1",
        "description": "Transmit application emails externally",
        "tool_name": "create_email_draft",
        "input_params": {"action": "EXTERNAL_DISPATCH"},
        "dependencies": [],
        "requires_approval": True,  # SENSITIVE ACTION GATING
        "status": "PENDING",
    }, db_path=db_path)

    executor = WorkflowExecutor(db_path=db_path)
    res = executor.run_task(task_id)

    # Must halt execution waiting for approval
    assert res["status"] == "WAITING_FOR_APPROVAL"
    task = database.get_task(task_id, db_path=db_path)
    assert task["status"] == "WAITING_FOR_APPROVAL"

    # Verify approval record created in SQLite
    pending_apprs = approval_svc.ApprovalService(db_path=db_path).get_pending(task_id)
    assert len(pending_apprs) == 1
    assert pending_apprs[0]["step_id"] == "step_1"


# --- 11. Partially Completed Task Reports Unresolved Issues Honestly ---

def test_partially_completed_task_reports_unresolved_honestly(temp_env):
    db_path = temp_env["db"]
    task_id = "partial_test_task"
    database.create_task(task_id, "Goal", "Summary", db_path=db_path)

    # Produce ONLY spreadsheet, but NO email drafts
    target_xlsx = os.path.join(temp_env["outputs"], f"opportunities_{task_id}.xlsx")
    opps = research_tools.search_opportunities("CS intern", max_results=2, force_demo=True)["opportunities"]
    spreadsheet_tools.save_opportunities(opps, file_path=target_xlsx)
    database.register_artifact(task_id, "SPREADSHEET", target_xlsx, "Opportunities", db_path=db_path)

    ver = verifier.verify_task_deliverables(task_id, db_path=db_path)
    # Deliverables are partial: spreadsheet exists, but drafts missing
    assert ver["status"] == verifier.VerificationResult.PARTIALLY_VERIFIED
    assert ver["failed_count"] >= 1
    failed_names = [f["name"] for f in ver["details"]["failed_checks"]]
    assert any("Email Drafts" in n for n in failed_names)


# --- 12. Screenshot Capture and Verification ---

def test_screenshot_capture_and_verification(temp_env):
    import tools.browser as browser_tools
    db_path = temp_env["db"]
    task_id = "test_screen_task"
    database.create_task(task_id, "Goal", "Summary", db_path=db_path)

    res = browser_tools.take_page_screenshot(
        url="https://careers.google.com/students/",
        task_id=task_id,
        output_path=os.path.join(temp_env["outputs"], "test_shot.png"),
        db_path=db_path,
    )
    assert res["success"] is True
    assert os.path.exists(res["file_path"])
    assert res["file_size_bytes"] > 0

    # Verify PNG magic bytes
    with open(res["file_path"], "rb") as f:
        magic = f.read(8)
        assert magic.startswith(b"\x89PNG\r\n\x1a\n")


# --- 13. Reminders CRUD and SQLite Persistence ---

def test_reminders_crud_and_persistence(temp_env):
    import tools.reminders as reminder_tools
    db_path = temp_env["db"]
    task_id = "test_reminder_task"
    database.create_task(task_id, "Goal", "Summary", db_path=db_path)

    # 1. Create
    res = reminder_tools.create_reminder(
        title="Submit ISRO Application Form",
        due_at="2026-11-15",
        recurrence="ONCE",
        reminder_type="DEADLINE",
        task_id=task_id,
        db_path=db_path,
    )
    assert res["success"] is True
    rem_id = res["reminder"]["id"]

    # 2. List
    listed = reminder_tools.list_reminders(task_id=task_id, db_path=db_path)
    assert listed["count"] == 1
    assert listed["reminders"][0]["title"] == "Submit ISRO Application Form"

    # 3. Cancel
    cancelled = reminder_tools.cancel_reminder(reminder_id=rem_id, db_path=db_path)
    assert cancelled["success"] is True
    assert cancelled["status"] == "CANCELLED"


# --- 14. Task Cancellation Workflow ---

def test_task_cancellation_workflow(temp_env):
    db_path = temp_env["db"]
    task_id = "cancel_me_task"
    database.create_task(task_id, "Long running job", "Summary", db_path=db_path)
    database.create_step(task_id, {
        "step_id": "step_1",
        "description": "Step 1",
        "tool_name": "search_opportunities",
        "input_params": {"query": "CS"},
        "dependencies": [],
        "status": "PENDING",
    }, db_path=db_path)

    # Cancel task
    ok = database.cancel_task(task_id, reason="User cancelled test", db_path=db_path)
    assert ok is True

    task = database.get_task(task_id, db_path=db_path)
    assert task["status"] == "CANCELLED"

    # Executor should exit cleanly on cancelled task
    executor = WorkflowExecutor(db_path=db_path)
    exec_res = executor.run_task(task_id)
    assert exec_res["status"] == "CANCELLED"


# --- 15. All 14 MCP Tools Discovered and Validated ---

def test_all_mcp_tools_discovered(temp_env):
    client = MCPClient(db_path=temp_env["db"])
    tools = client.list_tools()
    tool_names = {t["name"] for t in tools}
    expected = {
        "search_opportunities",
        "validate_source",
        "save_opportunities",
        "inspect_workbook",
        "create_email_draft",
        "list_drafts",
        "take_page_screenshot",
        "take_desktop_screenshot",
        "create_reminder",
        "list_reminders",
        "cancel_reminder",
        "generate_study_plan",
        "compare_resume_to_job",
        "draft_cover_letter",
    }
    assert expected.issubset(tool_names)
    assert len(tools) >= 14

