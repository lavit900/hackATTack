"""Regression tests for single-action routing, reminders, and requested result counts."""
from agent.planner import generate_plan
from tools.research import search_opportunities


def test_screenshot_only_plan_does_not_add_unrelated_deliverables():
    plan = generate_plan("Take a screenshot of https://example.com", task_id="shot_test")
    assert [step["tool_name"] for step in plan["steps"]] == ["take_page_screenshot"]
    assert plan["steps"][0]["input_params"]["url"] == "https://example.com"


def test_desktop_website_means_page_capture_not_physical_desktop():
    plan = generate_plan("Take ss of the desktop site at github.com", task_id="site_test")
    assert [step["tool_name"] for step in plan["steps"]] == ["take_page_screenshot"]
    assert plan["steps"][0]["input_params"]["url"] == "https://github.com"


def test_explicit_physical_desktop_uses_desktop_capture():
    plan = generate_plan("Take a screenshot of my desktop screen", task_id="desktop_test")
    assert [step["tool_name"] for step in plan["steps"]] == ["take_desktop_screenshot"]


def test_alarm_request_creates_only_a_reminder_step():
    plan = generate_plan("Set an alarm for 5 pm tomorrow", task_id="alarm_test")
    assert [step["tool_name"] for step in plan["steps"]] == ["create_reminder"]
    assert plan["steps"][0]["input_params"]["reminder_type"] == "ALARM"
    assert plan["steps"][0]["input_params"]["title"] == "Alarm"


def test_requested_opportunity_count_is_forwarded_to_search_tool():
    plan = generate_plan("Find 25 software engineering internships in India and create an Excel spreadsheet", task_id="jobs_test")
    search = next(step for step in plan["steps"] if step["tool_name"] == "search_opportunities")
    assert search["input_params"]["max_results"] == 25


def test_demo_search_uses_full_curated_catalogue_for_larger_counts():
    result = search_opportunities("software engineering internships", max_results=20, force_demo=True)
    assert result["count"] > 4
    assert result["count"] == result["available_fixture_count"]
    assert all(item["is_verified"] is False for item in result["opportunities"])


def test_localhost_port_is_recognized_as_requested_screenshot_target():
    plan = generate_plan("Capture a screenshot of localhost:3000", task_id="localhost_test")
    assert plan["steps"][0]["tool_name"] == "take_page_screenshot"
    assert plan["steps"][0]["input_params"]["url"] == "http://localhost:3000"
