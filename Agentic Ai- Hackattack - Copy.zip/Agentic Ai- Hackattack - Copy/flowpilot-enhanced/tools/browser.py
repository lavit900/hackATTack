"""
FlowPilot AI - Browser Automation and Screenshot Tools
Supports page screenshot capture, desktop capture, and page text extraction.
Uses Playwright if available, with robust Pillow visual rendering fallback.
"""

import os
import re
import time
import urllib.parse
from datetime import datetime, timezone
from typing import Any, Dict, Optional
import requests

import database


def _get_safe_filename(url: str) -> str:
    parsed = urllib.parse.urlparse(url)
    domain = parsed.netloc.replace("www.", "")
    path = re.sub(r'[^a-zA-Z0-9_-]', '_', parsed.path).strip('_')
    name = f"{domain}_{path}" if path else domain
    return name[:50] or "webpage"


def take_page_screenshot(
    url: str,
    task_id: Optional[str] = None,
    output_path: Optional[str] = None,
    db_path: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Capture a visual screenshot of a given webpage URL and save as PNG.
    Registers the screenshot as an artifact in SQLite.
    """
    if not output_path:
        out_dir = os.path.join("outputs", "screenshots", task_id or "general")
        os.makedirs(out_dir, exist_ok=True)
        safe_name = _get_safe_filename(url)
        output_path = os.path.join(out_dir, f"screenshot_{safe_name}_{int(time.time())}.png")
    else:
        os.makedirs(os.path.dirname(output_path), exist_ok=True)

    # A page screenshot means navigate to the requested URL in a real browser.
    # Never silently substitute the local dashboard or a generated placeholder.
    if not isinstance(url, str) or not url.strip():
        return {"success": False, "error": "No webpage URL was supplied. Include a full URL (for example, https://example.com) or a recognized site name."}
    url = url.strip()
    if not re.match(r"^https?://", url, re.IGNORECASE):
        url = "https://" + url
    parsed_url = urllib.parse.urlparse(url)
    if parsed_url.scheme not in ("http", "https") or not parsed_url.netloc or "." not in parsed_url.netloc:
        return {"success": False, "url": url, "error": "Invalid webpage URL. Use a complete http:// or https:// address."}

    playwright_success = False
    navigation_error = None
    page_title = ""
    page_url = url
    try:
        from playwright.sync_api import sync_playwright, TimeoutError as PlaywrightTimeoutError
        with sync_playwright() as p:
            browser = None
            launch_errors = []
            # Prefer bundled Chromium; then try installed Edge/Chrome as a fallback.
            for channel in [None, "msedge", "chrome"]:
                try:
                    browser = p.chromium.launch(channel=channel, headless=True) if channel else p.chromium.launch(headless=True)
                    break
                except Exception as launch_error:
                    launch_errors.append(str(launch_error))
            if browser is None:
                raise RuntimeError("Could not launch Chromium/Edge/Chrome. Run `python -m playwright install chromium`. " + " | ".join(launch_errors[-2:]))
            try:
                page = browser.new_page(viewport={"width": 1440, "height": 1000}, device_scale_factor=1)
                try:
                    response = page.goto(url, timeout=30000, wait_until="domcontentloaded")
                except PlaywrightTimeoutError:
                    # DOM may still be usable on sites that keep long-running requests open.
                    if page.url in ("about:blank", "chrome-error://chromewebdata/"):
                        raise RuntimeError(f"Timed out while opening {url}; no page was loaded.")
                page.wait_for_timeout(1200)
                page_title = page.title()
                page_url = page.url
                body_text = (page.locator("body").inner_text(timeout=2500) if page.locator("body").count() else "")[:500]
                if page_url.startswith("chrome-error://") or "this site can’t be reached" in body_text.lower() or "this site can't be reached" in body_text.lower():
                    raise RuntimeError(f"The browser could not reach {url}. Check the URL and internet connection.")
                page.screenshot(path=output_path, full_page=True, animations="disabled")
                playwright_success = True
            finally:
                browser.close()
    except Exception as e:
        navigation_error = str(e)
        playwright_success = False

    # Do not fabricate a screenshot if navigation or browser capture failed.
    if not playwright_success:
        try:
            if os.path.exists(output_path):
                os.remove(output_path)
        except OSError:
            pass
        message = navigation_error or "Unknown browser capture failure."
        if "playwright" in message.lower() or "chromium" in message.lower() or "executable" in message.lower():
            message += " Install dependencies with `pip install -r requirements.txt` and `python -m playwright install chromium`."
        return {"success": False, "url": url, "error": message, "placeholder_created": False}

    # Verify physical file existence and size
    if not os.path.exists(output_path) or os.path.getsize(output_path) == 0:
        return {
            "success": False,
            "url": url,
            "error": "Screenshot file was not written to disk or is 0 bytes.",
        }

    file_size = os.path.getsize(output_path)
    filename = os.path.basename(output_path)
    try:
        from PIL import Image
        with Image.open(output_path) as captured_image:
            resolution = f"{captured_image.width}x{captured_image.height}"
    except Exception:
        resolution = "unknown"

    # Register artifact in database
    if task_id:
        database.register_artifact(
            task_id=task_id,
            artifact_type="SCREENSHOT",
            file_path=output_path,
            title=f"Webpage Screenshot: {_get_safe_filename(url)}",
            metadata={"url": url, "page_url": page_url, "page_title": page_title, "file_size": file_size, "capture": "PLAYWRIGHT_REAL_BROWSER"},
            db_path=db_path,
        )

    return {
        "success": True,
        "url": url,
        "task_id": task_id,
        "file_path": output_path,
        "file_name": filename,
        "file_size_bytes": file_size,
        "page_title": page_title,
        "page_url": page_url,
        "resolution": resolution,
        "capture": "PLAYWRIGHT_REAL_BROWSER",
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


def take_desktop_screenshot(
    task_id: Optional[str] = None,
    output_path: Optional[str] = None,
    db_path: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Capture authorized desktop screenshot and save as PNG artifact.
    """
    if not output_path:
        out_dir = os.path.join("outputs", "screenshots", task_id or "desktop")
        os.makedirs(out_dir, exist_ok=True)
        output_path = os.path.join(out_dir, f"desktop_screenshot_{int(time.time())}.png")

    try:
        from PIL import ImageGrab
        # ImageGrab only captures the machine/session running Flask. It cannot
        # capture a remote user's desktop when the server is hosted elsewhere.
        shot = ImageGrab.grab(all_screens=True)
        shot.save(output_path, "PNG")
        if not os.path.exists(output_path) or os.path.getsize(output_path) < 1000:
            raise RuntimeError("The desktop capture returned an empty or invalid image.")
    except Exception as e:
        return {
            "success": False,
            "error": f"Desktop screenshot capture failed: {str(e)}. Run FlowPilot on the same logged-in desktop you want to capture; desktop capture may not work in a headless/server session.",
        }

    file_size = os.path.getsize(output_path)
    if task_id:
        database.register_artifact(
            task_id=task_id,
            artifact_type="SCREENSHOT",
            file_path=output_path,
            title="Desktop Screenshot Capture",
            metadata={"file_size": file_size, "type": "DESKTOP"},
            db_path=db_path,
        )

    return {
        "success": True,
        "task_id": task_id,
        "file_path": output_path,
        "file_size_bytes": file_size,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


def extract_page_content(url: str) -> Dict[str, Any]:
    """
    Extract readable text content, titles, and links from accessible web pages.
    """
    try:
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) FlowPilot/1.0"}
        resp = requests.get(url, headers=headers, timeout=8)
        text = resp.text

        title_match = re.search(r"<title>(.*?)</title>", text, re.IGNORECASE)
        title = title_match.group(1).strip() if title_match else url

        # Strip scripts and styles
        clean = re.sub(r"<(script|style).*?>.*?</\1>", "", text, flags=re.DOTALL | re.IGNORECASE)
        # Strip HTML tags
        clean_text = re.sub(r"<[^>]+>", " ", clean)
        clean_text = re.sub(r"\s+", " ", clean_text).strip()

        # Extract links
        links = re.findall(r'href=[\'"](https?://[^\'">]+)[\'"]', text)

        return {
            "success": True,
            "url": url,
            "status_code": resp.status_code,
            "title": title,
            "text_snippet": clean_text[:600],
            "total_links_found": len(links),
            "sample_links": links[:5],
        }
    except Exception as e:
        return {
            "success": False,
            "url": url,
            "error": str(e),
        }
