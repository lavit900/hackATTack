"""
FlowPilot AI - Email Draft Generation and Inspection Tool
Generates inspectable, standard .eml draft files on disk.
Never sends emails automatically. Explicitly marks missing recipients.
"""

import os
import re
import glob
from email.message import EmailMessage
from email import policy
from email.parser import BytesParser
from typing import Any, Dict, List, Optional


def get_default_drafts_dir(task_id: Optional[str] = None) -> str:
    base_out = os.getenv("OUTPUT_DIR", "outputs")
    if task_id:
        drafts_dir = os.path.join(base_out, "drafts", task_id)
    else:
        drafts_dir = os.path.join(base_out, "drafts")
    os.makedirs(drafts_dir, exist_ok=True)
    return drafts_dir


def create_email_draft(
    opportunity: Dict[str, Any],
    candidate_profile: Optional[Dict[str, Any]] = None,
    recipient: Optional[str] = None,
    task_id: Optional[str] = None,
    output_dir: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Generates and saves a personalized email draft as a standard .eml file.
    Does NOT invent recipient email addresses.
    """
    profile = candidate_profile or {
        "name": "Candidate",
        "education": "3rd-Year B.Tech Computer Science student in India",
        "skills": "Python, Data Structures, Algorithms, Distributed Systems",
        "email": "candidate@example.edu.in",
    }

    opp_id = opportunity.get("opportunity_id", "opp_unknown")
    company = opportunity.get("company", "Hiring Team")
    title = opportunity.get("title", "Internship Opportunity")
    skills = opportunity.get("skills", "software engineering")

    # Determine recipient
    if recipient and "@" in recipient:
        to_address = recipient
        recipient_status = "SPECIFIED"
    else:
        # Prompt rule: Do not invent recipient addresses. Mark requiring user input.
        to_address = f"USER_INPUT_REQUIRED <recruitment@{company.lower().replace(' ', '')}.com.invalid>"
        recipient_status = "RECIPIENT_INPUT_REQUIRED"

    subject = f"Application / Expression of Interest: {title} - {profile['name']}"
    
    body = f"""Dear {company} University Recruiting Team,

I am writing to express my strong interest in the {title} position at {company}.

I am currently a {profile['education']}, with a core focus on {skills}. Having closely reviewed the eligibility and role requirements, I believe my background in high-performance problem solving and software development aligns well with your engineering values.

Key Highlights of My Experience:
- Strong foundations in {profile['skills']}.
- Hands-on experience developing modular, resilient systems and participating in competitive technical challenges.
- Active coursework in Algorithms, Operating Systems, and Distributed Computing.

Opportunity Details Referenced:
- Opportunity ID: {opp_id}
- Location: {opportunity.get('location', 'India')}
- Verified Deadline: {opportunity.get('deadline', 'Rolling / TBD')}
- Official Listing: {opportunity.get('application_url', opportunity.get('source_url', ''))}

I would welcome the opportunity to discuss how my skill set and enthusiasm could contribute to the engineering team at {company}. My resume and portfolio links are attached to my candidate profile.

Thank you for your time and consideration.

Warm regards,
{profile['name']}
{profile['education']}
{profile['email']}
"""

    # Build standard MIME email
    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = f"{profile['name']} <{profile['email']}>"
    msg["To"] = to_address
    msg["X-FlowPilot-Opportunity-ID"] = opp_id
    msg["X-FlowPilot-Company"] = company
    msg["X-FlowPilot-Status"] = "DRAFT_ONLY_NOT_SENT"
    msg.set_content(body)

    # Determine filename
    safe_opp_id = re.sub(r"[^a-zA-Z0-9_\-]", "_", opp_id)
    target_dir = output_dir or get_default_drafts_dir(task_id)
    os.makedirs(target_dir, exist_ok=True)
    file_path = os.path.join(target_dir, f"draft_{safe_opp_id}.eml")

    # Atomic write
    temp_path = f"{file_path}.tmp"
    with open(temp_path, "wb") as f:
        f.write(msg.as_bytes(policy=policy.default))
    if os.path.exists(file_path):
        os.remove(file_path)
    os.rename(temp_path, file_path)

    relative_path = os.path.relpath(file_path, os.getcwd()).replace("\\", "/")

    return {
        "success": True,
        "opportunity_id": opp_id,
        "file_path": file_path,
        "relative_path": relative_path,
        "subject": subject,
        "recipient": to_address,
        "recipient_status": recipient_status,
        "requires_human_approval_to_send": True,
        "status": "SAVED_LOCAL_DRAFT",
    }


def inspect_draft(file_path: str) -> Dict[str, Any]:
    """
    Reopens a single saved .eml draft file and inspects headers, content, and opportunity metadata.
    """
    if not os.path.exists(file_path):
        return {"exists": False, "file_path": file_path, "error": "File does not exist"}

    try:
        with open(file_path, "rb") as f:
            msg = BytesParser(policy=policy.default).parse(f)

        body = ""
        if msg.is_multipart():
            for part in msg.walk():
                if part.get_content_type() == "text/plain":
                    body = part.get_content()
                    break
        else:
            body = msg.get_content()

        opp_id = msg.get("X-FlowPilot-Opportunity-ID", "")
        company = msg.get("X-FlowPilot-Company", "")
        subject = msg.get("Subject", "")
        to_addr = msg.get("To", "")

        return {
            "exists": True,
            "file_path": file_path,
            "relative_path": os.path.relpath(file_path, os.getcwd()).replace("\\", "/"),
            "opportunity_id": opp_id,
            "company": company,
            "subject": subject,
            "to": to_addr,
            "body_length": len(body),
            "body_preview": body[:200] + ("..." if len(body) > 200 else ""),
            "has_recipient_placeholder": ("USER_INPUT_REQUIRED" in to_addr or "invalid" in to_addr),
            "is_valid": bool(subject and opp_id and len(body) > 100),
        }
    except Exception as e:
        return {"exists": True, "file_path": file_path, "error": f"Failed to parse draft: {str(e)}", "is_valid": False}


def list_drafts(task_id: Optional[str] = None, output_dir: Optional[str] = None) -> Dict[str, Any]:
    """
    Inspects existing draft files and returns actual paths and identifiers.
    """
    target_dir = output_dir or get_default_drafts_dir(task_id)
    if not os.path.exists(target_dir):
        return {
            "success": True,
            "directory": target_dir,
            "count": 0,
            "drafts": [],
        }

    eml_files = glob.glob(os.path.join(target_dir, "*.eml"))
    drafts = []
    for fpath in sorted(eml_files):
        inspected = inspect_draft(fpath)
        if inspected.get("exists"):
            drafts.append(inspected)

    return {
        "success": True,
        "directory": target_dir,
        "relative_directory": os.path.relpath(target_dir, os.getcwd()).replace("\\", "/"),
        "count": len(drafts),
        "drafts": drafts,
    }
