"""
FlowPilot AI - Alarms, Reminders and Scheduling Tools
Provides persistent SQLite-backed scheduling, task reminders, and deadline trackers.
"""

from datetime import datetime, timezone
from typing import Any, Dict, List, Optional
import database


def create_reminder(
    title: str,
    due_at: str,
    recurrence: str = "ONCE",
    reminder_type: str = "GENERAL",
    task_id: Optional[str] = None,
    db_path: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Create a persistent reminder in SQLite.
    due_at format: YYYY-MM-DD or ISO timestamp (e.g. 2026-11-30T17:00:00Z)
    """
    if not title or not title.strip():
        return {"success": False, "error": "Reminder title cannot be empty."}

    rem = database.create_reminder(
        title=title.strip(),
        due_at=due_at,
        recurrence=recurrence.upper(),
        reminder_type=reminder_type.upper(),
        task_id=task_id,
        db_path=db_path,
    )
    return {
        "success": True,
        "reminder": rem,
        "message": f"Reminder '{title}' scheduled for {due_at} (Recurrence: {recurrence}).",
    }


def list_reminders(
    status: Optional[str] = None,
    task_id: Optional[str] = None,
    limit: int = 50,
    db_path: Optional[str] = None,
) -> Dict[str, Any]:
    """
    List upcoming or historical reminders from SQLite.
    """
    reminders = database.list_reminders(
        status=status,
        task_id=task_id,
        limit=limit,
        db_path=db_path,
    )
    return {
        "success": True,
        "count": len(reminders),
        "reminders": reminders,
    }


def cancel_reminder(
    reminder_id: str,
    db_path: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Cancel an existing reminder in SQLite.
    """
    updated = database.update_reminder(
        reminder_id=reminder_id,
        status="CANCELLED",
        db_path=db_path,
    )
    if not updated:
        return {"success": False, "error": f"Reminder '{reminder_id}' not found."}
    return {
        "success": True,
        "reminder_id": reminder_id,
        "status": "CANCELLED",
        "message": f"Reminder '{reminder_id}' was cancelled.",
    }
