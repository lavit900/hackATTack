"""
FlowPilot AI - Spreadsheet Management and Inspection Tool
Uses openpyxl for idempotent Excel creation, deduplication, professional styling, and inspection.
Includes fault injection simulation for self-healing demonstration.
"""

import os
from typing import Any, Dict, List, Optional, Set
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

import database

COLUMNS = [
    "Opportunity ID",
    "Company / Organization",
    "Opportunity Title",
    "Location",
    "Eligibility",
    "Required Skills",
    "Deadline",
    "Application URL",
    "Source URL",
    "Match Explanation",
    "Verification Status",
]


def get_default_spreadsheet_path(task_id: Optional[str] = None) -> str:
    out_dir = os.getenv("OUTPUT_DIR", "outputs")
    os.makedirs(out_dir, exist_ok=True)
    if task_id:
        return os.path.join(out_dir, f"opportunities_{task_id}.xlsx")
    return os.path.join(out_dir, "opportunities.xlsx")


def save_opportunities(
    opportunities: List[Dict[str, Any]],
    file_path: Optional[str] = None,
    task_id: Optional[str] = None,
    db_path: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Idempotently creates or updates an Excel workbook with opportunities.
    Prevents duplicate rows by tracking stable Opportunity IDs.
    Supports controlled fault injection for demonstration.
    """
    # 1. Controlled fault injection check
    fault = database.check_and_trigger_fault("save_opportunities", task_id=task_id, db_path=db_path)
    if fault:
        raise IOError(f"{fault}: Disk write lock timeout on target workbook. Operation aborted.")

    target_path = file_path or get_default_spreadsheet_path(task_id)
    os.makedirs(os.path.dirname(os.path.abspath(target_path)), exist_ok=True)

    # 2. Open existing or initialize new workbook
    is_new = not os.path.exists(target_path)
    if is_new:
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Internships"
        # Write headers
        ws.append(COLUMNS)
        existing_ids: Set[str] = set()
        id_to_row: Dict[str, int] = {}
    else:
        wb = openpyxl.load_workbook(target_path)
        ws = wb.active
        # Read existing IDs to guarantee idempotency and avoid duplicates
        existing_ids = set()
        id_to_row = {}
        for row_idx in range(2, ws.max_row + 1):
            cell_val = ws.cell(row=row_idx, column=1).value
            if cell_val:
                clean_id = str(cell_val).strip()
                existing_ids.add(clean_id)
                id_to_row[clean_id] = row_idx

    added_count = 0
    updated_count = 0

    # 3. Insert or update rows
    for opp in opportunities:
        opp_id = opp.get("opportunity_id", "").strip()
        if not opp_id:
            continue

        row_data = [
            opp_id,
            opp.get("company", ""),
            opp.get("title", ""),
            opp.get("location", ""),
            opp.get("eligibility", ""),
            opp.get("skills", ""),
            opp.get("deadline", "TBD"),
            opp.get("application_url", ""),
            opp.get("source_url", ""),
            opp.get("match_explanation", ""),
            "VERIFIED" if opp.get("is_verified") else "PENDING_VERIFICATION",
        ]

        if opp_id in existing_ids:
            # Update existing row in place (idempotency)
            row_idx = id_to_row[opp_id]
            for col_idx, val in enumerate(row_data, start=1):
                ws.cell(row=row_idx, column=col_idx, value=val)
            updated_count += 1
        else:
            # Append new row
            ws.append(row_data)
            new_row_idx = ws.max_row
            existing_ids.add(opp_id)
            id_to_row[opp_id] = new_row_idx
            added_count += 1

    # 4. Professional styling
    header_fill = PatternFill(start_color="1A202C", end_color="1A202C", fill_type="solid")
    header_font = Font(name="Segoe UI", size=11, bold=True, color="00F0FF")
    regular_font = Font(name="Segoe UI", size=10, color="2D3748")
    zebra_fill = PatternFill(start_color="F7FAFC", end_color="F7FAFC", fill_type="solid")
    white_fill = PatternFill(start_color="FFFFFF", end_color="FFFFFF", fill_type="solid")
    thin_border = Border(
        left=Side(style="thin", color="E2E8F0"),
        right=Side(style="thin", color="E2E8F0"),
        top=Side(style="thin", color="E2E8F0"),
        bottom=Side(style="thin", color="E2E8F0"),
    )

    # Style header
    for col_idx in range(1, len(COLUMNS) + 1):
        cell = ws.cell(row=1, column=col_idx)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

    # Freeze top row
    ws.freeze_panes = "A2"

    # Style data rows and zebra striping
    for row_idx in range(2, ws.max_row + 1):
        is_even = (row_idx % 2 == 0)
        current_fill = white_fill if is_even else zebra_fill
        for col_idx in range(1, len(COLUMNS) + 1):
            cell = ws.cell(row=row_idx, column=col_idx)
            cell.font = regular_font
            cell.fill = current_fill
            cell.border = thin_border
            if col_idx in (1, 7, 11):
                cell.alignment = Alignment(horizontal="center", vertical="center")
            else:
                cell.alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)

    # Auto-adjust column widths
    for col in ws.columns:
        max_len = 0
        col_letter = get_column_letter(col[0].column)
        for cell in col:
            val = str(cell.value or "")
            if len(val) > max_len:
                max_len = len(val)
        ws.column_dimensions[col_letter].width = min(max(max_len + 4, 12), 40)

    # 5. Atomic save
    temp_path = f"{target_path}.tmp"
    wb.save(temp_path)
    wb.close()
    if os.path.exists(target_path):
        os.remove(target_path)
    os.rename(temp_path, target_path)

    # Return structured outcome
    return {
        "success": True,
        "file_path": target_path,
        "relative_path": os.path.relpath(target_path, os.getcwd()).replace("\\", "/"),
        "total_records": len(existing_ids),
        "added": added_count,
        "updated": updated_count,
        "opportunity_ids": sorted(list(existing_ids)),
    }


def inspect_workbook(file_path: str) -> Dict[str, Any]:
    """
    Reopens the actual Excel workbook using openpyxl.
    Validates sheets, headers, row counts, and detects duplicate IDs.
    """
    if not os.path.exists(file_path):
        return {
            "exists": False,
            "file_path": file_path,
            "error": f"File does not exist: {file_path}",
            "is_valid": False,
            "total_records": 0,
            "opportunity_ids": [],
            "duplicate_ids": [],
        }

    try:
        wb = openpyxl.load_workbook(file_path, data_only=True)
        ws = wb.active

        # Extract headers from row 1
        found_headers = [str(ws.cell(row=1, column=c).value or "").strip() for c in range(1, ws.max_column + 1)]
        missing_headers = [h for h in COLUMNS if h not in found_headers]

        ids_seen = []
        duplicate_ids = []
        records = []

        for row_idx in range(2, ws.max_row + 1):
            row_id = ws.cell(row=row_idx, column=1).value
            if row_id:
                clean_id = str(row_id).strip()
                if clean_id in ids_seen and clean_id not in duplicate_ids:
                    duplicate_ids.append(clean_id)
                ids_seen.append(clean_id)
                records.append({
                    "row": row_idx,
                    "id": clean_id,
                    "company": ws.cell(row=row_idx, column=2).value,
                    "title": ws.cell(row=row_idx, column=3).value,
                    "app_url": ws.cell(row=row_idx, column=8).value,
                    "status": ws.cell(row=row_idx, column=11).value,
                })

        wb.close()
        is_valid = (len(missing_headers) == 0) and (len(duplicate_ids) == 0) and (len(ids_seen) > 0)

        return {
            "exists": True,
            "file_path": file_path,
            "relative_path": os.path.relpath(file_path, os.getcwd()).replace("\\", "/"),
            "sheet_name": ws.title,
            "headers": found_headers,
            "missing_headers": missing_headers,
            "total_records": len(ids_seen),
            "unique_records": len(set(ids_seen)),
            "opportunity_ids": ids_seen,
            "duplicate_ids": duplicate_ids,
            "sample_records": records[:5],
            "is_valid": is_valid,
        }
    except Exception as e:
        return {
            "exists": True,
            "file_path": file_path,
            "error": f"Failed to read workbook: {str(e)}",
            "is_valid": False,
            "total_records": 0,
            "opportunity_ids": [],
            "duplicate_ids": [],
        }
