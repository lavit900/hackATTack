"""
FlowPilot AI - Student Productivity & Placement Preparation Tools
Provides DSA & Core CS interview study plans, resume-to-job matching, and cover letter generation.
"""

import os
import time
from typing import Any, Dict, List, Optional
import database


def generate_study_plan(
    topic: str = "Full Stack & DSA",
    target_role: str = "Software Engineering Intern",
    duration_weeks: int = 4,
    task_id: Optional[str] = None,
    db_path: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Generate structured, milestone-based placement and interview roadmap.
    """
    weeks = []
    topics_list = [
        ("Week 1: Algorithmic Foundations", "Arrays, Two Pointers, Sliding Window, Hashing, Time Complexity (Big-O)"),
        ("Week 2: Advanced Data Structures", "Linked Lists, Stacks, Queues, Binary Trees, BFS/DFS Traversals"),
        ("Week 3: Core Computer Science", "Operating Systems (Processes, Threads, Semaphores), DBMS (SQL, Normalization, ACID), Computer Networks"),
        ("Week 4: System Design & Mock Interviews", "Object-Oriented Design, Microservices vs Monolith, Behavioral Stories (STAR method), Live Mock Coding"),
    ]

    for idx in range(min(duration_weeks, len(topics_list))):
        title, focus = topics_list[idx]
        weeks.append({
            "week_number": idx + 1,
            "title": title,
            "focus_areas": focus,
            "daily_target": "2 LeetCode problems + 1 Core CS subject concept",
            "benchmark_quiz": f"Pass Week {idx + 1} Assessment with >= 80% accuracy",
        })

    # Save artifact if task_id provided
    out_dir = os.path.join("outputs", "study_plans")
    os.makedirs(out_dir, exist_ok=True)
    plan_path = os.path.join(out_dir, f"study_plan_{task_id or 'general'}_{int(time.time())}.txt")
    with open(plan_path, "w", encoding="utf-8") as f:
        f.write(f"FlowPilot AI — Placement Preparation Plan\nTarget Role: {target_role}\nPrimary Domain: {topic}\nDuration: {duration_weeks} Weeks\n\n")
        for w in weeks:
            f.write(f"=== {w['title']} ===\nFocus: {w['focus_areas']}\nTarget: {w['daily_target']}\nBenchmark: {w['benchmark_quiz']}\n\n")

    if task_id:
        database.register_artifact(
            task_id=task_id,
            artifact_type="STUDY_PLAN",
            file_path=plan_path,
            title=f"Study Plan: {target_role} ({duration_weeks}w)",
            metadata={"target_role": target_role, "weeks": len(weeks)},
            db_path=db_path,
        )

    return {
        "success": True,
        "target_role": target_role,
        "duration_weeks": duration_weeks,
        "plan_file": plan_path,
        "modules": weeks,
    }


def compare_resume_to_job(
    resume_text: str,
    job_requirements: str,
    task_id: Optional[str] = None,
    db_path: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Compare candidate resume skills against target job description.
    Produces matching score, detected competencies, and gaps.
    """
    common_skills = ["python", "java", "c++", "data structures", "algorithms", "sql", "linux", "git", "cloud", "react", "fastapi", "docker"]
    resume_lower = resume_text.lower()
    job_lower = job_requirements.lower()

    matched_skills = [s for s in common_skills if s in resume_lower and s in job_lower]
    missing_skills = [s for s in common_skills if s in job_lower and s not in resume_lower]

    total_relevant = len(matched_skills) + len(missing_skills)
    match_score = round((len(matched_skills) / max(1, total_relevant)) * 100, 1)

    recommendations = []
    if missing_skills:
        recommendations.append(f"Add projects highlighting: {', '.join(missing_skills[:3]).title()}.")
    if match_score < 70:
        recommendations.append("Emphasize algorithmic problem solving metrics and quantifiable project outcomes.")
    else:
        recommendations.append("Strong baseline alignment. Tailor bullet points to mirror exact JD terminology.")

    return {
        "success": True,
        "match_score_percent": match_score,
        "matched_skills": matched_skills,
        "missing_skills": missing_skills,
        "recommendations": recommendations,
        "verdict": "STRONG_FIT" if match_score >= 75 else "MODERATE_FIT" if match_score >= 50 else "GAPS_DETECTED",
    }


def draft_cover_letter(
    company: str,
    role: str,
    applicant_skills: str,
    task_id: Optional[str] = None,
    db_path: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Generate a tailored professional cover letter saved as a text artifact.
    """
    letter = f"""Dear Hiring Team at {company},

I am writing to express my enthusiastic interest in the {role} position. As a Computer Science undergraduate with active technical experience in {applicant_skills}, I have focused my academic trajectory on building high-performance, resilient software architectures.

Throughout my coursework and engineering projects, I have developed strong algorithmic rigor, clean code habits, and hands-on familiarity with distributed systems, database design, and end-to-end testing. The mission of {company} in driving cutting-edge software engineering resonates deeply with my career objectives.

I welcome the opportunity to discuss how my technical competencies and proactive problem-solving mindset can contribute directly to your engineering team. Thank you for your time and consideration.

Sincerely,
FlowPilot Applicant
"""
    out_dir = os.path.join("outputs", "cover_letters")
    os.makedirs(out_dir, exist_ok=True)
    file_path = os.path.join(out_dir, f"cover_letter_{company.lower().replace(' ', '_')}_{int(time.time())}.txt")
    with open(file_path, "w", encoding="utf-8") as f:
        f.write(letter)

    if task_id:
        database.register_artifact(
            task_id=task_id,
            artifact_type="COVER_LETTER",
            file_path=file_path,
            title=f"Cover Letter — {company} ({role})",
            metadata={"company": company, "role": role},
            db_path=db_path,
        )

    return {
        "success": True,
        "company": company,
        "role": role,
        "file_path": file_path,
        "content_preview": letter[:250] + "...",
    }
